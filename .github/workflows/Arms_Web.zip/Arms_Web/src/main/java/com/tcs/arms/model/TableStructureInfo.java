package com.tcs.arms.model;

public class TableStructureInfo {

	private String columnId;

	private String columnName;

	private String objectId;

	private String tableName;

	public String getColumnId() {

		return columnId;
	}

	public void setColumnId(String columnId) {

		this.columnId = columnId;
	}

	public String getColumnName() {

		return columnName;
	}

	public void setColumnName(String columnName) {

		this.columnName = columnName;
	}

	public String getObjectId() {

		return objectId;
	}

	public void setObjectId(String objectId) {

		this.objectId = objectId;
	}

	public String getTableName() {

		return tableName;
	}

	public void setTableName(String tableName) {

		this.tableName = tableName;
	}

}