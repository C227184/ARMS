package com.tcs.system.util;

import java.time.format.DateTimeFormatter;

public class Common {

	public static String convertDate(String strDate) {
		String str = "";
		try {
			String fmt = "yyyy-MM-dd HH:mm:ss";
			strDate = strDate.replace("T", " ");
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(fmt);
			return dateTimeFormatter.format(dateTimeFormatter.parse(strDate));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return str;
	}

}