package com.tcs.arms.model;

import java.util.Date;

public class OperationErrorLog {

	private int operationID;

	private String operatorID;

	private String operatorName;

	private Date operateTime;

	private String operateModule;

	private String operateMethod;

	private String operateRequestParam;

	private String operateResponseParam;

	private String operateUri;

	private String operateIP;

	private String businessID;

	private String errorName;

	private String errorMessage;

	private String operateInfo;

	public int getOperationID() {
		return operationID;
	}

	public void setOperationID(int operationID) {
		this.operationID = operationID;
	}

	public String getOperatorID() {
		return operatorID;
	}

	public void setOperatorID(String operatorID) {
		this.operatorID = operatorID;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public Date getOperateTime() {
		return operateTime;
	}

	public void setOperateTime(Date operateTime) {

		this.operateTime = operateTime;
	}

	public String getOperateModule() {
		return operateModule;
	}

	public void setOperateModule(String operateModule) {
		this.operateModule = operateModule;
	}

	public String getOperateMethod() {
		return operateMethod;
	}

	public void setOperateMethod(String operateMethod) {
		this.operateMethod = operateMethod;
	}

	public String getOperateRequestParam() {
		return operateRequestParam;
	}

	public void setOperateRequestParam(String operateRequestParam) {
		this.operateRequestParam = operateRequestParam;
	}

	public String getOperateResponseParam() {
		return operateResponseParam;
	}

	public void setOperateResponseParam(String operateResponseParam) {
		this.operateResponseParam = operateResponseParam;
	}

	public String getOperateUri() {
		return operateUri;
	}

	public void setOperateUri(String operateUri) {
		this.operateUri = operateUri;
	}

	public String getOperateIP() {
		return operateIP;
	}

	public void setOperateIP(String operateIP) {
		this.operateIP = operateIP;
	}

	public String getBusinessID() {
		return businessID;
	}

	public void setBusinessID(String businessID) {
		this.businessID = businessID;
	}

	public String getErrorName() {
		return errorName;
	}

	public void setErrorName(String errorName) {

		this.errorName = errorName;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getOpertateInfo() {
		return operateInfo;
	}

	public void setOpertateInfo(String operateInfo) {
		this.operateInfo = operateInfo;
	}

}