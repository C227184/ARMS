package com.tcs.aop;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.alibaba.fastjson.JSON;
import com.tcs.annotation.Log;
import com.tcs.common.utils.IPUtils;
import com.tcs.arms.model.OperationErrorLog;
import com.tcs.arms.model.OperationLog;
import com.tcs.arms.service.ArmsService;

import io.jsonwebtoken.Claims;
import com.tcs.arms.service.LoginService;

@Component
@Aspect
public class OperationLogAspect {

	@Resource
	private ArmsService armsService;

	@Resource
	private LoginService loginService;

	@Pointcut("@annotation(com.tcs.annotation.Log)")
	public void operationLogPointCut() {

	}

	// GetRequestParams
	public Map<Object, Object> requestParam(JoinPoint joinPoint) {
		Signature signature = joinPoint.getSignature();
		// 参数名数组
		String[] parameterNames = ((MethodSignature) signature).getParameterNames();
		// 构造参数组集合
		Map<Object, Object> map = new HashMap<>();
		Object[] args = joinPoint.getArgs();
		for (int i = 0; i < args.length; i++) {
			// request/response无法使用toJSON
			if (args[i] instanceof HttpServletRequest) {
				// map.put(JSON.toJSON(parameterNames[i]), "request");
			} else if (args[i] instanceof HttpServletResponse) {
				// map.put(JSON.toJSON(parameterNames[i]), "response");
			} else {
				map.put(JSON.toJSON(parameterNames[i]), JSON.toJSON(args[i]));
			}
		}
		return map;
	}

	/**
	 * 设置操作异常切入点记录异常日志 扫描所有controller包下操作
	 */
	@Pointcut("execution(* com.tcs.arms.controller..*.*(..))")
	public void operationErrorLogPointCut() {
	}

	@AfterReturning(value = "operationLogPointCut()", returning = "keys")
	public void saveOperationLog(JoinPoint joinPoint, Object keys) {

		RequestAttributes requestAttributes = RequestContextHolder.currentRequestAttributes();
		HttpServletRequest request = (HttpServletRequest) requestAttributes
				.resolveReference(requestAttributes.REFERENCE_REQUEST);

		try {
			OperationLog operationLog = new OperationLog();
			MethodSignature signature = (MethodSignature) joinPoint.getSignature();
			Method method = signature.getMethod();
			Log log = method.getAnnotation(Log.class);
			if (log != null) {
				String operateModule = log.operModule();
				String operateType = log.operType();
				String operateDesc = log.operDesc();

				operationLog.setOperateModule(operateModule);
				operationLog.setOperateType(operateType);
				operationLog.setOperateInfo(operateDesc);
			}

			String className = joinPoint.getTarget().getClass().getName();
			String methodName = method.getName();
			methodName = className + "." + methodName;
			operationLog.setOperateMethod(methodName);

			Map<Object, Object> rtnMap = requestParam(joinPoint);
			// converMap(request.getParameterMap());
			// 将参数所在的数组转为json
			String params = JSON.toJSONString(rtnMap);
			// 请求参数
			operationLog.setOperateRequestParam(params);
			// 返回结果
			// operationLog.setOperateResponseParam(JSON.toJSONString(keys));
			operationLog.setOperateIP(IPUtils.getIpAddr(request));
			// 请求URI
			operationLog.setOperateUri(request.getRequestURI());
			operationLog.setOperateTime(new Date());

			if (rtnMap != null) {
				if (methodName.toLowerCase().contains("login")) { // 用戶登錄
					if (rtnMap.get("user") != null) {
						// System.out.println(rtnMap.get("user"));
						Map<Object, Object> userMap = (Map<Object, Object>) rtnMap.get("user");

						if (userMap != null) {
							String userName = userMap.get("username").toString();
							operationLog.setOperatorID(userName);
							operationLog.setOperatorName(userName);
						}
					}
				} else if (methodName.toLowerCase().contains("attributecontrol")) { // 操作系統配置
					if (rtnMap.get("params") != null) {
						Map<Object, Object> paramsMap = (Map<Object, Object>) rtnMap.get("params");

						if (paramsMap != null) {
							String reason = paramsMap.get("changeReason").toString();
							operationLog.setOperateInfo(reason);
						}
					}
				} else if (methodName.toLowerCase().contains("manualruntask")) { // 手動執行task
					if (rtnMap.get("rerunReason") != null) {
						String reason = rtnMap.get("rerunReason").toString();
						reason = "执行原因: " + reason;

						Map<Object, Object> result = (Map<Object, Object>) JSON.toJSON(keys);
						if (result != null) {
							if (result.get("message") != null) {
								String message = result.get("message").toString();
								if (message != null || message != "") {
									reason = reason + ", 结果: " + message;
								}
							}
						}
						operationLog.setOperateInfo(reason);
					}
				} else if (methodName.toLowerCase().contains("tasksyncfilepath")) { // 修改文件同步路徑
					if (rtnMap.get("params") != null) {
						Map<Object, Object> paramsMap = (Map<Object, Object>) rtnMap.get("params");

						if (paramsMap != null) {
							String reason = paramsMap.get("changeReason").toString();
							operationLog.setOperateInfo(reason);
						}
					}
				} else if (methodName.toLowerCase().contains("querymaininfo")) { // 修改文件同步路徑
					if (rtnMap.get("params") != null) {
						Map<Object, Object> paramsMap = (Map<Object, Object>) rtnMap.get("params");

						if (paramsMap.size() < 3) {
							return;
						}
					}
				}
			}

			if (request.getHeader("Token") != null) {
				// 携帶Token的各種接口
				String token = request.getHeader("Token");
				Claims c = loginService.parserToken(token);
				String userName = c.get("username").toString();
				operationLog.setOperatorID(userName);
				operationLog.setOperatorName(userName);
			}

			armsService.SaveOperationLog(operationLog);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@AfterThrowing(pointcut = "operationErrorLogPointCut()", throwing = "e")
	public void saveOperationErrorLog(JoinPoint joinPoint, Throwable e) {
		// 获取RequestAttributes
		RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
		// 从RequestAttributes中获取HttpServletRequest的信息
		HttpServletRequest request = (HttpServletRequest) requestAttributes
				.resolveReference(RequestAttributes.REFERENCE_REQUEST);

		OperationErrorLog errorLog = new OperationErrorLog();
		try {
			// 在切面织入点通过反射机制获取织入点的方法
			MethodSignature signature = (MethodSignature) joinPoint.getSignature();
			// 获取织入点的方法
			Method method = signature.getMethod();
			// 获取操作
			Log log = method.getAnnotation(Log.class);
			// 获取请求的类名
			String className = joinPoint.getTarget().getClass().getName();
			// 获取请求的方法
			String methodName = method.getName();
			methodName = className + "." + methodName;
			// 请求的参数
			Map<String, String> rtnMap = converMap(request.getParameterMap());
			String params = JSON.toJSONString(rtnMap);
			// 请求参数
			errorLog.setOperateRequestParam(params);
			// 请求方法名
			errorLog.setOperateMethod(methodName);
			// 异常名称
			errorLog.setErrorName(e.getClass().getName());
			// 异常信息
			errorLog.setErrorMessage(stackTraceToString(e.getClass().getName(), e.getMessage(), e.getStackTrace()));
			// 请求URI
			errorLog.setOperateUri(request.getRequestURI());
			// 操作员ip地址
			errorLog.setOperateIP(IPUtils.getIpAddr(request));
			// 发生异常的时间
			errorLog.setOperateTime(new Date());

			String UserId = "AOP-Error-001";
			String UserName = "AOP-Error";
			HttpSession session = request.getSession();
			if (session != null) {
				if (session != null) {
					if (session.getAttribute("UserId") != null) {
						UserId = session.getAttribute("UserId").toString();
					}
					if (session.getAttribute("UserName") != null) {
						UserName = session.getAttribute("UserName").toString();
					}
				}
			}

			errorLog.setOperatorID(UserId);
			errorLog.setOperatorName(UserName);

			// armsService.SaveOperationErrorLog(errorLog);

		} catch (Exception ex) {
			System.out.println("e.getMessage(): " + ex.getMessage());
			System.out.println("e.toString(): " + ex.toString());
			System.out.println("e.printStackTrace():");
			ex.printStackTrace();
		}
	}

	/**
	 * 转换request请求参数
	 * 
	 * @param paramMap request中获取的参数数组
	 * @return 转换后的数组
	 */
	public Map<String, String> converMap(Map<String, String[]> paramMap) {
		Map<String, String> rtnMap = new HashMap<>();
		for (String key : paramMap.keySet()) {
			rtnMap.put(key, paramMap.get(key)[0]);
		}
		return rtnMap;
	}

	public String stackTraceToString(String exceptionName, String exceptionMessage, StackTraceElement[] elements) {
		StringBuilder stringBuilder = new StringBuilder();
		for (StackTraceElement element : elements) {
			stringBuilder.append(element).append("\n");
		}
		String message = exceptionName + ":" + exceptionMessage + "\n\t" + stringBuilder.toString();
		return message;
	}

}