package com.tcs.arms.service;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.xml.*;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Iterator;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.common.utils.ConstInfo;
import com.tcs.common.utils.DateUtils;
import com.tcs.arms.mapper.ArmsMapper;
import com.tcs.arms.model.AuditInfo;
import com.tcs.arms.model.MainInfo;
import com.tcs.arms.model.TaskSyncFilePath;
import com.tcs.arms.model.TaskSyncLog;

/*
 * 文件名：TaskService.java
 * 描述：数据文件同步
 * 作者：Haijun Huang
 * 创建时间：2023-06-01
*/

@Service
public class TaskService {

	@Autowired
	private ArmsService armsService;

	@Value("${arms.baseSourceAPath}")
	private String baseSourceAPath;

	@Value("${arms.baseSourceBPath}")
	private String baseSourceBPath;

	@Value("${arms.baseTargetPath}")
	private String baseTargetPath;

	@Value("${arms.baseTempPath}")
	private String baseTempPath;

	@Value("${arms.syncLimitNumber}")
	private int syncLimitNumber;

	// Ldap Info
	@Value("${ldap.url}")
	private String ldapUrl;

	@Value("${ldap.base}")
	private String ldapBase;

	@Value("${ldap.userName}")
	private String ldapUserName;

	@Value("${ldap.userPwd}")
	private String ldapUserPwd;

	@Value("${ldap.referral}")
	private String ldapReferral;

	private static final SimpleDateFormat dataFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public boolean resolveFileWithManual(String fileName) {

		TaskSyncFilePath filePathModel = armsService.QueryTaskSyncFilePathInfo();
		if (filePathModel == null)
			return false;

		baseSourceAPath = filePathModel.getSourceAPath();
		// baseTargetPath = filePathModel.getTargetPath();
		int baseDirLength = baseTargetPath.lastIndexOf("\\");

		// baseSourceAPath = "C:\\Lilly\\Temp\\arms_SourceA";

		// 1.獲取目錄下的所有文件
		File dirSource = new File(baseSourceAPath);
		File dirTarget = new File(baseTargetPath);

		// 判断源文件夹是否存在
		if (!dirSource.exists()) {
			System.out.println("源文件夾 " + baseSourceAPath + " 不存在");
			return false;
		}

		String baseSourceCompleted = baseSourceAPath + "\\Completed";
		String fileSourceName = dirSource + "\\" + fileName;
		File source_file = new File(fileSourceName);
		if (!source_file.exists()) {
			System.out.println("源文件 " + fileName + " 不存在");

			// fileName在baseSourceAPath不存在，繼續查找baseSourceBPath
			String baseSourceBPath = filePathModel.getSourceBPath();
			if (baseSourceBPath == null) {
				System.out.println("源文件夾 " + baseSourceBPath + " 未配置");
				return false;
			}

			dirSource = new File(baseSourceBPath);
			if (!dirSource.exists()) {
				System.out.println("源文件夾 " + baseSourceBPath + " 未存在");
				return false;
			}

			fileSourceName = dirSource + "\\" + fileName;
			source_file = new File(fileSourceName);
			if (!source_file.exists()) {
				System.out.println("源文件 " + fileName + " 不存在");
				return false;
			}
			baseSourceCompleted = baseSourceBPath + "\\Completed";
		}

		// 判断目標文件夹是否存在
		if (!dirTarget.exists()) {
			dirTarget.mkdirs();
			// System.out.println("目標文件夹 "+baseSourceAPath+" 不存在");
			// return;
		}

		File dirSourceCompleted = new File(baseSourceCompleted);
		if (!dirSourceCompleted.exists()) {
			dirSourceCompleted.mkdirs();
		}

		// 解析xml
		MainInfo mainModel = new MainInfo();

		String fullFileName = dirSource + "\\" + fileName;

		String fileNameWithNoExtension = fileName.replace(".xml", "").replace(".XML", "");
		String dirTargetDirectoryWithFileName = dirTarget + "\\" + fileNameWithNoExtension;
		String fullTargetFileName = dirTargetDirectoryWithFileName + "\\" + fileName;

		// .audit.xml
		String auditFileName = fileName.replace(".xml", ".audit.xml");
		String fullAuditFileName = dirSource + "\\" + auditFileName;
		;
		String fullTargetAuditFileName = dirTargetDirectoryWithFileName + "\\" + auditFileName;

		// PDF
		String pdfFileName = fileName.replace(".xml", ".pdf");
		String fullPdfFileName = dirSource + "\\" + pdfFileName;
		String fullTargetPdfFileName = dirTargetDirectoryWithFileName + "\\" + pdfFileName;

		Date nowTime = new Date();
		MainInfo h_model = armsService.QueryMainInfo(fileName);
		if (h_model != null) {
			boolean syncFlag = h_model.getSyncFlag();
			if (syncFlag == true)
				return false;

			int syncNumber = armsService.CountTaskSyncLog(fileName);
			int mainId = h_model.getMainId();
			try {
				// 更新XML操作
				mainModel = readXml(fullFileName);
				if (mainModel != null) {
					boolean flag = true;
					String message = "Success";

					mainModel.setMainId(mainId);
					mainModel.setXmlFileName(fileName);
					mainModel.setXmlFileNamePath(fullTargetFileName);
					mainModel.setXmlAuditFileName(auditFileName);
					mainModel.setXmlAuditFileNamePath(fullTargetAuditFileName);

					mainModel.setSyncNumber(syncNumber + 1);
					mainModel.setSyncFlag(flag);
					mainModel.setRowCreatedTime(nowTime);

					boolean hasPdfFlag = false;
					File pdfFile = new File(fullPdfFileName);
					if (pdfFile.exists()) {
						hasPdfFlag = true;
						mainModel.setHasPdfFlag(hasPdfFlag);
						mainModel.setPdfFileName(pdfFileName);
						mainModel.setPdfFileNamePath(fullTargetPdfFileName);
					} else {
						mainModel.setHasPdfFlag(false);
						//mainModel.setPdfFileName("");
						//mainModel.setPdfFileNamePath("");
					}

					int m_result = armsService.UpdateMainInfo(mainModel);

					if (m_result > 0) {

						List<AuditInfo> auditList = readAuditXml(fullAuditFileName, mainId);
						// Clean auditInfo with mainId
						armsService.DeleteAuditInfo(mainId);

						if (auditList != null) {
							armsService.SaveAuditInfo(auditList);
						}

						// 複製 Source File 到 Target
						copyFileToTargetDirectory(fullFileName, dirTargetDirectoryWithFileName);
						copyFileToTargetDirectory(fullAuditFileName, dirTargetDirectoryWithFileName);
						if (hasPdfFlag) {
							copyFileToTargetDirectory(fullPdfFileName, dirTargetDirectoryWithFileName);
						}

						// 遷移Source File 到 Completed
						copyFileToTargetDirectory(fullFileName, baseSourceCompleted);
						copyFileToTargetDirectory(fullAuditFileName, baseSourceCompleted);
						if (hasPdfFlag) {
							copyFileToTargetDirectory(fullPdfFileName, baseSourceCompleted);
						}

						copyFileToTargetDirectory(fullFileName + ".hash", baseSourceCompleted);
						copyFileToTargetDirectory(fullAuditFileName + ".hash", baseSourceCompleted);
						if (hasPdfFlag) {
							copyFileToTargetDirectory(fullPdfFileName + ".hash", baseSourceCompleted);
						}

						deleteFile(fullFileName);
						deleteFile(fullAuditFileName);
						deleteFile(fullPdfFileName);
					}
					// 保存数据同步日志
					saveTaskSyncLog(flag, mainId, ConstInfo.Manual, fileName, message);
					return true;
				}
			} catch (Exception e) {

				saveTaskSyncLog(false, mainId, ConstInfo.Manual, fileName, "Error");

				System.out.println(e.getMessage().toString());

				return false;

			} finally {

			}
		} else {
			try {
				mainModel = readXml(fullFileName);
				if (mainModel != null) {

					boolean flag = true;
					String message = "Success";

					mainModel.setXmlFileName(fileName);
					mainModel.setXmlFileNamePath(fullTargetFileName);
					mainModel.setXmlAuditFileName(auditFileName);
					mainModel.setXmlAuditFileNamePath(fullTargetAuditFileName);

					mainModel.setSyncNumber(1);
					mainModel.setSyncFlag(flag);
					mainModel.setRowCreatedTime(nowTime);

					boolean hasPdfFlag = false;
					File pdfFile = new File(fullPdfFileName);
					if (pdfFile.exists()) {
						hasPdfFlag = true;
						mainModel.setHasPdfFlag(hasPdfFlag);
						mainModel.setPdfFileName(pdfFileName);
						mainModel.setPdfFileNamePath(fullTargetPdfFileName);
					} else {
						mainModel.setHasPdfFlag(false);
						//mainModel.setPdfFileName("");
						//mainModel.setPdfFileNamePath("");
					}

					int m_result = armsService.SaveMainInfo(mainModel);
					// int m_result = armsService.SaveMainInfoWithSQL(mainModel);

					int mainId = mainModel.getMainId();

					if (m_result > 0) {

						List<AuditInfo> auditList = readAuditXml(fullAuditFileName, mainId);

						if (auditList != null) {
							int a_result = armsService.SaveAuditInfo(auditList);
						}

						// 複製 Source File 到 Target
						copyFileToTargetDirectory(fullFileName, dirTargetDirectoryWithFileName);
						copyFileToTargetDirectory(fullAuditFileName, dirTargetDirectoryWithFileName);
						if (hasPdfFlag) {
							copyFileToTargetDirectory(fullPdfFileName, dirTargetDirectoryWithFileName);
						}

						// 遷移Source File 到 Completed
						copyFileToTargetDirectory(fullFileName, baseSourceCompleted);
						copyFileToTargetDirectory(fullAuditFileName, baseSourceCompleted);
						if (hasPdfFlag) {
							copyFileToTargetDirectory(fullPdfFileName, baseSourceCompleted);
						}

						copyFileToTargetDirectory(fullFileName + ".hash", baseSourceCompleted);
						copyFileToTargetDirectory(fullAuditFileName + ".hash", baseSourceCompleted);
						if (hasPdfFlag) {
							copyFileToTargetDirectory(fullPdfFileName + ".hash", baseSourceCompleted);
						}

						deleteFile(fullFileName);
						deleteFile(fullAuditFileName);
						deleteFile(fullPdfFileName);
					}
					// 保存数据同步日志
					saveTaskSyncLog(flag, mainId, ConstInfo.Manual, fileName, message);
					return true;
				}
			} catch (Exception e) {
				Object mainId = mainModel.getMainId();
				if (mainId == null)
					mainId = 0;

				saveTaskSyncLog(false, mainModel.getMainId(), ConstInfo.Manual, fileName, "Error");

				System.out.println(e.getMessage().toString());

				return false;

			} finally {
			}
		}
		return true;
	}

	public void resolveFile() {

		TaskSyncFilePath filePathModel = armsService.QueryTaskSyncFilePathInfo();
		if (filePathModel == null)
			return;

		baseSourceAPath = filePathModel.getSourceAPath();
		baseSourceBPath = filePathModel.getSourceBPath();

		// baseSourceAPath = "C:\\Lilly\\Temp\\arms_SourceA";

		List<String> listSource = new ArrayList<String>();
		if (baseSourceAPath != null) {
			listSource.add(baseSourceAPath);
		}
		if (baseSourceBPath != null) {
			listSource.add(baseSourceBPath);
		}

		for (String itemSource : listSource) {

			// 1.獲取目錄下的所有文件
			File dirSource = new File(itemSource);
			if (!dirSource.exists()) {
				System.out.println("源文件夾 " + itemSource + " 不存在");
				continue;
			}

			String baseSourceCompleted = itemSource + "\\Completed";
			File dirSourceCompleted = new File(baseSourceCompleted);
			if (!dirSourceCompleted.exists()) {
				dirSourceCompleted.mkdirs();
			}

			File dirTarget = new File(baseTargetPath);
			if (!dirTarget.exists()) {
				dirTarget.mkdirs();
			}

			// 解析xml
			File[] sFiles = dirSource.listFiles();

			if (sFiles == null || sFiles.length == 0)
				continue;

			for (File sfile : sFiles) {
				if (!sfile.isFile() || sfile.isDirectory()) {
					continue;
				}

				String fileName = sfile.getName();
				MainInfo mainModel = new MainInfo();

				// 1.先解析不帶audit名稱的xxxx.xml
				String lowerFileName = fileName.toLowerCase();
				String extensionName = getFileExtensionName(lowerFileName);

				if (extensionName.contains(".xml") && !lowerFileName.contains("audit")) {

					String fullFileName = dirSource + "\\" + fileName;
					String fileNameWithNoExtension = fileName.replace(".xml", "").replace(".XML", "");
					String dirTargetDirectoryWithFileName = dirTarget + "\\" + fileNameWithNoExtension;
					String fullTargetFileName = dirTargetDirectoryWithFileName + "\\" + fileName;

					// .audit.xml
					String auditFileName = fileName.replace(".xml", ".audit.xml");
					String fullAuditFileName = dirSource + "\\" + auditFileName;
					String fullTargetAuditFileName = dirTargetDirectoryWithFileName + "\\" + auditFileName;

					// PDF
					String pdfFileName = fileName.replace(".xml", ".pdf");
					String fullPdfFileName = dirSource + "\\" + pdfFileName;
					String fullTargetPdfFileName = dirTargetDirectoryWithFileName + "\\" + pdfFileName;

					// 1.判断是否已同步过 n 次，> n 次，不在同步
					int syncNumber = armsService.CountTaskSyncLog(fileName);
					if (syncNumber > syncLimitNumber)
						continue;

					try {
						// 2.首先解析XML是否已签名
						mainModel = readXml(fullFileName);
						if (mainModel != null) {
							boolean signFlag = true;
							String signMessage = "验证通过";
							String sign2 = mainModel.signature2.toString().trim();
							if (sign2 == "" || sign2.length() == 0) {
								signFlag = false;
								signMessage = "SPV验证不通过!";
							}
							// 1.1 未前签名
							if (!signFlag) {
								// System.out.println(signMessage);
								saveTaskSyncLog(false, 0, ConstInfo.Auto, fileName, signMessage);
								continue;
							}
						}
					} catch (Exception ex) {
						continue;
					}

					Date nowTime = new Date();
					MainInfo h_model = armsService.QueryMainInfo(fileName);
					if (h_model != null) {
						boolean syncFlag = h_model.getSyncFlag();
						if (syncFlag == true) // 已同步过
							continue;

						int mainId = h_model.getMainId();
						try {
							// 更新XML操作
							if (mainModel != null) {

								boolean flag = true;
								String message = "Success";

								mainModel.setMainId(mainId);
								mainModel.setXmlFileName(fileName);
								mainModel.setXmlFileNamePath(fullTargetFileName);
								mainModel.setXmlAuditFileName(auditFileName);
								mainModel.setXmlAuditFileNamePath(fullTargetAuditFileName);

								mainModel.setSyncNumber(syncNumber + 1);
								mainModel.setSyncFlag(flag);
								mainModel.setRowCreatedTime(nowTime);

								boolean hasPdfFlag = false;
								File pdfFile = new File(fullPdfFileName);
								if (pdfFile.exists()) {
									hasPdfFlag = true;
									mainModel.setHasPdfFlag(hasPdfFlag);
									mainModel.setPdfFileName(pdfFileName);
									mainModel.setPdfFileNamePath(fullTargetPdfFileName);
								}
								else
								{
									mainModel.setHasPdfFlag(false);
								}

								int m_result = armsService.UpdateMainInfo(mainModel);

								if (m_result > 0) {

									List<AuditInfo> auditList = readAuditXml(fullAuditFileName, mainId);
									// Clean auditInfo with mainId
									armsService.DeleteAuditInfo(mainId);

									if (auditList != null) {
										for (AuditInfo model : auditList) {
											int reValue = armsService.SaveAuditInfoOneByOne(model);
										}
									}
								}

								copyFileToTargetDirectory(fullFileName, dirTargetDirectoryWithFileName);
								copyFileToTargetDirectory(fullAuditFileName, dirTargetDirectoryWithFileName);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName, dirTargetDirectoryWithFileName);
								}

								copyFileToTargetDirectory(fullFileName, baseSourceCompleted);
								copyFileToTargetDirectory(fullAuditFileName, baseSourceCompleted);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName, baseSourceCompleted);
								}

								copyFileToTargetDirectory(fullFileName + ".hash", baseSourceCompleted);
								copyFileToTargetDirectory(fullAuditFileName + ".hash", baseSourceCompleted);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName + ".hash", baseSourceCompleted);
								}

								deleteFile(fullFileName);
								deleteFile(fullAuditFileName);
								deleteFile(fullPdfFileName);

								// 保存数据同步日志
								saveTaskSyncLog(flag, mainId, ConstInfo.Auto, fileName, message);
								if (mainModel != null) {
									mainModel = null;
								}
								continue;
							}
						} catch (Exception e) {
							// saveTaskSyncLog(false, mainId, ConstInfo.Auto, fileName, "Failed:解析失败！");
							if (mainModel != null) {
								mainModel = null;
							}

							System.out.println(e.getMessage().toString());

							continue;

						} finally {

						}
					} else {
						try {
							if (mainModel != null) {
								boolean flag = true;
								String message = "Success";

								mainModel.setXmlFileName(fileName);
								mainModel.setXmlFileNamePath(fullTargetFileName);
								mainModel.setXmlAuditFileName(auditFileName);
								mainModel.setXmlAuditFileNamePath(fullTargetAuditFileName);

								mainModel.setSyncNumber(syncNumber + 1);
								mainModel.setSyncFlag(flag);
								mainModel.setRowCreatedTime(nowTime);

								boolean hasPdfFlag = false;
								File pdfFile = new File(fullPdfFileName);
								if (pdfFile.exists()) {
									hasPdfFlag = true;
									mainModel.setHasPdfFlag(hasPdfFlag);
									mainModel.setPdfFileName(pdfFileName);
									mainModel.setPdfFileNamePath(fullTargetPdfFileName);
								} else {
									mainModel.setHasPdfFlag(false);
									//mainModel.setPdfFileName("");
									//mainModel.setPdfFileNamePath("");
								}

								// System.out.println("Save MainInfo: "+new Date().toString());
								int m_result = armsService.SaveMainInfo(mainModel);
								// int m_result = armsService.SaveMainInfoWithSQL(mainModel);

								int mainId = mainModel.getMainId();

								if (m_result > 0) {

									List<AuditInfo> auditList = readAuditXml(fullAuditFileName, mainId);

									if (auditList != null) {
										for (AuditInfo model : auditList) {
											int reValue = armsService.SaveAuditInfoOneByOne(model);
										}
									}
								}

								copyFileToTargetDirectory(fullFileName, dirTargetDirectoryWithFileName);
								copyFileToTargetDirectory(fullAuditFileName, dirTargetDirectoryWithFileName);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName, dirTargetDirectoryWithFileName);
								}

								copyFileToTargetDirectory(fullFileName, baseSourceCompleted);
								copyFileToTargetDirectory(fullAuditFileName, baseSourceCompleted);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName, baseSourceCompleted);
								}

								copyFileToTargetDirectory(fullFileName + ".hash", baseSourceCompleted);
								copyFileToTargetDirectory(fullAuditFileName + ".hash", baseSourceCompleted);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName + ".hash", baseSourceCompleted);
								}

								deleteFile(fullFileName);
								deleteFile(fullAuditFileName);
								deleteFile(fullPdfFileName);

								// 保存数据同步日志
								saveTaskSyncLog(true, mainId, ConstInfo.Auto, fileName, message);
								if (mainModel != null) {
									mainModel = null;
								}
								continue;
							}
						} catch (Exception e) {
							Object mainId = mainModel.getMainId();
							if (mainId == null)
								mainId = 0;
							// saveTaskSyncLog(false, (int) mainId, ConstInfo.Auto, fileName,
							// "Failed:解析失败！");
							if (mainModel != null) {
								mainModel = null;
							}

							System.out.println(e.getMessage().toString());

							continue;

						} finally {
						}
					}
				}
			}
		}
	}

	public void resolveXmlFile() {

		TaskSyncFilePath filePathModel = armsService.QueryTaskSyncFilePathInfo();
		if (filePathModel == null)
			return;

		baseSourceAPath = filePathModel.getSourceAPath();
		baseSourceBPath = filePathModel.getSourceBPath();

		List<String> listSource = new ArrayList<String>();
		if (baseSourceAPath != null && baseSourceAPath.length() > 0) {
			listSource.add(baseSourceAPath);
		}
		if (baseSourceBPath != null && baseSourceBPath.length() > 0) {
			listSource.add(baseSourceBPath);
		}

		for (String itemSource : listSource) {

			// 1.獲取目錄下的所有文件
			File dirSource = new File(itemSource);
			if (!dirSource.exists()) {
				System.out.println("源文件夾 " + itemSource + " 不存在");
				continue;
			}

			String baseSourceCompleted = itemSource + "\\Completed";
			File dirSourceCompleted = new File(baseSourceCompleted);
			if (!dirSourceCompleted.exists()) {
				dirSourceCompleted.mkdirs();
			}

			File dirTarget = new File(baseTargetPath);
			if (!dirTarget.exists()) {
				dirTarget.mkdirs();
			}

			// 解析xml
			File[] sFiles = dirSource.listFiles((d, s) -> {
				return s.toLowerCase().endsWith(".xml");
			});

			if (sFiles == null || sFiles.length == 0)
				continue;

			for (File sfile : sFiles) {
				if (sfile.isDirectory()) {
					continue;
				}

				String fileName = sfile.getName();

				// 1.先解析不帶audit名稱的xxxx.xml
				String lowerFileName = fileName.toLowerCase();
				String extensionName = getFileExtensionName(lowerFileName);

				if (extensionName.contains(".xml") && !lowerFileName.contains("audit")) {

					String fullFileName = dirSource + "\\" + fileName;
					String fileNameWithNoExtension = fileName.replace(".xml", "").replace(".XML", "");
					String dirTargetDirectoryWithFileName = dirTarget + "\\" + fileNameWithNoExtension;
					String fullTargetFileName = dirTargetDirectoryWithFileName + "\\" + fileName;

					// .audit.xml
					String auditFileName = fileName.replace(".xml", ".audit.xml");
					String fullAuditFileName = dirSource + "\\" + auditFileName;
					String fullTargetAuditFileName = dirTargetDirectoryWithFileName + "\\" + auditFileName;

					// PDF
					String pdfFileName = fileName.replace(".xml", ".pdf");
					String fullPdfFileName = dirSource + "\\" + pdfFileName;
					String fullTargetPdfFileName = dirTargetDirectoryWithFileName + "\\" + pdfFileName;

					// 1.判断是否已同步过 n 次，> n 次，不在同步
					int syncNumber = armsService.CountTaskSyncLog(fileName);
					if (syncNumber > syncLimitNumber)
						continue;

					try {
						// 2.首先解析XML是否已签名
						MainInfo modelInfo = readXml(fullFileName);
						if (modelInfo != null) {
							boolean signFlag = true;
							String signMessage = "验证通过";
							String sign2 = modelInfo.signature2.toString().trim();
							if (sign2 == "" || sign2.length() == 0) {
								signFlag = false;
								signMessage = "SPV验证不通过!";
							}
							// 1.1 未前签名
							if (!signFlag) {
								// System.out.println(signMessage);
								saveTaskSyncLog(false, 0, ConstInfo.Auto, fileName, signMessage);
								continue;
							}
						}
					} catch (Exception ex) {
						continue;
					}

					// Date nowTime = new Date();
					MainInfo h_model = armsService.QueryMainInfo(fileName);
					if (h_model != null) {
						boolean syncFlag = h_model.getSyncFlag();
						if (syncFlag == true) // 已同步过
							continue;

						int mainId = h_model.getMainId();
						try {
							MainInfo mainModel = readXml(fullFileName);
							// 更新XML操作
							if (mainModel != null) {

								boolean flag = true;
								String message = "Success";

								mainModel.setMainId(mainId);
								mainModel.setXmlFileName(fileName);
								mainModel.setXmlFileNamePath(fullTargetFileName);
								mainModel.setXmlAuditFileName(auditFileName);
								mainModel.setXmlAuditFileNamePath(fullTargetAuditFileName);

								mainModel.setSyncNumber(syncNumber + 1);
								mainModel.setSyncFlag(flag);
								mainModel.setRowCreatedTime(new Date());

								boolean hasPdfFlag = false;
								File pdfFile = new File(fullPdfFileName);
								if (pdfFile.exists()) {
									hasPdfFlag = true;
									mainModel.setHasPdfFlag(hasPdfFlag);
									mainModel.setPdfFileName(pdfFileName);
									mainModel.setPdfFileNamePath(fullTargetPdfFileName);
								} else {
									mainModel.setHasPdfFlag(false);
									//mainModel.setPdfFileName("");
									//mainModel.setPdfFileNamePath("");
								}

								int m_result = armsService.UpdateMainInfo(mainModel);

								if (m_result > 0) {

									List<AuditInfo> auditList = readAuditXml(fullAuditFileName, mainId);
									// Clean auditInfo with mainId
									armsService.DeleteAuditInfo(mainId);

									if (auditList != null) {
										for (AuditInfo model : auditList) {
											int reValue = armsService.SaveAuditInfoOneByOne(model);
										}
									}
								}

								copyFileToTargetDirectory(fullFileName, dirTargetDirectoryWithFileName);
								copyFileToTargetDirectory(fullAuditFileName, dirTargetDirectoryWithFileName);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName, dirTargetDirectoryWithFileName);
								}

								copyFileToTargetDirectory(fullFileName, baseSourceCompleted);
								copyFileToTargetDirectory(fullAuditFileName, baseSourceCompleted);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName, baseSourceCompleted);
								}

								copyFileToTargetDirectory(fullFileName + ".hash", baseSourceCompleted);
								copyFileToTargetDirectory(fullAuditFileName + ".hash", baseSourceCompleted);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName + ".hash", baseSourceCompleted);
								}

								deleteFile(fullFileName);
								deleteFile(fullAuditFileName);
								deleteFile(fullPdfFileName);

								// 保存数据同步日志
								saveTaskSyncLog(flag, mainId, ConstInfo.Auto, fileName, message);
								if (mainModel != null) {
									mainModel = null;
								}
								continue;
							}
						} catch (Exception e) {
							// saveTaskSyncLog(false, mainId, ConstInfo.Auto, fileName, "Failed:解析失败！");
							System.out.println(e.getMessage().toString());
							continue;
						}
					} else {
						try {
							MainInfo mainModel = readXml(fullFileName);
							// 更新XML操作
							if (mainModel != null) {
								boolean flag = true;
								String message = "Success";

								mainModel.setXmlFileName(fileName);
								mainModel.setXmlFileNamePath(fullTargetFileName);
								mainModel.setXmlAuditFileName(auditFileName);
								mainModel.setXmlAuditFileNamePath(fullTargetAuditFileName);

								mainModel.setSyncNumber(syncNumber + 1);
								mainModel.setSyncFlag(flag);
								mainModel.setRowCreatedTime(new Date());

								boolean hasPdfFlag = false;
								File pdfFile = new File(fullPdfFileName);
								if (pdfFile.exists()) {
									hasPdfFlag = true;
									mainModel.setHasPdfFlag(hasPdfFlag);
									mainModel.setPdfFileName(pdfFileName);
									mainModel.setPdfFileNamePath(fullTargetPdfFileName);
								} else {
									mainModel.setHasPdfFlag(false);
									//mainModel.setPdfFileName("");
									//mainModel.setPdfFileNamePath("");
								}

								int m_result = armsService.SaveMainInfo(mainModel);

								int mainId = mainModel.getMainId();

								if (m_result > 0) {

									List<AuditInfo> auditList = readAuditXml(fullAuditFileName, mainId);

									if (auditList != null) {
										for (AuditInfo model : auditList) {
											int reValue = armsService.SaveAuditInfoOneByOne(model);
										}
									}
								}

								copyFileToTargetDirectory(fullFileName, dirTargetDirectoryWithFileName);
								copyFileToTargetDirectory(fullAuditFileName, dirTargetDirectoryWithFileName);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName, dirTargetDirectoryWithFileName);
								}

								copyFileToTargetDirectory(fullFileName, baseSourceCompleted);
								copyFileToTargetDirectory(fullAuditFileName, baseSourceCompleted);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName, baseSourceCompleted);
								}

								copyFileToTargetDirectory(fullFileName + ".hash", baseSourceCompleted);
								copyFileToTargetDirectory(fullAuditFileName + ".hash", baseSourceCompleted);
								if (hasPdfFlag) {
									copyFileToTargetDirectory(fullPdfFileName + ".hash", baseSourceCompleted);
								}

								deleteFile(fullFileName);
								deleteFile(fullAuditFileName);
								deleteFile(fullPdfFileName);

								// 保存数据同步日志
								saveTaskSyncLog(true, mainId, ConstInfo.Auto, fileName, message);
								if (mainModel != null) {
									mainModel = null;
								}
								continue;
							}
						} catch (Exception e) {
							System.out.println(e.getMessage().toString());
							continue;
						}
					}
				}
			}
		}
	}

	public void resolveStartedByName() {

		List<String> list = armsService.GetMainInfoWithStartBy();
		if (list.size() == 0) {
			return;
		}

		Hashtable<String, String> HashEnv = new Hashtable<>();
		// LDAP Url
		HashEnv.put(Context.PROVIDER_URL, ldapUrl);
		// LDAP Dns
		// HashEnv.put(Context.DNS_URL, ldapBase);
		// LDAP访问安全级别(none,simple,strong);
		HashEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
		// AD的用户名
		HashEnv.put(Context.SECURITY_PRINCIPAL, "AP\\" + ldapUserName);
		// AD的密码
		HashEnv.put(Context.SECURITY_CREDENTIALS, ldapUserPwd);
		// LDAP工厂类
		HashEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		// 连接超时设置为5秒
		HashEnv.put("com.sun.jndi.ldap.connect.timeout", "5000");

		try {

			InitialDirContext dc = new InitialDirContext(HashEnv);// 初始化上下文
			InitialLdapContext ctx1 = new InitialLdapContext(HashEnv, null);
			// 域节点
			String searchBase = ldapBase;

			for (String item : list) {
				String userId = item.toUpperCase().replace("ap\\", "").replace("AP\\", "");
				String searchFilter = "cn=" + userId;

				SearchControls searchCtls = new SearchControls();
				// 设置查询的属性,根据登陆用户姓名获取ou
				String[] returnedAtts = { "mail", "givenName", "displayName", "cn", "sn" };// 定制返回属性
				searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE); // Create the Specify
				searchCtls.setReturningAttributes(returnedAtts); // 设置返回属性集

				try {
					// 根据设置的域节点、过滤器类和搜索控制器搜索LDAP得到结果
					NamingEnumeration<SearchResult> entries = ctx1.search(searchBase, searchFilter, searchCtls);
					if (!entries.hasMore()) {
						continue;
					}
					SearchResult entry = entries.next();
					Attributes attrs = entry.getAttributes();

					String displayName = attrs.get("displayName").toString();
					String[] displayArray = displayName.split(":");
					if (displayArray.length > 1) {
						displayName = displayArray[1].toString().replace("- Network", "").replace("-Network", "");
						displayName = displayName.trim();
					}
					if (displayName != null) {
						armsService.UpdateMainInfoWithStartBy(item.toString(), displayName);
					}

				} catch (Exception e) {
					System.out.println("更新Record報錯：" + e);
					continue;
				}
			}
		} catch (javax.naming.AuthenticationException e) {
			System.out.println("认证失败");

		} catch (Exception e) {
			System.out.println("更新報錯：" + e);
		}
	}

	public void saveTaskSyncLog(boolean syncFlag, int mainId, String executeType, String taskFile, String message) {

		TaskSyncLog taskLog = new TaskSyncLog();
		taskLog.setMainId(mainId);
		taskLog.setExecuteTime(new Date());
		taskLog.setExecuteType(executeType);
		taskLog.setSyncFlag(syncFlag);
		taskLog.setTaskName("同步任务-XML文件解析");
		taskLog.setMessage(message);
		taskLog.setSyncFileName(taskFile);
		armsService.SaveTaskSyncLog(taskLog);

	}

	private void deleteFile(String FileName) {
		new File(FileName).delete();
		new File(FileName + ".hash").delete();
	}

	private static void getAllFile(File fileInput, List<File> allFileList) {
		// 获取文件列表
		File[] fileList = fileInput.listFiles();
		assert fileList != null;
		for (File file : fileList) {
			if (file.isDirectory()) {
				// 递归处理文件夹
				// 如果不想统计子文件夹则可以将下一行注释掉
				getAllFile(file, allFileList);
			} else {
				// 如果是文件则将其加入到文件数组中
				allFileList.add(file);
			}
		}
	}

	private static void copyFile(File sourceFile, File targetFile) {
		if (!sourceFile.canRead()) {
			System.out.println("源文件" + sourceFile.getAbsolutePath() + "不可读，无法复制！");
			return;
		} else {
			// System.out.println("开始复制文件" + sourceFile.getAbsolutePath() + "到" +
			// targetFile.getAbsolutePath());
			FileInputStream fis = null;
			BufferedInputStream bis = null;
			FileOutputStream fos = null;
			BufferedOutputStream bos = null;

			try {
				fis = new FileInputStream(sourceFile);
				bis = new BufferedInputStream(fis);
				fos = new FileOutputStream(targetFile);
				bos = new BufferedOutputStream(fos);
				int len = 0;
				while ((len = bis.read()) != -1) {
					bos.write(len);
				}
				bos.flush();

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (fis != null) {
						fis.close();
					}
					if (bis != null) {
						bis.close();
					}
					if (fos != null) {
						fos.close();
					}
					if (bos != null) {
						bos.close();
					}
					// System.out.println("文件" + sourceFile.getAbsolutePath() + "复制到" +
					// targetFile.getAbsolutePath() + "完成");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static void copyDirectory(String sourcePathString, String targetPathString) {
		if (!new File(sourcePathString).canRead()) {
			// System.out.println("源文件夹" + sourcePathString + "不可读，无法复制！");
			return;
		} else {
			(new File(targetPathString)).mkdirs();
			System.out.println("开始复制文件夹" + sourcePathString + "到" + targetPathString);
			File[] files = new File(sourcePathString).listFiles();
			for (File file : files) {
				if (file.isFile()) {
					copyFile(new File(sourcePathString + File.separator + file.getName()),
							new File(targetPathString + File.separator + file.getName()));
				} else if (file.isDirectory()) {
					copyDirectory(sourcePathString + File.separator + file.getName(),
							targetPathString + File.separator + file.getName());
				}
			}
			// System.out.println("复制文件夹" + sourcePathString + "到" + targetPathString +
			// "结束");
		}
	}

	private void copyFileToTargetDirectory(String sourceFileName, String targetDirectory) {
		File targetPath = new File(targetDirectory);

		if (!targetPath.exists()) {
			targetPath.mkdir();
		}

		File sourceFile = new File(sourceFileName);

		String fileName = sourceFile.getName();
		String targetFileName = targetDirectory + "\\" + fileName;
		File targetFile = new File(targetFileName);

		copyFile(sourceFile, targetFile);

		// System.out.println("复制文件 " + sourceFileName + " 到 " + targetPathString + "
		// 成功.");
	}

	// 使用lastIndexOf()结合subString()获取后缀名
	private String getFileExtensionName(String fileName) {
		return fileName.substring(fileName.lastIndexOf("."));
	}

	public MainInfo readXml(String fileName) throws Exception {
		if (!new File(fileName).exists()) {
			return null;
		}
		// 1.创建SAXReader对象用于读取xml文件
		SAXReader reader = new SAXReader();
		// 2.读取xml文件，获得Document对象
		Document doc = reader.read(new File(fileName));
		if (doc == null) {
			return null;
		}
		// 3.获取根元素
		Element root = doc.getRootElement();
		// 4.获取根元素下的所有子元素（通过迭代器）
		Iterator<Element> elementList = root.elementIterator("ResultData");

		MainInfo model = new MainInfo();
		while (elementList.hasNext()) {
			Element e = elementList.next();
			Element eLabel = e.element("Label");
			Element eValue = e.element("Value");

			String eLabel_Text = eLabel.getStringValue().replace(".", "").toLowerCase();
			String eValue_Text = eValue.getStringValue();
			if (eValue_Text != null) {
				eValue_Text = eValue_Text.trim();
			}

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			switch (eLabel_Text) {
			case "runqueuerunheader1sttext":
				model.setBatchId(eValue_Text);
				break;

			case "runqueuerunheader4text":
				model.setRunNotes(eValue_Text);
				break;

			case "runqueuestartdate":
				if (eValue_Text.trim() != "") {
					String startDate = DateUtils.formatDateTime(eValue_Text.trim());
					if (startDate != "") {
						Date newDate = sdf.parse(startDate);
						model.setStartDate(newDate);
					} else {
						model.setStartDate(new Date());
					}
				}
				break;
			case "teststestname":
				model.setTestName(eValue_Text);
				break;

			case "teststestfiltername":
				model.setTestFilterName(eValue_Text);
				break;

			case "testsdescription":
				model.setTestDescription(eValue_Text);
				break;

			case "testpassed":
				if (eValue_Text == null) {
					eValue_Text = "99";
				}
				model.setTestPassed(eValue_Text);
				break;

			case "instrumentserialnumber":
				model.setInstrumentSerialNumber(eValue_Text);
				break;

			case "flowrate":
				model.setFlowrate(eValue_Text);
				break;

			case "flowrateatconst":
				model.setFlowRateAtConst(eValue_Text);
				break;

			case "runqueuestartedby":
				model.setStartedBy(eValue_Text);
				break;

			case "runqueuestartedbyfullname":
				model.setStartedByFullName(eValue_Text);
				break;

			case "archivedate":
				if (eValue_Text.trim() != "") {
					String archiveDate = DateUtils.formatDateTime(eValue_Text.trim());
					if (archiveDate != "") {
						Date newDate = sdf.parse(archiveDate);
						model.setArchiveDate(newDate);
					} else {
						model.setArchiveDate(new Date());
					}
				}
				break;
			// add by 20230529
			case "runqueuecompletedate":
				if (eValue_Text.trim() != "") {
					String completeDate = DateUtils.formatDateTime(eValue_Text.trim());
					if (completeDate != "") {
						Date newDate = sdf.parse(completeDate);
						model.setCompleteDate(newDate);
					} else {
						model.setCompleteDate(new Date());
					}
				}
				break;

			case "actualtestpressure":
				model.setActualTestPressure(eValue_Text);
				break;

			case "systemsize":
				model.setSystemSize(eValue_Text);
				break;

			case "sizeattemperature":
				model.setSizeAtTemperature(eValue_Text);
				break;

			case "selfcheckpassed":
				if (eValue_Text == null) {
					eValue_Text = "99";
				}
				model.setSelfCheckPassed(eValue_Text);
				break;

			case "testsfiltersize":
				model.setFilterSize(eValue_Text);
				break;

			case "testsnumofrounds":
				model.setNumOfRounds(eValue_Text);
				break;

			case "runqueuelastcalibrationdate":
				if (eValue_Text.trim() != "") {
					String lastCalibrationDate = DateUtils.formatDateTime(eValue_Text.trim());
					if (lastCalibrationDate != "") {
						Date newDate = sdf.parse(lastCalibrationDate);
						model.setLastCalibrationDate(newDate);
					} else {
						model.setLastCalibrationDate(new Date());
					}
				}
				break;

			case "runqueuecalibrationoverdue":
				model.setCalibrationOverdue(eValue_Text);
				break;

			case "signature1":
				model.setSignature1(eValue_Text);
				break;

			case "signature2":
				model.setSignature2(eValue_Text);
				break;

			case "signaturesremaining":
				model.setSignaturesRemaining(eValue_Text);
				break;

			default:
				break;
			}
		}
		return model;
	}

	public List<AuditInfo> readAuditXml(String fileName, Integer mainId) throws Exception {

		if (!new File(fileName).exists()) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		// 1.创建SAXReader对象用于读取xml文件
		SAXReader reader = new SAXReader();
		// 2.读取xml文件，获得Document对象
		Document doc = reader.read(new File(fileName));

		if (doc == null) {
			return null;
		}

		// 3.获取根元素
		Element root = doc.getRootElement();
		// 4.获取根元素下的所有子元素（通过迭代器）
		Iterator<Element> elementList = root.elementIterator("row");
		List<AuditInfo> list = new ArrayList<AuditInfo>();
		while (elementList.hasNext()) {
			Element e = elementList.next();

			Element e_changeid = e.element("changeid");
			Element e_date = e.element("date");
			Element e_level = e.element("level");
			Element e_source = e.element("source");
			Element e_objectname = e.element("objectname");
			Element e_eventidname = e.element("eventidname");
			Element e_eventid = e.element("eventid");
			Element e_createddate = e.element("createddate");
			Element e_createdby = e.element("createdby");
			Element e_createdbyfullname = e.element("createdbyfullname");
			Element e_computer = e.element("computer");
			Element e_processid = e.element("processid");
			Element e_message = e.element("message");
			Element e_data = e.element("data");

			AuditInfo model = new AuditInfo();
			model.setMainId(mainId);
			model.setChangeId(Integer.parseInt(e_changeid.getStringValue()));

			String eDate = DateUtils.formatDateTime(e_date.getStringValue());
			if (eDate != "") {
				Date newDate = sdf.parse(eDate);
				model.setDate(newDate);
			}
			model.setLevel(Integer.parseInt(e_level.getStringValue()));
			model.setSource(e_source.getStringValue());
			model.setObjectName(e_objectname.getStringValue());
			model.setEventIdName(e_eventidname.getStringValue());
			model.setEventId(Integer.parseInt(e_eventid.getStringValue()));

			if (e_createddate.getStringValue().toString().trim() != "") {
				String cDate = DateUtils.formatDateTime(e_createddate.getStringValue());
				if (cDate != "") {
					Date newCreateDate = sdf.parse(cDate);
					model.setCreatedDate(newCreateDate);
				}
			}

			model.setCreatedBy(e_createdby.getStringValue());
			model.setCreatedByFullName(e_createdbyfullname.getStringValue());
			model.setComputer(e_computer.getStringValue());
			model.setProcessId(e_processid.getStringValue());
			model.setMessage(e_message.getStringValue());
			String dataValue = e_data.getStringValue();
			if (dataValue == "" || dataValue == null) {
				dataValue = e_data.getTextTrim();
			}
			model.setData(dataValue);
			model.setRowCreatedTime(new Date());
			list.add(model);
		}
		return list;
	}
}