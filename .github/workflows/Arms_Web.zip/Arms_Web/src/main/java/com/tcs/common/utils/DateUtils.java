package com.tcs.common.utils;

import org.joda.time.DateTime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class DateUtils {
	
    public static Date addDateHours(Date date, int hours) {
        DateTime dateTime = new DateTime(date);
        return dateTime.plusHours(hours).toDate();
    }
    
    public static String format(Date date, String pattern) {
        if (date != null) {
            SimpleDateFormat df = new SimpleDateFormat(pattern);
            return df.format(date);
        }
        return null;
    }
    
    
    //把utc格式日期转换为常见的格式
    public static String formatTime(String timeStr) {
        try {
            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
            SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = sdf1.parse(timeStr);
            return sdf2.format(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return timeStr;
    }
 
    //判断是否为日期格式
    public static boolean isValidDate(String dateString) {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            df.parse(dateString);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
    
    public static String formatDateTime(String timeStr) {
        try {
        	
            LocalDateTime date = LocalDateTime.parse(timeStr,DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    		String dateString = date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            return dateString;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
   
}
