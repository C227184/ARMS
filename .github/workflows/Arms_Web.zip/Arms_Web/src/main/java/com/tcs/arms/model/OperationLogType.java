package com.tcs.arms.model;

public interface OperationLogType {

	String QUERY = "查询";

	String ADD = "新增";

	String MODIFY = "修改";

	String WITHDRAW = "撤回";

	String DELETE = "删除";
	
	String ChangeSystemConfig="修改系统配置";
	
	String RerunTask="Re-run Task";
	
	String QueryReport="查询报告";
	
	String ExportReport="导出报告";
	
	String Login="登录";
	
	String Logout="注销";
	
	String DownLoad="查看PDF";
}