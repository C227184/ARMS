package com.tcs.arms.model;

public class AttributeControlInfo {

	private int Id;

	private String attributeId;

	private String attributeName;

	private String tableId;

	private String tableName;

	private int sort;

	private boolean isActive;

	private String changeReason;

	public int getId() {

		return Id;
	}

	public void setId(int Id) {

		this.Id = Id;
	}

	public String getAttributeId() {

		return attributeId;
	}

	public void setAttributeId(String attributeId) {

		this.attributeId = attributeId;
	}

	public String getAttributeName() {

		return attributeName;
	}

	public void setAttributeName(String attributeName) {

		this.attributeName = attributeName;
	}

	public String getTableId() {

		return tableId;
	}

	public void setTableId(String tableId) {

		this.tableId = tableId;
	}

	public String getTableName() {

		return tableName;
	}

	public void setTableName(String tableName) {

		this.tableName = tableName;
	}

	public int getSort() {

		return sort;
	}

	public void setSort(int sort) {

		this.sort = sort;
	}

	public boolean getIsActive() {

		return isActive;
	}

	public void setIsActive(boolean isActive) {

		this.isActive = isActive;
	}

	public String getChangeReason() {
		return changeReason;
	}

	public void setChangeReason(String changeReason) {
		this.changeReason = changeReason;
	}

}