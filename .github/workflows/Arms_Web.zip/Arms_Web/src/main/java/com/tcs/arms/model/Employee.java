package com.tcs.arms.model;

public class Employee{

		public String employeeId;

		public String name;

		public String displayName;

		public String role;
		
		
		public String getEmployeeId() {

			return employeeId;
		}

		public void setEmployeeId(String employeeId) {

			this.employeeId = employeeId;
		}
		
		public String getName() {

			return name;
		}

		public void setName(String name) {

			this.name = name;
		}
		
		public String getDisplayName() {

			return displayName;
		}

		public void seDisplayName(String displayName) {

			this.displayName = displayName;
		}
		
		public String getRole() {

			return role;
		}

		public void seRole(String role) {

			this.role = role;
		}
}