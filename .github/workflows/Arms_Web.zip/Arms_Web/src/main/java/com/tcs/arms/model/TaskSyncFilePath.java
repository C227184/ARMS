package com.tcs.arms.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class TaskSyncFilePath {

	private int id;

	private String sourcePath;
	
	private String sourceAPath;
	
	private String sourceBPath;

	private String targetPath;
	
	private String changeReason;

	public int getId() {

		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSourcePath() {

		return sourcePath;
	}

	public void setSourcePath(String sourcePath) {

		this.sourcePath = sourcePath;
	}
	
	public String getSourceAPath() {

		return sourceAPath;
	}

	public void setSourceAPath(String sourceAPath) {

		this.sourceAPath = sourceAPath;
	}
	
	public String getSourceBPath() {

		return sourceBPath;
	}

	public void setSourceBPath(String sourceBPath) {

		this.sourceBPath = sourceBPath;
	}

	public String getTargetPath() {

		return targetPath;
	}

	public void setTargetPath(String targetPath) {

		this.targetPath = targetPath;
	}
	
	public String getChangeReason() {

		return changeReason;
	}

	public void setChangeReason(String changeReason) {

		this.changeReason = changeReason;
	}
}