package com.tcs.system.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.common.utils.PageResult;
import com.tcs.common.utils.R;
import com.tcs.common.utils.Result;
import com.tcs.common.utils.TokenUtils;
import com.tcs.arms.service.LoginService;
import com.tcs.system.model.Menu;
import com.tcs.system.model.MenuMeta;
import com.tcs.arms.model.UserInfo;

import io.jsonwebtoken.Claims;

//@RestController
//@RequestMapping("/users")
public class UserController {

	@Autowired
	private LoginService loginService;

	@GetMapping("/info")
	public R getRoleList(HttpServletRequest request) {
		// 解析Token
		try {
			if (request.getHeader("Token") == null) {
				return R.ok().put("result", null);
			}

			String token = request.getHeader("Token");
			Claims c = loginService.parserToken(token);
			String userName = c.get("username").toString();
			String passWord = c.get("password").toString();
			// 模擬賬號
			String name = userName;
			if (name.equalsIgnoreCase("admin") || name.equalsIgnoreCase("L003828") || name.equalsIgnoreCase("user")) {
				String role = "admin";
				if (name.equalsIgnoreCase("user")) {
					role = "user";
				}
				UserInfo user = loginService.GetUserInfo(userName, userName, userName, role, token);
				return R.ok().put("result", user);
			}

			// 獲取MemberOf權限信息
			UserInfo result = loginService.Login2(userName, passWord, token);
			return R.ok().put("result", result);

		} catch (Exception e) {
			e.printStackTrace();
			return R.ok().put("result", null);
		}
	}

	@RequestMapping("/nav")
	public R getUserMenus() {

		List<Menu> dataArray = new ArrayList<>();
		Menu menu1 = new Menu();
		menu1.setId(1);
		menu1.setParentId(0);
		menu1.setName("reportMain");
		menu1.setRedirect("/report/mainInfo");
		menu1.setComponent("RouteView");
		menu1.setTitle("menu.report.display");
		menu1.setIcon("table");
		menu1.setKeepAlive(true);
		menu1.setIndex(1);
		dataArray.add(menu1);

		Menu menu2 = new Menu();
		menu2.setId(2);
		menu2.setParentId(1);
		menu2.setName("report");
		menu2.setRedirect("/report/mainInfo");
		// menu2.setComponent("RouteView");
		menu2.setTitle("menu.report.display");
		// menu2.setIcon("table");
		menu2.setKeepAlive(true);
		menu2.setIndex(1);
		dataArray.add(menu2);

		return R.ok().put("result", dataArray);
	}
}