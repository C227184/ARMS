package com.tcs.arms.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class MainInfo {

	public int mainId;

	public String runQueueTestName;

	public String runQueueTestFilterName;

	public String runQueueID;

	public String runQueueStatus;

	// Batch ID
	public String batchId;

	// Run notes
	public String runNotes;

	// Start Date
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date startDate;

	// Test Name
	public String testName;

	public String testFilterName;

	// Test Description
	public String testPassed;

	// Test Passed
	public String testDescription;

	// Instrument Serial Number
	public String instrumentSerialNumber;

	// Flow Rate
	public String flowRate;

	// Flow Rate AtConst
	public String flowRateAtConst;

	// Started by
	public String startedBy;

	// Started by
	public String startedByName;

	// Started by
	public String startedByFullName;

	// Archive Date
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date archiveDate;

	// Complete Date
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date completeDate;

	// Actual Test Pressure
	public String actualTestPressure;

	// System Size
	public String systemSize;

	// Filter Size
	public String sizeAtTemperature;

	// Self Check Passed
	public String selfCheckPassed;

	// Filter Size
	public String filterSize;

	// Number Rounds
	public String numOfRounds;

	// Last Calibration Date
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date lastCalibrationDate;

	// Calibration Overdue
	public String calibrationOverdue;

	// signature1
	public String signature1;

	// signature2
	public String signature2;

	// signaturesRemaining
	public String signaturesRemaining;

	public String xmlFileName;

	public String xmlFileNamePath;

	public String xmlAuditFileName;

	public String xmlAuditFileNamePath;

	public boolean syncFlag;

	public int syncNumber;

	public boolean hasPdfFlag;

	public String pdfFileNamePath;

	public String pdfFileName;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	public Date rowCreatedTime;

	public void setMainId(int mainId) {
		this.mainId = mainId;
	}

	public int getMainId() {

		return mainId;
	}

	public String getRunQueueTestName() {

		return runQueueTestName;
	}

	public void setRunQueueTestName(String runQueueTestName) {

		this.runQueueTestName = runQueueTestName;
	}

	public String getRunQueueTestFilterName() {

		return runQueueTestFilterName;
	}

	public void setRunQueueTesFiltertName(String runQueueTestFilterName) {

		this.runQueueTestFilterName = runQueueTestFilterName;
	}

	public String getRunQueueID() {

		return runQueueID;
	}

	public void setRunQueueID(String runQueueID) {

		this.runQueueID = runQueueID;
	}

	public String getRunQueueStatus() {

		return runQueueStatus;
	}

	public void setRunQueueStatus(String runQueueStatus) {

		this.runQueueStatus = runQueueStatus;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getRunNotes() {
		return runNotes;
	}

	public void setRunNotes(String runNotes) {
		this.runNotes = runNotes;
	}

	public Date getStartDate() {
		if (startDate == null) {
			return null;
		}
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public String getTestFilterName() {
		return testFilterName;
	}

	public void setTestFilterName(String testFilterName) {
		this.testFilterName = testFilterName;
	}

	public String getTestPassed() {
		return testPassed;
	}

	public void setTestPassed(String testPassed) {
		this.testPassed = testPassed;
	}

	public String getTestDescription() {
		return testDescription;
	}

	public void setTestDescription(String testDescription) {
		this.testDescription = testDescription;
	}

	public String getInstrumentSerialNumber() {
		return instrumentSerialNumber;
	}

	public void setInstrumentSerialNumber(String instrumentSerialNumber) {
		this.instrumentSerialNumber = instrumentSerialNumber;
	}

	public String getFlowrate() {
		return flowRate;
	}

	public void setFlowrate(String flowRate) {
		this.flowRate = flowRate;
	}

	public String getFlowRateAtConst() {
		return flowRateAtConst;
	}

	public void setFlowRateAtConst(String flowRateAtConst) {
		this.flowRateAtConst = flowRateAtConst;
	}

	public String getStartedBy() {
		return startedBy;
	}

	public void setStartedBy(String startedBy) {
		this.startedBy = startedBy;
	}

	public String getStartedByName() {
		return startedByName;
	}

	public void setStartedByName(String startedByName) {
		this.startedByName = startedByName;
	}

	public String getStartedByFullName() {
		return startedByFullName;
	}

	public void setStartedByFullName(String startedByFullName) {
		this.startedByFullName = startedByFullName;
	}

	public Date getArchiveDate() {
		if (archiveDate == null) {
			return null;
		}
		return archiveDate;
	}

	public void setArchiveDate(Date archiveDate) {
		this.archiveDate = archiveDate;
	}

	public Date getCompleteDate() {
		if (completeDate == null) {
			return null;
		}
		return completeDate;
	}

	public void setCompleteDate(Date completeDate) {
		this.completeDate = completeDate;
	}

	public String getActualTestPressure() {
		return actualTestPressure;
	}

	public void setActualTestPressure(String actualTestPressure) {
		this.actualTestPressure = actualTestPressure;
	}

	public String getSystemSize() {
		return systemSize;
	}

	public void setSystemSize(String systemSize) {
		this.systemSize = systemSize;
	}

	public String getSizeAtTemperature() {
		return sizeAtTemperature;
	}

	public void setSizeAtTemperature(String sizeAtTemperature) {
		this.sizeAtTemperature = sizeAtTemperature;
	}

	public String getSelfCheckPassed() {
		return selfCheckPassed;
	}

	public void setSelfCheckPassed(String selfCheckPassed) {
		this.selfCheckPassed = selfCheckPassed;
	}

	public String getFilterSize() {
		return filterSize;
	}

	public void setFilterSize(String filterSize) {
		this.filterSize = filterSize;
	}

	public String getCalibrationOverdue() {
		return calibrationOverdue;
	}

	public void setCalibrationOverdue(String calibrationOverdue) {
		this.calibrationOverdue = calibrationOverdue;
	}

	public Date getLastCalibrationDate() {
		if (lastCalibrationDate == null) {
			return null;
		}
		return lastCalibrationDate;
	}

	public void setLastCalibrationDate(Date lastCalibrationDate) {
		this.lastCalibrationDate = lastCalibrationDate;
	}

	public String getNumOfRounds() {
		return numOfRounds;
	}

	public void setNumOfRounds(String numOfRounds) {
		this.numOfRounds = numOfRounds;
	}

	public String getSignature1() {
		return signature1;
	}

	public void setSignature1(String signature1) {
		this.signature1 = signature1;
	}

	public String getSignature2() {
		return signature2;
	}

	public void setSignature2(String signature2) {
		this.signature2 = signature2;
	}

	public String getSignaturesRemaining() {
		return signaturesRemaining;
	}

	public void setSignaturesRemaining(String signaturesRemaining) {
		this.signaturesRemaining = signaturesRemaining;
	}

	public String getXmlFileName() {
		return xmlFileName;
	}

	public void setXmlFileName(String xmlFileName) {
		this.xmlFileName = xmlFileName;
	}

	public String getXmlFileNamePath() {
		return xmlFileNamePath;
	}

	public void setXmlFileNamePath(String xmlFileNamePath) {
		this.xmlFileNamePath = xmlFileNamePath;
	}

	public String getXmlAuditFileNamePath() {
		return xmlAuditFileNamePath;
	}

	public void setXmlAuditFileNamePath(String xmlAuditFileNamePath) {
		this.xmlAuditFileNamePath = xmlAuditFileNamePath;
	}

	public String getXmlAuditFileName() {
		return xmlAuditFileName;
	}

	public void setXmlAuditFileName(String xmlAuditFileName) {
		this.xmlAuditFileName = xmlAuditFileName;
	}

	public boolean getSyncFlag() {
		return syncFlag;
	}

	public void setSyncFlag(boolean syncFlag) {
		this.syncFlag = syncFlag;
	}

	public int getSyncNumber() {

		return syncNumber;
	}

	public void setSyncNumber(int syncNumber) {
		this.syncNumber = syncNumber;
	}

	public boolean getHasPdfFlag() {
		return hasPdfFlag;
	}

	public void setHasPdfFlag(boolean hasPdfFlag) {
		this.hasPdfFlag = hasPdfFlag;
	}

	public String getPdfFileNamePath() {
		return pdfFileNamePath;
	}

	public void setPdfFileNamePath(String pdfFileNamePath) {
		this.pdfFileNamePath = pdfFileNamePath;
	}

	public String getPdfFileName() {
		return pdfFileName;
	}

	public void setPdfFileName(String pdfFileName) {
		this.pdfFileName = pdfFileName;
	}

	public Date getRowCreatedTime() {
		return rowCreatedTime;
	}

	public void setRowCreatedTime(Date rowCreatedTime) {
		this.rowCreatedTime = rowCreatedTime;
	}
}