package com.tcs.mail.pojo;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("B_PROC_BATCH_COMPLETE_MAIL")
public class BatchCompleteMail {

	@TableId
	private Integer mailId;

	private String mailSender;

	private String mailFrom;

	private String mailTo;

	private String mailCc;

	private String mailBcc;

	private String mailSubject;

	private String mailBody;

	private String mailAttachment;

	private Date createDate;

	private Date sentDate;

	private String isSent;

	private Integer wrongTimes;

	private String moblieApprovalId;

	private String missMailAddress;

	public Integer getMailId() {
		return mailId;
	}

	public void setMailId(Integer mailId) {
		this.mailId = mailId;
	}

	public String getMailSender() {
		return mailSender;
	}

	public void setMailSender(String mailSender) {
		this.mailSender = mailSender;
	}

	public String getMailFrom() {
		return mailFrom;
	}

	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}

	public String getMailTo() {
		return mailTo;
	}

	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}

	public String getMailCc() {
		return mailCc;
	}

	public void setMailCc(String mailCc) {
		this.mailCc = mailCc;
	}

	public String getMailBcc() {
		return mailBcc;
	}

	public void setMailBcc(String mailBcc) {
		this.mailBcc = mailBcc;
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

	public String getMailBody() {
		return mailBody;
	}

	public void setMailBody(String mailBody) {
		this.mailBody = mailBody;
	}

	public String getMailAttachment() {
		return mailAttachment;
	}

	public void setMailAttachment(String mailAttachment) {
		this.mailAttachment = mailAttachment;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getSentDate() {
		return sentDate;
	}

	public void setSentDate(Date sentDate) {
		this.sentDate = sentDate;
	}

	public String getIsSent() {
		return isSent;
	}

	public void setIsSent(String isSent) {
		this.isSent = isSent;
	}

	public Integer getWrongTimes() {
		return wrongTimes;
	}

	public void setWrongTimes(Integer wrongTimes) {
		this.wrongTimes = wrongTimes;
	}

	public String getMoblieApprovalId() {
		return moblieApprovalId;
	}

	public void setMoblieApprovalId(String moblieApprovalId) {
		this.moblieApprovalId = moblieApprovalId;
	}

	public String getMissMailAddress() {
		return missMailAddress;
	}

	public void setMissMailAddress(String missMailAddress) {
		this.missMailAddress = missMailAddress;
	}
	
	
	
	
}
