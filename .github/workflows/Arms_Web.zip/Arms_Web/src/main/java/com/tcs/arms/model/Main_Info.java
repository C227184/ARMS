package com.tcs.arms.model;

import java.util.Date;

public class Main_Info {

	public int mainId;

	public String rowNumber;

	public String runQueueTestName;

	public String runQueueTestFilterName;

	public int runQueueInternalID;

	public String runQueueID;

	public String runQueueTMID;

	public String runQueueStatus;

	public String runQueueUITestType;

	public String runQueueCreatedDate;

	public String runQueueCreatedBy;

	public String runQueueCreatedByFullName;

	public String runQueueModifiedDate;

	public String runQueueModifiedBy;

	public String runQueueModifiedByFullName;

	public String xmlFileName;
	
	public String xmlFileNamePath;
	
    public String xmlAuditFileName;
	
	public String xmlAuditFileNamePath;

	public boolean syncFlag;

	public int syncNumber;

	public boolean hasPdfFlag;

	public String pdfFileNamePath;
	
	public String pdfFileName;

	public Date rowCreatedTime;

	public void setMainId(int mainId) {
		this.mainId = mainId;
	}

	public int getMainId() {

		return mainId;
	}

	public String getRownumber() {

		return rowNumber;
	}

	public void setRownumber(String rowNumber) {
		this.rowNumber = rowNumber;
	}

	public String getRunQueueTestName() {

		return runQueueTestName;
	}

	public void setRunQueueTestName(String runQueueTestName) {

		this.runQueueTestName = runQueueTestName;
	}

	public String getRunQueueTestFilterName() {

		return runQueueTestFilterName;
	}

	public void setRunQueueTesFiltertName(String runQueueTestFilterName) {

		this.runQueueTestFilterName = runQueueTestFilterName;
	}

	public int getRunQueueInternalID() {

		return runQueueInternalID;
	}

	public void setRunQueueInternalID(int runQueueInternalID) {

		this.runQueueInternalID = runQueueInternalID;
	}

	public String getRunQueueID() {

		return runQueueID;
	}

	public void setRunQueueID(String runQueueID) {

		this.runQueueID = runQueueID;
	}

	public String getRunQueueTMID() {

		return runQueueTMID;
	}

	public void setRunQueueTMID(String runQueueTMID) {

		this.runQueueTMID = runQueueTMID;
	}

	public String getRunQueueStatus() {

		return runQueueStatus;
	}

	public void setRunQueueStatus(String runQueueStatus) {

		this.runQueueStatus = runQueueStatus;
	}

	public String getRunQueueUITestType() {

		return runQueueUITestType;
	}

	public void setRunQueueUITestType(String runQueueUITestType) {

		this.runQueueUITestType = runQueueUITestType;
	}

	public String getRunQueueCreatedDate() {

		return runQueueCreatedDate;
	}

	public void setRunQueueCreatedDate(String runQueueCreatedDate) {

		this.runQueueCreatedDate = runQueueCreatedDate;
	}

	public String getRunQueueCreatedBy() {
		return runQueueCreatedBy;
	}

	public void setRunQueueCreatedBy(String runQueueCreatedBy) {
		this.runQueueCreatedBy = runQueueCreatedBy;
	}

	public String getRunQueueCreatedByFullName() {
		return runQueueCreatedByFullName;
	}

	public void setRunQueueCreatedByFullName(String runQueueCreatedByFullName) {
		this.runQueueCreatedByFullName = runQueueCreatedByFullName;
	}

	public String getRunQueueModifiedDate() {
		return runQueueModifiedDate;
	}

	public void setRunQueueModifiedDate(String runQueueModifiedDate) {
		this.runQueueModifiedDate = runQueueModifiedDate;
	}

	public String getRunQueueModifiedBy() {
		return runQueueModifiedBy;
	}

	public void setRunQueueModifiedBy(String runQueueModifiedBy) {
		this.runQueueModifiedBy = runQueueModifiedBy;
	}

	public String getRunQueueModifiedByFullName() {
		return runQueueModifiedByFullName;
	}

	public void setRunQueueModifiedByFullName(String runQueueModifiedByFullName) {
		this.runQueueModifiedByFullName = runQueueModifiedByFullName;
	}

	public String getXmlFileName() {
		return xmlFileName;
	}

	public void setXmlFileName(String xmlFileName) {
		this.xmlFileName = xmlFileName;
	}
	
	public String getXmlFileNamePath() {
		return xmlFileNamePath;
	}

	public void setXmlFileNamePath(String xmlFileNamePath) {
		this.xmlFileNamePath = xmlFileNamePath;
	}
	
	
	public String getXmlAuditFileNamePath() {
		return xmlAuditFileNamePath;
	}

	public void setXmlAuditFileNamePath(String xmlAuditFileNamePath) {
		this.xmlAuditFileNamePath = xmlAuditFileNamePath;
	}
	
	public String getXmlAuditFileName() {
		return xmlAuditFileName;
	}

	public void setXmlAuditFileName(String xmlAuditFileName) {
		this.xmlAuditFileName = xmlAuditFileName;
	}

	public boolean getSyncFlag() {
		return syncFlag;
	}

	public void setSyncFlag(boolean syncFlag) {
		this.syncFlag = syncFlag;
	}

	public int getSyncNumber() {

		return syncNumber;
	}

	public void setSyncNumber(int syncNumber) {
		this.syncNumber = syncNumber;
	}

	public boolean getHasPdfFlag() {
		return hasPdfFlag;
	}

	public void setHasPdfFlag(boolean hasPdfFlag) {
		this.hasPdfFlag = hasPdfFlag;
	}

	public String getPdfFileNamePath() {
		return pdfFileNamePath;
	}

	public void setPdfFileNamePath(String pdfFileNamePath) {
		this.pdfFileNamePath = pdfFileNamePath;
	}
	
	public String getPdfFileName() {
		return pdfFileName;
	}

	public void setPdfFileName(String pdfFileName) {
		this.pdfFileName = pdfFileName;
	}

	public Date getRowCreatedTime() {
		return rowCreatedTime;
	}

	public void setRowCreatedTime(Date rowCreatedTime) {
		this.rowCreatedTime = rowCreatedTime;
	}

}