package com.tcs.common.mail;

import org.apache.velocity.VelocityContext;

public interface MailContent {
	
	public abstract void setContext(VelocityContext context);
	public abstract void setTemplate(String template);
	
	public abstract String getMailTo(String mailToStr);
	public abstract String getMailBody(int type);
	
	public String getMail_from();
 
	public String getMail_sender();

	public String getMail_status();
	
	public String getMail_cc();
	
	public String getStatus();
	
	public String getMailAttachmentUrl();
}
