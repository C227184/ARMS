package com.tcs.common.utils;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.security.Key;
import io.jsonwebtoken.*;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;

public class TokenUtils {

	public static String createJWT(String username,String password,String issuer,long ttlMillis,String jwtKey) {
		
		SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
		byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(jwtKey);
		Key signingKey = new SecretKeySpec(apiKeySecretBytes, 
		                signatureAlgorithm.getJcaName());
		 //token的Header信息
        Map<String, Object> map = new HashMap<>();
        map.put("alg", "HS256");
        map.put("typ", "JWT");
        
        Map<String, Object> mapClaims = new HashMap<>();
        mapClaims.put("username", username);
        mapClaims.put("password", password);
		
		long nowMillis = System.currentTimeMillis();
		Date now = new Date(nowMillis);

		// Let's set the JWT Claims
		JwtBuilder builder = Jwts.builder().setHeader(map)
				.setId(username)
				.setIssuedAt(now)
				.setSubject(username)
				.setIssuer(issuer).setClaims(mapClaims)
				.signWith(signatureAlgorithm, signingKey);

		// if it has been specified, let's add the expiration
		if (ttlMillis >= 0) {
			long expMillis = nowMillis + ttlMillis;
			Date exp = new Date(expMillis);
			builder.setExpiration(exp);
		}

		// Builds the JWT and serializes it to a compact, URL-safe string
		return builder.compact();
	}


	 //解析token
    public static Claims parserToken(String token,String jwtKey) {
    	SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;
		byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(jwtKey);
		Key signingKey = new SecretKeySpec(apiKeySecretBytes, 
		                signatureAlgorithm.getJcaName());
				
        Claims c = Jwts.parser().setSigningKey(signingKey) 
                .parseClaimsJws(token).getBody(); //解析token
        return c;
    }
}