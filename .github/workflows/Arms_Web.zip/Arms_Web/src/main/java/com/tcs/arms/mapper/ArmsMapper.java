package com.tcs.arms.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.tcs.arms.model.AttributeControlInfo;
import com.tcs.arms.model.AuditInfo;
import com.tcs.arms.model.MainInfo;
import com.tcs.arms.model.OperationErrorLog;
import com.tcs.arms.model.OperationLog;
import com.tcs.arms.model.TableStructureInfo;
import com.tcs.arms.model.TaskSyncFilePath;
import com.tcs.arms.model.TaskSyncLog;

@Mapper
public interface ArmsMapper {

	int SaveMainInfo(MainInfo model);

	int SaveMainInfoWithSQL(MainInfo model);

	int Save_MainInfo(MainInfo model);

	int UpdateMainInfo(MainInfo model);

	int UpdateMainInfoByMainId(int mainId, boolean hasSync, int syncCount);

	int SaveAuditInfo(List<AuditInfo> list);

	int SaveAuditInfoOneByOne(AuditInfo model);

	int DeleteAuditInfo(int mainId);

	int SaveTaskSyncLog(TaskSyncLog model);

	int CountTaskSyncLog(String fileName);

	int ManualRunTask(String messageInfo);

	int SaveOperationLog(OperationLog model);

	int SaveOperationErrorLog(OperationErrorLog model);

	int Save_AttributeControlInfo(List<AttributeControlInfo> list);

	int SaveAttributeControlInfo(AttributeControlInfo model);

	int GetAttributeControlRecord(String attributeId, String tableId);

	int EditAttributeControlInfo(AttributeControlInfo model);

	int DeleteAttributeControlInfo(Integer tableId);

	MainInfo QueryMainInfo(String fileName);

	MainInfo GetMainPdfFile(int mainId);

	int SaveMainPdfFilePath(int mainId, boolean hasPdfFlag, String pdfFileName, String pdfFileNamePath);

	TaskSyncFilePath QueryTaskSyncFilePathInfo();

	int SaveFilePathInfo(TaskSyncFilePath model);

	int DeleteFilePathInfo();

	List<MainInfo> QueryMainInfoList();

	List<String> GetMainInfoWithStartBy();

	int UpdateMainInfoWithStartBy(String startedBy, String startedByName);

	List<MainInfo> SearchMainInfo(Map<String, String> params);

	List<AuditInfo> QueryAuditInfoList(Integer mainId);

	List<TaskSyncLog> QueryTaskSyncLogList(Map<String, String> params);

	List<OperationLog> QueryOperationLogList(Map<String, String> params);

	int GetOperationLogTotalCount();

	List<TableStructureInfo> QueryTableStructureInfo(String tableName);

	List<AttributeControlInfo> QueryAttributeControlInfo();

	List<AttributeControlInfo> QueryAttributeControlInfoIsActive();

}