package com.tcs.common.utils;

import java.util.List;

public class PageResult<T> {

	private Integer pageNo;

	private Integer pageSize;

	private Integer totalCount;

	private Integer totalPage;

	private Integer currPage;

	private List<T> data;

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Integer getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(Integer totalPage) {
		this.totalPage = totalPage;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public Integer getCurrPage() {
		return currPage;
	}

	public void setCurrPage(Integer currPage) {
		this.currPage = currPage;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}

	public PageResult<T> instance(List<T> list, int pageNo, int pageSize) {
		int total_Count = list.size();

		int total_Page = (int) (Math.ceil(total_Count / pageSize));

		int beginIndex = (pageNo - 1) * pageSize;
		int endIndex = (pageNo) * pageSize;
		if (endIndex > total_Count) {
			endIndex = total_Count;
		}

		int modPage = total_Count % pageSize;
		if (modPage > 0) {
			total_Page += 1;
		}

		this.data = list.subList(beginIndex, endIndex);
		this.pageNo = pageNo;
		this.currPage = pageNo;
		this.pageSize = pageSize;
		this.totalCount = total_Count;
		this.totalPage = total_Page;
		return this;
	}
	
	public PageResult<T> newPage(List<T> list, int totalCount,int pageNo, int pageSize) {
		
		int totalPage=1;
		int modPage = totalCount % pageSize;
		if (modPage > 0) {
			totalPage += 1;
		}

		this.data = list;
		this.pageNo = pageNo;
		this.currPage = pageNo;
		this.pageSize = pageSize;
		this.totalCount = totalCount;
		this.totalPage = totalPage;
		return this;
	}
}