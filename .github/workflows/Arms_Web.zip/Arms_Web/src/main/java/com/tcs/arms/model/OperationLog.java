package com.tcs.arms.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class OperationLog {

	private int operationId;

	private String operatorId;

	private String operatorName;

	private Date operateTime;

	private String operateModule;

	private String operateMethod;

	private String operateRequestParam;

	private String operateResponseParam;

	private String operateUri;

	private String operateIP;

	private String businessId;

	private String operateType;

	private String operateTypeName;

	private String operateInfo;

	public int getOperationId() {
		return operationId;
	}

	public void setOperationId(int operationId) {
		this.operationId = operationId;
	}

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorID(String operatorId) {
		this.operatorId = operatorId;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	public Date getOperateTime() {
		return operateTime;
	}

	public void setOperateTime(Date operateTime) {

		this.operateTime = operateTime;
	}

	public String getOperateModule() {
		return operateModule;
	}

	public void setOperateModule(String operateModule) {
		this.operateModule = operateModule;
	}

	public String getOperateMethod() {
		return operateMethod;
	}

	public void setOperateMethod(String operateMethod) {
		this.operateMethod = operateMethod;
	}

	public String getOperateRequestParam() {
		return operateRequestParam;
	}

	public void setOperateRequestParam(String operateRequestParam) {
		this.operateRequestParam = operateRequestParam;
	}

	public String getOperateResponseParam() {
		return operateResponseParam;
	}

	public void setOperateResponseParam(String operateResponseParam) {
		this.operateResponseParam = operateResponseParam;
	}

	public String getOperateUri() {
		return operateUri;
	}

	public void setOperateUri(String operateUri) {
		this.operateUri = operateUri;
	}

	public String getOperateIP() {
		return operateIP;
	}

	public void setOperateIP(String operateIP) {
		this.operateIP = operateIP;
	}

	public String getBusinessId() {
		return businessId;
	}

	public void setBusinessID(String businessId) {
		this.businessId = businessId;
	}

	public String getOperateType() {
		return operateType;
	}

	public void setOperateType(String operateType) {

		this.operateType = operateType;
	}

	public String getOperateTypeName() {
		return operateTypeName;
	}

	public void setOperateTypeName(String operateTypeName) {
		this.operateTypeName = operateTypeName;
	}

	public String getOperateInfo() {
		return operateInfo;
	}

	public void setOperateInfo(String operateInfo) {
		this.operateInfo = operateInfo;
	}

}