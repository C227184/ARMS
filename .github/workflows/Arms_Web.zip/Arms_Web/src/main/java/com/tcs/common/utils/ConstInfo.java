package com.tcs.common.utils;

public class ConstInfo {

    public final static String Status_Waiting_for_Confirmation = "Waiting for Confirmation";
    public final static String Status_Confirmed  = "Confirmed";
    public final static String Status_Runing  = "Runing";
    public static final String REPORT_TYPE_WARNING="Warning";
    
    public static final String Auto="Auto";
    public static final String Manual="Manual";
}
