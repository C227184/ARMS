package com.tcs.system.util;

public interface CircularConst {
	public static final String CIRCULAR_REQUEST_TYPE = "Circular";
	public static final String PROCESS_NAME_SUBCIRCULAR="LE Sub Circular";
	public static final String PROCESS_NAME_LECIRCULAR="LE Circular";
	public static final String NEW_DIS = "new";
	public static final String COPY_DIS = "copy";
	public static final String PROCESS_DIS = "process";
	public static final String COMPLETED_DIS = "completed";
	public static final String INBOX_DIS = "inbox";
	public static final String DRAFT_DIS = "draft";
	public static final String CONSULT_DIS = "consult";
	public static final String BclDate_DIS = "BclDate";
	public static final String CCC_DELEGATION_DIS = "CCCdelegation";
	public static final String PROCESS_NAME_CIRCULAR="Circular";
	public static final String STATUS_DRAFT= "Draft";
	public static final String STATUS_CANCELED = "Cancelled";
	public static final String STATUS_WAITING_FOR_APPROVAL="Waiting for Approval";
	public static final String STATUS_APPROVED="Approved";
	public static final String COMMAND_APPROVED = "Approved";
	public static final String COMMAND_WAITING_FOR_APPROVAL = "Waiting for Approval";
	public static final String COMMAND_DELETE_CIRCULAR = "Delete Circular";
	public static final String CIRCULAR_REGULATIONS_URL="U";
	public static final String CIRCULAR_REGULATIONS_FILE="F";
	public static final String COMMAND_CCCREVIEW="for CCC Review";
	public static final String ACTION_REJECTED ="rejected";
	public static final String ACTION_RETURNED ="returned";
	public static final String ACTION_APPROVED ="approved";
	public static final String ACTION_SUBMITED = "submitted";
	public static final String ACTION_CHECKED = "accepted";
	public static final String ACTION_CONFIRMED = "verified";
	public static final String ACTION_ENDORSED = "endorsed";
	public static final String ACTION_RESUBMITED = "resubmitted";
	public static final String ACTION_CANCELD = "cancelled";
	public static final String ACTION_SUBMITTED  = "submitted";
	
	
	
	public static final String STATUS_FOR_LEGAL_ADMIN_REVIEW="for Legal Consultant Reply";
	public static final String UPLOAD_FILE_NAME_FOLDER_LEGAL="legal";
	public static final String UPLOAD_FILE_NAME_FOLDER_DELEGATION="delegation";
	public static final String UPLOAD_FILE_NAME_FOLDER_NEWCIRCULAR="circular";
	public static final String UPLOAD_FILE_NAME_FOLDER_BCL_FRAMEWORK="BCL Framework";
	public static final String COMMAND_ASSIGNER_ASSIGN="Assign";
	public static final String COMMAND_NEW_CIRCULAR_SUBMIT = "Submit";
	public static final String COMMAND_CIRCULAR_RESUBMIT = "ReSubmit";
	public static final String COMMAND_LEGAL_CONSULTANT_SUBMIT="Reply";
	public static final String STATUS_FOR_ASSIGNER_REVIEW="for Assignment";
	public static final String STATUS_FOR_CIRCULAR_OWNER_REVIEW="for Circular Owner Review";
	public static final String STATUS_FOR_DELEGATION_REVIEW_OWNER="For Delegation Review(for Owner)";
	public static final String STATUS_FOR_DELEGATION_REVIEW="For Delegation Review";
	public static final String STATUS_FOR_CCC_REVIEW="for CCC Review";
	public static final String STATUS_RETURN="Returned";
	public static final String STATUS_COMPLETED="Completed";
	public static final String STATUS_FOR_CCC_REVIEW_COMPLETED="Waiting For CCC Completion";
	public static final String STATUS_FOR_LE_HEAD_REVIEW="for LE Head Review";
	public static final String COMMAND_CCC_TO_OWNER="cccToOwner";
	
	//	add by wlm
	public static final String STATUS_FOR_LEGAL_CONSULTANT_REPLY="for Legal Consultant Reply";
	public static final String STATUS_FOR_DEVELOPING_BCL_FRAMEWORK="for Developing BCL Framework";
	public static final String STATUS_FOR_CCC_TRANSFER="for CCC Transfer";
	public static String[] CIRCULAR_STATUS = { STATUS_FOR_ASSIGNER_REVIEW,STATUS_FOR_CIRCULAR_OWNER_REVIEW,STATUS_FOR_DELEGATION_REVIEW,STATUS_FOR_LE_HEAD_REVIEW 
		,STATUS_FOR_CCC_REVIEW,STATUS_FOR_LEGAL_CONSULTANT_REPLY,STATUS_FOR_DEVELOPING_BCL_FRAMEWORK
		,STATUS_COMPLETED,STATUS_FOR_CCC_TRANSFER,"Waiting for MD Approval","Rejected"};
	 
	public static final String COMMAND_DELEGATION_SIGN_OFF="Sign Off For Delegation";
	public static final String COMMAND_CIRCULAR_SIGN_OFF_OWNER="Sign Off For Owner";
	public static final String COMMAND_CIRCULAR_OWNER_TRANSFER_OUT="LE Transfer Out";
	public static final String COMMAND_CIRCULAR_SIGN_OFF="Sign Off";
	public static final String COMMAND_CIRCULAR_SIGN_OFF_DELEGATION="Sign Off For Delegation";
	public static final String COMMAND_CIRCULAR_SAVE_OWNER="Save For Owner";
	public static final String CIRCULAR_CATEGORY_BCL="BCL Framework";
	public static final String CIRCULAR_PROCESS_PARTICIPANT_APPLICANT="ccc";
	public static final String CIRCULAR_PROCESS_PARTICIPANT_APPLICANT_REQUWSTER="requester";
	public static final String COMMAND_LE_HEAD_REVIEW="LE Head Review For Completed";
	public static final String COMMAND_ASSIGNER_RETURN="Assigner Return";
	public static final String COMMAND_NEW_SUB_CIRCULAR_SUBMIT = "Submit";
	public static final String COMMAND_CONSULT_SAVE="Consult";
	public static final String COMMAND_Develop_BCL_Framework="Develop BCL Framework";
	public static final String  CIRCULAR_ROLE_LEGAL ="legal_consultant";
	public static final String PROCESS_CIRCULAR_REDIRECT="action_result";
	public static final String  PROCESS_CIRCULAR_CONSULT ="consultted";
	public static final String  PROCESS_CIRCULAR_DEV_BCL = "develop_bcl_framework";
	public static final String  PROCESS_CIRCULAR_LE_COMPLETED = "le_completed";
	public static final String COMMAND_OWNER_RETURN_TO_C="Owner Return To CCC";
	public static final String COMMAND_OWNER_RETURN_TO_ASSIGNER="Owner Return To Assigner";
	public static final String COMMAND_RETURN="Return";
	public static final String COMMAND_COMPLETE="Complete";
	public static final String   COMMAND_CIRCULAR_SAVEASDRAFT = "Save circular as draft"	; 
	public static final String   COMMAND_CIRCULAR_SUBMIT = "Submit circular to CCC "	; 
	public static final String COMMAND_CIRCULAR_OWNER_ACCEPT="Accept";
	public static final String COMMAND_CIRCULAR_COMPLETE="Complete";
	public static final String COMMAND_CIRCULAR_NOT_APPLY_FOR_CHINA_DRAFT="saveAsDraftNotForChina";
	public static final String COMMAND_CIRCULAR_APPLY_FOR_CHINA_DRAFT="saveAsDraftForChina";
	
	public static final String COMMAND_CIRCULAR_COMPLETE_ACTION="completed";
	public static final String  NOT_APPLY_FOR_CHINA_Y="Y";
	public static final String  NOT_APPLY_FOR_CHINA_N="N";
	public static final String  IS_ASSIGN_Y="Y";
	public static final String  IS_ASSIGN_N="N";
	public static final String COMMAND_CIRCULAR_TRANSFER_OUT="Transfer Out";
	public static final String  PROCESS_CIRCULAR_TRANSFER_OUT = "transfer_out";
	public static final String  PROCESS_CIRCULAR_ASSIGNER_N = "not_need_assigner";
	public static final String  PROCESS_CIRCULAR_ASSIGNER_Y = "need_assigner";
	public static String[] IN_PROCESS_STATUS = {STATUS_FOR_CCC_REVIEW,STATUS_RETURN,STATUS_FOR_DEVELOPING_BCL_FRAMEWORK,STATUS_FOR_LEGAL_ADMIN_REVIEW};
	public static String[] COMPLETED_STATUS = {STATUS_COMPLETED};
	public static String[] DRAFT_STATUS = { STATUS_DRAFT };
	public static final String LECIRCULAR_PROCESS_PARTICIPANT_OWNER = "owner";
	public static final String LECIRCULAR_PROCESS_PARTICIPANT_ASSIGNER = "assigner";
	
	public static final String PROCESS_CIRCULAR_REDIRECT_REPLIED = "replied";
	public static final String PROCESS_CIRCULAR_REDIRECT_ASSIGNED = "assigned";
	public static final String PROCESS_CIRCULAR_RETURN = "Return";
	public static final String  PROCESS_CIRCULAR_RETURNED = "returned";
	public static final String PROCESS_CIRCULAR_REDIRECT_COMPLETED = "completed";
	public static final String PROCESS_CIRCULAR_REDIRECT_SIGN_OFF = "sign_off";
	public static final String PROCESS_CIRCULAR_REDIRECT_LE_HEADER = "le_header";
	public static final String COMMAND_TRANSFER_IN="Transfer In";
	public static final String PROCESS_CIRCULAR_REDIRECT_TRANSFER_IN = "transfer_in";
	public static final String PROCESS_CIRCULAR_REDIRECT_TRANSFER_OUT = "transfer_out";
	public static final String PROCESS_CIRCULAR_REDIRECT_DELEGATION = "delegation";
	
	public static final String COMMAND_CIRCULAR_SIGN_OFF_DELEGATION_OF_OWNER="Sign Off For Delegation Of Owner";
	
	public static final String COMMAND_LEGAL_CONSULTANT_FORWARD="Forward";
	public static final String PROCESS_CIRCULAR_REDIRECT_FORWARDED = "forwarded";
	public static final String COMMAND_CANCEL="Cancel";
	public static final String STATIC_CIRCULAR_CANCELLED="Cancelled";
	public static String[] REPORT_STATUS = {STATUS_FOR_CCC_REVIEW_COMPLETED,COMMAND_CCCREVIEW,STATUS_FOR_LEGAL_ADMIN_REVIEW,STATUS_RETURN,STATUS_FOR_CCC_TRANSFER,STATUS_FOR_DEVELOPING_BCL_FRAMEWORK,STATUS_COMPLETED};
	public static final String MAIL_CIRCULAR_NEW="New Circular Request";
	public static final String BASIC_CIRCULAR_STAUAS_VALID="Valid";
	public static final String BASIC_CIRCULAR_STAUAS_DELETED="Deleted";
	public static final String BASIC_CIRCULAR_STAUAS_OBSOLETE="Obsolete";
	
	public static final String COMMAND_CIRCULAR_ACCEPT_OWNER="Accept For Owner";
	public static final String DelegationRemark="Align with regulation";
	public static final String RESPONSIBILITY="Ensure the Circular is appropriately implemented in the legal entity";
	public static final String CATEGORY_BMS_GROUP = "BMS Group";  
    public static final String PROPERTY_FOLDER_KEY_NAME = "appl.props.path"; 
    public static final String SUMMARY_REPORT_FOLDER = "Circular Summary Report Template";
    public static final String CATEGORY_GROUP = "Group";
    public static final String ACTION_CCC_SEND_TO_LE = "send";
    public static final String COMMAND_OWNER_SIGNOFF = "Transfer Out"; 
    public static final String COMMAND_OWNER_SIGNOFF_CONDITION = "owner_sign_off"; 
	public static final String COMMAND_LEHEAD_RETURN="Return";
	public static final String COMMAND_LEHEAD_RETURN_ACTIVITY="LEHeadReturn";
	public static final String COMMAND_CCC_REVIEW_COMPLETE="CCCReviewComplete";
	public static final String LOCAL_FRAMEWORK_CATEGORY="Circular_Local_FrameWork_Category";
	public static final String MIGRATION_DATA_FOLDER = "Circular Export Migration Template";
	public static final String DROP_DOWN_CIRCULAR_CATEGORY = "CIRCULAR_CATEGORY";
	public static final String SUBGROUP_CIRCULAR_CATEGORY = "Subgroup";
	public static final String COMMAND_CCC_TO_Responsible_Person="cccToResponsiblePerson";
	public static final String COMMAND_Le_Head_TO_CCC="LeHeadToCCC";
	public static final String COMMAND_CCC_TO_ICS="cccToICS";
	public static final String COMMAND_CCC_TO_ICS_TWO="cccToICSTwo";
	public static final String COMMAND_CCC_TO_ICS_THREE="cccToICSThree";
	public static final String NO_DELEGATE = "no delegation";
	public static final String NEED_DELEGATE = "need delegation";
	public static final String COMMAND_CCC_TO_Dategate="cccToDelegate";
	public static final String COMMAND_Back_TO_CCC="backToCCC";
}