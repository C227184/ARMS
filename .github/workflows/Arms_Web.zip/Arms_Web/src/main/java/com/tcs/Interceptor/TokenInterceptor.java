package com.tcs.Interceptor;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Component
public class TokenInterceptor implements HandlerInterceptor {
	// 处理请求之前执行
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		String requestURI = request.getRequestURI();

		if (requestURI.contains("/login")) {
			return true;
		}
		request.setCharacterEncoding("UTF-8");
		//PrintWriter resultWriter = response.getWriter();
		try {
			String token = request.getHeader("Token");
			// String requestToken = request.getHeader("Authorization");
			if (token == null || token == "") {
				response.setStatus(403);
				return false;
			}
			return true;
		} catch (Exception ex) {
			response.setStatus(500);
			return false;
		}
	}
}