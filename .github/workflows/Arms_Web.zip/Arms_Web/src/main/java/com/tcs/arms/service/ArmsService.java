package com.tcs.arms.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.sl.usermodel.VerticalAlignment;
import org.apache.poi.ss.formula.functions.T;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.csvreader.CsvWriter;
import com.tcs.common.utils.ConstInfo;
import com.tcs.common.utils.DateUtils;
import com.tcs.common.utils.IPUtils;
import com.tcs.common.utils.PageUtils;
import com.tcs.arms.mapper.ArmsMapper;
import com.tcs.arms.model.AttributeControlInfo;
import com.tcs.arms.model.AuditInfo;
import com.tcs.arms.model.MainInfo;
import com.tcs.arms.model.OperationErrorLog;
import com.tcs.arms.model.OperationLog;
import com.tcs.arms.model.TableStructureInfo;
import com.tcs.arms.model.TaskSyncFilePath;
import com.tcs.arms.model.TaskSyncLog;
import com.tcs.system.model.PageResult;
import com.tcs.system.model.Result;
import com.tcs.system.util.StringUtils;

/*
 * 文件名：ArmsController.java
 * 描述：ARMS System
 * 作者：Haijun Huang
 * 创建时间：2023-06-01
*/

@Service
public class ArmsService {

	@Autowired
	ArmsMapper armsMappper;

	@Value("${arms.filterFields}")
	private String filterFields;

	@Value("${arms.baseTargetPath}")
	private String baseTargetPath;

	/*
	 * Add Source Three Path 描述：ARMS System 作者：Haijun Huang 创建时间：2023-07-05
	 */
	@Value("${arms.baseSourceCPath}")
	private String baseSourceCPath;

	public int SaveMainInfo(MainInfo model) {
		return armsMappper.Save_MainInfo(model);
	}

	public int SaveMainInfoWithSQL(MainInfo model) {
		return armsMappper.SaveMainInfoWithSQL(model);
	}

	public int UpdateMainInfo(MainInfo model) {
		return armsMappper.UpdateMainInfo(model);
	}

	public int UpdateMainInfoByMainId(int mainId, boolean hasSync, int syncCount) {
		return armsMappper.UpdateMainInfoByMainId(mainId, hasSync, syncCount);
	}

	public int SaveAuditInfo(List<AuditInfo> list) {
		return armsMappper.SaveAuditInfo(list);
	}

	public int SaveAuditInfoOneByOne(AuditInfo model) {
		return armsMappper.SaveAuditInfoOneByOne(model);
	}

	public int DeleteAuditInfo(int mainId) {
		return armsMappper.DeleteAuditInfo(mainId);
	}

	public int SaveTaskSyncLog(TaskSyncLog model) {
		return armsMappper.SaveTaskSyncLog(model);
	}

	public int CountTaskSyncLog(String fileName) {
		return armsMappper.CountTaskSyncLog(fileName);
	}

	public int SaveOperationLog(OperationLog model) {
		return armsMappper.SaveOperationLog(model);
	}

	public int SaveOperationErrorLog(OperationErrorLog model) {
		return armsMappper.SaveOperationErrorLog(model);
	}

	public int SaveOperationLogInfo(HttpServletRequest request, String operateType, String message) {

		OperationLog operationLog = new OperationLog();
		operationLog.setOperateIP(IPUtils.getIpAddr(request));
		// 请求URI
		operationLog.setOperateUri(request.getRequestURI());

		operationLog.setOperateTime(new Date());

		String UserId = "SystemAdmin";
		String UserName = "SystemAdmin";
		HttpSession session = request.getSession();
		if (session != null) {
			if (session.getAttribute("UserId") != null) {
				UserId = session.getAttribute("UserId").toString();
			}
			if (session.getAttribute("UserName") != null) {
				UserName = session.getAttribute("UserName").toString();
			}
		}

		operationLog.setOperatorID(UserId);
		operationLog.setOperatorName(UserName);

		operationLog.setOperateType(operateType);

		operationLog.setOperateInfo(message);

		return armsMappper.SaveOperationLog(operationLog);

	}

	public MainInfo QueryMainInfo(String fileName) {
		return armsMappper.QueryMainInfo(fileName);
	}

	public List<MainInfo> QueryMainInfoList() {
		return armsMappper.QueryMainInfoList();
	}

	public List<MainInfo> SearchMainInfo(Map<String, String> params) {
		List<MainInfo> listRecord = armsMappper.SearchMainInfo(params);
		return listRecord;
	}

	public List<MainInfo> Search_MainInfo(Map<String, String> params) {
		MainInfo model = new MainInfo();
		Field[] tt = model.getClass().getDeclaredFields();
		try {
			for (Field field : tt) {
				String name = field.getName();
				if (params.containsKey(name)) {
					String value = params.get(field.getName());
					field.set(model, value);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return armsMappper.SearchMainInfo(params);
	}

	public List<String> GetMainInfoWithStartBy() {
		return armsMappper.GetMainInfoWithStartBy();
	}

	public int UpdateMainInfoWithStartBy(String startedBy, String startedByName) {
		return armsMappper.UpdateMainInfoWithStartBy(startedBy, startedByName);
	}

	public List<AuditInfo> QueryAuditInfoList(Integer mainId) {
		return armsMappper.QueryAuditInfoList(mainId);
	}

	public List<TaskSyncLog> QueryTaskSyncLogList(Map<String, String> params) {
		return armsMappper.QueryTaskSyncLogList(params);
	}

	public List<OperationLog> QueryOperationLogList(Map<String, String> params) {
		return armsMappper.QueryOperationLogList(params);
	}

	public int GetOperationLogTotalCount() {
		return armsMappper.GetOperationLogTotalCount();
	}

	public int ManualRunTask(String messageInfo) {
		return 1;
	}

	public List<TableStructureInfo> QueryTableStructureInfo(String tableName) {
		// Compare to list
		List<TableStructureInfo> reList = new ArrayList<TableStructureInfo>();

		List<TableStructureInfo> allList = armsMappper.QueryTableStructureInfo(tableName);

		String[] arrayFilter = filterFields.split(",");

		for (String tt : arrayFilter) {
			String filedName1 = tt.toString();
			for (TableStructureInfo item : allList) {
				String filedName2 = item.getColumnName().toString();
				boolean result = filedName1.equalsIgnoreCase(filedName2);
				if (result == true) {
					reList.add(item);
				}
			}
		}

		return reList;
	}

	public List<AttributeControlInfo> QueryAttributeControlInfo() {
		return armsMappper.QueryAttributeControlInfo();
	}

	public List<AttributeControlInfo> QueryAttributeControlInfoIsActive() {
		return armsMappper.QueryAttributeControlInfoIsActive();
	}

	public int Save_AttributeControlInfo(List<AttributeControlInfo> list) {
		// armsMappper.DeleteAttributeControlInfo(list[0]);
		return armsMappper.Save_AttributeControlInfo(list);
	}

	public int SaveAttributeControlInfo(AttributeControlInfo model) {
		return armsMappper.SaveAttributeControlInfo(model);
	}

	public int EditAttributeControlInfo(AttributeControlInfo model) {
		return armsMappper.EditAttributeControlInfo(model);
	}

	public int DeleteAttributeControlInfo(Integer id) {
		return armsMappper.DeleteAttributeControlInfo(id);
	}

	public int GetAttributeControlRecord(String attributeId, String tableId) {
		return armsMappper.GetAttributeControlRecord(attributeId, tableId);
	}

	public int SaveTaskSyncFilePath(TaskSyncFilePath model) {
		int result = armsMappper.DeleteFilePathInfo();
		// 保存日志
		return armsMappper.SaveFilePathInfo(model);
	}

	public TaskSyncFilePath QueryTaskSyncFilePathInfo() {
		return armsMappper.QueryTaskSyncFilePathInfo();
	}

	public void GetMainPdfFile(HttpServletRequest request, HttpServletResponse response, Integer mainId) {
		try {

			MainInfo model = armsMappper.GetMainPdfFile(mainId);
			if (model == null) {
				return;
			}

			String pdfFilePath = "";
			if (model.getPdfFileNamePath() != null) {
				pdfFilePath = model.getPdfFileNamePath();
			}

			// 目标文件不存在，需要从服务器重新拉取
			File sourcePdf = new File(pdfFilePath);
			if (!sourcePdf.exists()) {
				TaskSyncFilePath filePathModel = armsMappper.QueryTaskSyncFilePathInfo();
				if (filePathModel == null) // 文件路径未初始化
					return;

				// 根文件夹
				String baseSourceAPath = filePathModel.getSourceAPath();
				String baseSourceBPath = filePathModel.getSourceBPath();
				if (baseSourceAPath != null) {
					baseSourceAPath = baseSourceAPath.trim();
				}
				if (baseSourceBPath != null) {
					baseSourceBPath = baseSourceBPath.trim();
				}

				String pdfFileName = model.getPdfFileName();
				if (pdfFileName == null) {
					pdfFileName = model.getXmlFileName().toString().trim().replace(".xml", ".pdf");
				} else {
					if (pdfFileName == "") {
						pdfFileName = model.getXmlFileName().toString().trim().replace(".xml", ".pdf");
					}
				}
				String baseSourceAPdf = baseSourceAPath + "\\" + pdfFileName;
				String baseSourceBPdf = baseSourceBPath + "\\" + pdfFileName;
				String baseSourceCPdf = baseSourceCPath + "\\" + pdfFileName;

				// Completed文件夹
				String baseSourceACompletedPdf = baseSourceAPath + "\\Completed\\" + pdfFileName;
				String baseSourceBCompletedPdf = baseSourceBPath + "\\Completed\\" + pdfFileName;

				String fileNameWithNoExtension = pdfFileName.replace(".pdf", "").replace(".PDF", "");
				String dirTargetDirectoryWithFileName = baseTargetPath + "\\" + fileNameWithNoExtension;
				String fullTargetFileName = dirTargetDirectoryWithFileName + "\\" + pdfFileName;

				File targetDirectory = new File(dirTargetDirectoryWithFileName); // 目录
				if (!targetDirectory.exists()) {
					targetDirectory.mkdirs();
				}

				// 從baseSourceAPdf拉取Pdf
				File sourceAPdf = new File(baseSourceAPdf);
				if (sourceAPdf.exists()) { // Copy File
					copyFile(sourceAPdf, new File(fullTargetFileName));
					pdfFilePath = fullTargetFileName;
				}

				// 從baseSourceACompletedPdf拉取Pdf
				File sourceACompletedPdf = new File(baseSourceACompletedPdf);
				if (sourceACompletedPdf.exists()) { // Copy File
					copyFile(sourceACompletedPdf, new File(fullTargetFileName));
					pdfFilePath = fullTargetFileName;
				}

				// 從baseSourceBPdf拉取Pdf
				File sourceBPdf = new File(baseSourceBPdf);
				if (sourceBPdf.exists()) { // Copy File
					copyFile(sourceBPdf, new File(fullTargetFileName));
					pdfFilePath = fullTargetFileName;
				}

				// 從baseSourceBCompletedPdf拉取Pdf
				File sourceBCompletedPdf = new File(baseSourceBCompletedPdf);
				if (sourceBCompletedPdf.exists()) { // Copy File
					copyFile(sourceBCompletedPdf, new File(fullTargetFileName));
					pdfFilePath = fullTargetFileName;
				}

				// 從baseSourceCPdf拉取Pdf
				File sourceCPdf = new File(baseSourceCPdf);
				if (sourceCPdf.exists()) { // Copy File
					copyFile(sourceCPdf, new File(fullTargetFileName));
					pdfFilePath = fullTargetFileName;
				}

				// Update Target PDFPath Filed
				// boolean hasPdfFlag = model.getHasPdfFlag();
				if (model.getPdfFileNamePath() == null) {
					if (pdfFilePath != "") {
						armsMappper.SaveMainPdfFilePath(mainId, true, pdfFileName, pdfFilePath);
					}
				}
			}

			downLoadPdf(response, pdfFilePath);

		} catch (Exception ex) {
			System.out.println(ex.getMessage().toString());
		}
	}

	private static void copyFile(File sourceFile, File targetFile) {
		if (!sourceFile.canRead()) {
			System.out.println("源文件" + sourceFile.getAbsolutePath() + "不可读，无法复制！");
			return;
		} else {
			// System.out.println("开始复制文件" + sourceFile.getAbsolutePath() + "到" +
			// targetFile.getAbsolutePath());
			FileInputStream fis = null;
			BufferedInputStream bis = null;
			FileOutputStream fos = null;
			BufferedOutputStream bos = null;

			try {
				fis = new FileInputStream(sourceFile);
				bis = new BufferedInputStream(fis);
				fos = new FileOutputStream(targetFile);
				bos = new BufferedOutputStream(fos);
				int len = 0;
				while ((len = bis.read()) != -1) {
					bos.write(len);
				}
				bos.flush();

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					if (fis != null) {
						fis.close();
					}
					if (bis != null) {
						bis.close();
					}
					if (fos != null) {
						fos.close();
					}
					if (bos != null) {
						bos.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void downLoadPdf(HttpServletResponse response, String filePath) {
		ServletOutputStream out;
		BufferedInputStream buf;
		try {
			String FileName = filePath.substring(filePath.lastIndexOf("/") + 1);
			response.setContentType("multipart/form-data");
			response.setHeader("Content-Disposition", "inline;fileName=" + FileName);

			FileInputStream inputStream = new FileInputStream(filePath);

			// 使用输入读取缓冲流读取一个文件输入流
			buf = new BufferedInputStream(inputStream);
			// 利用response获取一个字节流输出对象
			out = response.getOutputStream();
			// 定义个数组，由于读取缓冲流中的内容
			byte[] buffer = new byte[1024];
			int n;
			// while循环一直读取缓冲流中的内容到输出的对象中
			while ((n = buf.read(buffer)) != -1) {
				out.write(buffer, 0, n);
			}

			out.flush();
			buf.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void exportMainInfoToExcel(HttpServletResponse response, @RequestBody Map<String, String> params)
			throws Exception {
		// 1.创建工作薄
		HSSFWorkbook workbook = new HSSFWorkbook();
		// 2.创建工作表
		HSSFSheet sheet = workbook.createSheet("arms System");

		HSSFCellStyle style = workbook.createCellStyle();

		// 水平居中
		style.setAlignment(HorizontalAlignment.CENTER);
		// 3.创建行
		// 首先创建第一行
		HSSFRow row = sheet.createRow(0);
		// 创建第一行的单元格
		HSSFCell rowCell0 = row.createCell(0);
		rowCell0.setCellStyle(style);
		rowCell0.setCellValue("Batch ID");
		sheet.setColumnWidth(0, 20 * 256);

		HSSFCell rowCell1 = row.createCell(1);
		rowCell1.setCellStyle(style);
		rowCell1.setCellValue("Test Name");
		sheet.setColumnWidth(1, 25 * 256);

		HSSFCell rowCell2 = row.createCell(2);
		rowCell2.setCellStyle(style);
		rowCell2.setCellValue("Test Passed");
		sheet.setColumnWidth(2, 20 * 256);

		HSSFCell rowCell3 = row.createCell(3);
		rowCell3.setCellStyle(style);
		rowCell3.setCellValue("Test Description");
		sheet.setColumnWidth(3, 35 * 256);

		HSSFCell rowCell4 = row.createCell(4);
		rowCell4.setCellStyle(style);
		rowCell4.setCellValue("Run Notes");
		sheet.setColumnWidth(4, 30 * 256);

		HSSFCell rowCell5 = row.createCell(5);
		rowCell5.setCellStyle(style);
		rowCell5.setCellValue("Started By");
		sheet.setColumnWidth(5, 30 * 256);

		HSSFCell rowCell6 = row.createCell(6);
		rowCell6.setCellStyle(style);
		rowCell6.setCellValue("Start Date");
		sheet.setColumnWidth(6, 30 * 256);

		HSSFCell rowCell7 = row.createCell(7);
		rowCell7.setCellStyle(style);
		rowCell7.setCellValue("Instrument Serial Number");
		sheet.setColumnWidth(7, 30 * 256);

		HSSFCell rowCell8 = row.createCell(8);
		rowCell8.setCellStyle(style);
		rowCell8.setCellValue("Flow Rate");
		sheet.setColumnWidth(8, 20 * 256);

		HSSFCell rowCell9 = row.createCell(9);
		rowCell9.setCellStyle(style);
		rowCell9.setCellValue("Flow Rate At Const");
		sheet.setColumnWidth(9, 20 * 256);

		HSSFCell rowCell10 = row.createCell(10);
		rowCell10.setCellStyle(style);
		rowCell10.setCellValue("Archive Date");
		sheet.setColumnWidth(10, 20 * 256);

		HSSFCell rowCell11 = row.createCell(11);
		rowCell11.setCellStyle(style);
		rowCell11.setCellValue("Actual Test Pressure");
		sheet.setColumnWidth(11, 20 * 256);

		HSSFCell rowCell12 = row.createCell(12);
		rowCell12.setCellStyle(style);
		rowCell12.setCellValue("System Size");
		sheet.setColumnWidth(12, 20 * 256);

		HSSFCell rowCell13 = row.createCell(13);
		rowCell13.setCellStyle(style);
		rowCell13.setCellValue("Size At Temperature");
		sheet.setColumnWidth(13, 20 * 256);

		HSSFCell rowCell14 = row.createCell(14);
		rowCell14.setCellStyle(style);
		rowCell14.setCellValue("Self Check Passed");
		sheet.setColumnWidth(14, 20 * 256);

		HSSFCell rowCell15 = row.createCell(15);
		rowCell15.setCellStyle(style);
		rowCell15.setCellValue("Filter Size");
		sheet.setColumnWidth(15, 20 * 256);

		HSSFCell rowCell16 = row.createCell(16);
		rowCell16.setCellStyle(style);
		rowCell16.setCellValue("Number Of Rounds");
		sheet.setColumnWidth(16, 20 * 256);

		HSSFCell rowCell17 = row.createCell(17);
		rowCell17.setCellStyle(style);
		rowCell17.setCellValue("Last Calibration Date");
		sheet.setColumnWidth(17, 35 * 256);

		HSSFCell rowCell18 = row.createCell(18);
		rowCell18.setCellStyle(style);
		rowCell18.setCellValue("Calibration OverDue");
		sheet.setColumnWidth(18, 20 * 256);

		HSSFCell rowCell19 = row.createCell(19);
		rowCell19.setCellStyle(style);
		rowCell19.setCellValue("Sync Flag");
		sheet.setColumnWidth(19, 15 * 256);

		HSSFCell rowCell20 = row.createCell(20);
		rowCell20.setCellStyle(style);
		rowCell20.setCellValue("File Name");
		sheet.setColumnWidth(20, 50 * 256);

		HSSFCell rowCell21 = row.createCell(21);
		rowCell21.setCellStyle(style);
		rowCell21.setCellValue("Create Time");
		sheet.setColumnWidth(21, 30 * 256);

		HSSFCell rowCell22 = row.createCell(22);
		rowCell22.setCellStyle(style);
		rowCell22.setCellValue("Complete Date");
		sheet.setColumnWidth(22, 30 * 256);

		HSSFCellStyle cellStyle = workbook.createCellStyle();
		// 水平居中
		cellStyle.setAlignment(HorizontalAlignment.CENTER);

		HSSFCellStyle cellLeftStyle = workbook.createCellStyle();
		cellLeftStyle.setAlignment(HorizontalAlignment.LEFT);

		try {

			List<MainInfo> list = armsMappper.SearchMainInfo(params);
			// 遍历集合，写数据到excel表上
			for (int i = 0; i < list.size(); i++) {
				MainInfo model = list.get(i);
				// 创建excel的行,由于第一行已经创建过，所以这里从 索引为i+1的开始
				HSSFRow sheetRow = sheet.createRow(i + 1);

				for (int g = 0; g < 23; g++) {
					HSSFCell cell = sheetRow.createCell(g);
					cell.setCellStyle(cellStyle);
					if (g == 0) {
						cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getBatchId().toString());
					} else if (g == 1) {
						cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getTestName());
					} else if (g == 2) {
						String Value = "";
						String testPassed = model.getTestPassed();
						// System.out.println(testPassed);
						if (testPassed.equals("0"))
							Value = "FAILED";
						if (testPassed.equals("2"))
							Value = "INVALID";
						if (testPassed.equals("1"))
							Value = "PASSED";
						if (testPassed.equals("99"))
							Value = "NULL";

						if (Value != "") {
							cell.setCellValue(Value);
						}
					} else if (g == 3) {
						cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getTestDescription());
					} else if (g == 4) {
						cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getRunNotes());
					} else if (g == 5) {
						cell.setCellStyle(cellLeftStyle);
						String startedBy = model.getStartedBy();
						String startedByName = model.getStartedByName();
						if (startedByName != null && startedByName.length() > 0) {
							cell.setCellValue(startedBy + "-" + startedByName);
						} else {
							cell.setCellValue(startedBy);
						}

					} else if (g == 6) {
						cell.setCellStyle(cellLeftStyle);
						if (model.getStartDate() != null) {
							String startTime = DateUtils.format(model.getStartDate(), "yyyy-MM-dd HH:mm:ss");
							cell.setCellValue(startTime);
						}
					} else if (g == 7) {
						cell.setCellValue(model.getInstrumentSerialNumber());
					} else if (g == 8) {
						cell.setCellValue(model.getFlowrate());
					} else if (g == 9) {
						cell.setCellValue(model.getFlowRateAtConst());
					} else if (g == 10) {
						cell.setCellStyle(cellLeftStyle);
						if (model.getArchiveDate() != null) {
							String archiveTime = DateUtils.format(model.getArchiveDate(), "yyyy-MM-dd HH:mm:ss");
							cell.setCellValue(archiveTime);
						}
					} else if (g == 11) {
						cell.setCellValue(model.getActualTestPressure());
					} else if (g == 12) {
						cell.setCellValue(model.getSystemSize());
					} else if (g == 13) {
						cell.setCellValue(model.getSizeAtTemperature());
					} else if (g == 14) {
						String Value = "";
						String selfCheckPassed = model.getSelfCheckPassed();
						// System.out.println(selfCheckPassed);
						if (selfCheckPassed.equals("0"))
							Value = "FAILED";
						if (selfCheckPassed.equals("2"))
							Value = "INVALID";
						if (selfCheckPassed.equals("1"))
							Value = "PASSED";
						if (selfCheckPassed.equals("99"))
							Value = "NULL";

						if (Value != "") {
							cell.setCellValue(Value);
						}
					} else if (g == 15) {
						cell.setCellValue(model.getFilterSize());
					} else if (g == 16) {
						cell.setCellValue(model.getNumOfRounds());
					} else if (g == 17) {
						cell.setCellStyle(cellLeftStyle);
						if (model.getLastCalibrationDate() != null) {
							String calTime = DateUtils.format(model.getLastCalibrationDate(), "yyyy-MM-dd HH:mm:ss");
							cell.setCellValue(calTime);
						}
						// cell.setCellValue(model.getLastCalibrationDate());
					} else if (g == 18) {
						cell.setCellValue(model.getCalibrationOverdue());
					} else if (g == 19) {
						cell.setCellValue(model.getSyncFlag());
					} else if (g == 20) {
						cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getXmlFileName());
					} else if (g == 21) {
						cell.setCellStyle(cellLeftStyle);
						if (model.getRowCreatedTime() != null) {
							String rowTime = DateUtils.format(model.getRowCreatedTime(), "yyyy-MM-dd HH:mm:ss");
							cell.setCellValue(rowTime);
						}
					} else if (g == 22) {
						cell.setCellStyle(cellLeftStyle);
						if (model.getCompleteDate() != null) {
							String rowTime = DateUtils.format(model.getCompleteDate(), "yyyy-MM-dd HH:mm:ss");
							cell.setCellValue(rowTime);
						}
					} else {
					}
				}
			}

			long millis = System.currentTimeMillis();
			String FileName = StringUtils.DateToYMDHMS(new Date(millis)).replaceAll(":", "-") + ".xls";
			response.setContentType("multipart/form-data");
			response.setHeader("Content-Disposition", "inline;fileName=" + FileName);

			ServletOutputStream out = response.getOutputStream();
			out = response.getOutputStream();

			workbook.write(out);

			// 刷新释放资源
			out.flush();
			out.close();
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void exportAuditInfoToExcel(HttpServletResponse response, Integer mainId) throws Exception {
		// 1.创建工作薄
		HSSFWorkbook workbook = new HSSFWorkbook();
		// 2.创建工作表
		HSSFSheet sheet = workbook.createSheet("AuditInfo");

		HSSFCellStyle style = workbook.createCellStyle();

		// 水平居中
		style.setAlignment(HorizontalAlignment.CENTER);
		// 3.创建行
		// 首先创建第一行
		HSSFRow row = sheet.createRow(0);
		// 创建第一行的单元格
		HSSFCell rowCell0 = row.createCell(0);
		rowCell0.setCellStyle(style);
		rowCell0.setCellValue("ChangeId");
		sheet.setColumnWidth(0, 15 * 256);

		HSSFCell rowCell1 = row.createCell(1);
		rowCell1.setCellStyle(style);
		rowCell1.setCellValue("Date");
		sheet.setColumnWidth(1, 30 * 256);

		HSSFCell rowCell2 = row.createCell(2);
		rowCell2.setCellStyle(style);
		rowCell2.setCellValue("Level");
		sheet.setColumnWidth(2, 15 * 256);

		HSSFCell rowCell3 = row.createCell(3);
		rowCell3.setCellStyle(style);
		rowCell3.setCellValue("Source");
		sheet.setColumnWidth(3, 15 * 256);

		HSSFCell rowCell4 = row.createCell(4);
		rowCell4.setCellStyle(style);
		rowCell4.setCellValue("ObjectName");
		sheet.setColumnWidth(4, 15 * 256);

		HSSFCell rowCell5 = row.createCell(5);
		rowCell5.setCellStyle(style);
		rowCell5.setCellValue("EventId");
		sheet.setColumnWidth(5, 15 * 256);

		HSSFCell rowCell6 = row.createCell(6);
		rowCell6.setCellStyle(style);
		rowCell6.setCellValue("EventIdName");
		sheet.setColumnWidth(6, 20 * 256);

		HSSFCell rowCell7 = row.createCell(7);
		rowCell7.setCellStyle(style);
		rowCell7.setCellValue("CreatedDate");
		sheet.setColumnWidth(7, 30 * 256);

		HSSFCell rowCell8 = row.createCell(8);
		rowCell8.setCellStyle(style);
		rowCell8.setCellValue("CreateBy");
		sheet.setColumnWidth(8, 15 * 256);

		HSSFCell rowCell9 = row.createCell(9);
		rowCell9.setCellStyle(style);
		rowCell9.setCellValue("CreateByFullName");
		sheet.setColumnWidth(9, 15 * 256);

		HSSFCell rowCell10 = row.createCell(10);
		rowCell10.setCellStyle(style);
		rowCell10.setCellValue("Computer");
		sheet.setColumnWidth(10, 15 * 256);

		HSSFCell rowCell11 = row.createCell(11);
		rowCell11.setCellStyle(style);
		rowCell11.setCellValue("ProcessId");
		sheet.setColumnWidth(11, 15 * 256);

		HSSFCell rowCell12 = row.createCell(12);
		rowCell12.setCellStyle(style);
		rowCell12.setCellValue("Message");
		sheet.setColumnWidth(12, 50 * 256);

		HSSFCell rowCell13 = row.createCell(13);
		rowCell13.setCellStyle(style);
		rowCell13.setCellValue("Data");
		sheet.setColumnWidth(13, 80 * 256);

		HSSFCellStyle cellStyle = workbook.createCellStyle();
		// 水平居中
		cellStyle.setAlignment(HorizontalAlignment.CENTER);

		HSSFCellStyle cellLeftStyle = workbook.createCellStyle();
		cellLeftStyle.setAlignment(HorizontalAlignment.LEFT);

		try {

			List<AuditInfo> list = armsMappper.QueryAuditInfoList(mainId);
			// 遍历集合，写数据到excel表上
			for (int i = 0; i < list.size(); i++) {
				AuditInfo model = list.get(i);
				// 创建excel的行,由于第一行已经创建过，所以这里从 索引为i+1的开始
				HSSFRow sheetRow = sheet.createRow(i + 1);

				for (int g = 0; g < 14; g++) {
					HSSFCell cell = sheetRow.createCell(g);
					cell.setCellStyle(cellStyle);
					if (g == 0) {
						cell.setCellValue(model.getChangeId());
					} else if (g == 1) {
						cell.setCellStyle(cellLeftStyle);
						if (model.getDate() != null) {
							String nDate = DateUtils.format(model.getDate(), "yyyy-MM-dd HH:mm:ss");
							cell.setCellValue(nDate);
						}
						// cell.setCellValue(model.getDate());
					} else if (g == 2) {
						cell.setCellValue(model.getLevel());
					} else if (g == 3) {
						// cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getSource());
					} else if (g == 4) {
						// cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getObjectName());
					} else if (g == 5) {
						cell.setCellValue(model.getEventId());
					} else if (g == 6) {
						cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getEventIdName());
					} else if (g == 7) {
						cell.setCellStyle(cellLeftStyle);
						if (model.getCreatedDate() != null) {
							String createDate = DateUtils.format(model.getCreatedDate(), "yyyy-MM-dd HH:mm:ss");
							cell.setCellValue(createDate);
						}
						// cell.setCellValue(model.getCreatedDate());
					} else if (g == 8) {
						cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getCreatedBy());
					} else if (g == 9) {
						cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getCreatedByFullName());
					} else if (g == 10) {
						// cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getComputer());
					} else if (g == 11) {
						cell.setCellValue(model.getProcessId());
					} else if (g == 12) {
						cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getMessage());
					} else if (g == 13) {
						cell.setCellStyle(cellLeftStyle);
						cell.setCellValue(model.getData());
					} else {
					}
				}
			}

			long millis = System.currentTimeMillis();
			String FileName = StringUtils.DateToYMDHMS(new Date(millis)).replaceAll(":", "-") + ".xls";
			response.setContentType("multipart/form-data");
			response.setHeader("Content-Disposition", "inline;fileName=" + FileName);

			ServletOutputStream out = response.getOutputStream();
			out = response.getOutputStream();

			workbook.write(out);

			// 刷新释放资源
			out.flush();
			out.close();
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}