package com.tcs.common.utils;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class AESCoder {

	public static String key = "cc65040447370eead004d734f99ba866";

	private static final String ALGORITHM = "AES";

	private static final String CHARSET = "UTF-8";

	private static final int KEYSIZE = 128;

	/**
	 * AES加密
	 * @param data
	 * @return
	 */
	public static String encrypt(String data) {
		return encrypt(data, key);
	}

	/**
	 * AES加密
	 * @param data
	 * @param key
	 * @return
	 */
	public static String encrypt(String data, String key) {
		String output = null;
		try {
			/* 实例化 */
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			/* 初始化，设置为加密模式 */
			cipher.init(Cipher.ENCRYPT_MODE, evalKey(key));
			/* 执行操作 */
			byte[] bytes = cipher.doFinal(data.getBytes(CHARSET));
			output = byte2HexStr(bytes);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	/**
	 * AES解密
	 * @param enData
	 * @return
	 */
	public static String decrypt(String enData) {
		return decrypt(enData, key);
	}

	/**
	 * AES解密
	 * @param bytes
	 * @param key
	 * @return
	 */
	public static String decrypt(String enData, String key) {
		String output = null;
		try {
			/* 实例化 */
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			/* 初始化，设置为解密模式 */
			cipher.init(Cipher.DECRYPT_MODE, evalKey(key));
			/* 执行操作 */
			byte[] bytes = cipher.doFinal(hexStr2Byte(enData));
			output = new String(bytes, CHARSET);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}

	private static SecretKey evalKey(String keys) throws Exception {
		KeyGenerator generator = KeyGenerator.getInstance(ALGORITHM);
		SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
		secureRandom.setSeed(keys.getBytes());
		generator.init(KEYSIZE, secureRandom);
		return generator.generateKey();
	}

	/**
	 * 将二进制转换成16进制
	 * @param buf
	 * @return
	 */
	private static String byte2HexStr(byte buf[]) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < buf.length; i++) {
			String hex = Integer.toHexString(buf[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			sb.append(hex.toLowerCase());
		}
		return sb.toString();
	}

	/**
	 * 将16进制转换为二进制
	 * @param hexStr
	 * @return
	 */
	private static byte[] hexStr2Byte(String hexStr) {
		if (hexStr.length() < 1) {
			return null;
		}
		byte[] result = new byte[hexStr.length() / 2];
		for (int i = 0; i < hexStr.length() / 2; i++) {
			int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
			int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
			result[i] = (byte)(high * 16 + low);
		}
		return result;
	}

	//public static void main(String[] args) {
		//String password = "1";
		//System.out.println(AESCoder.decrypt(password, key));
	//}
}