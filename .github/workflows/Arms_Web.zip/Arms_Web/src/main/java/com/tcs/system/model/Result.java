package com.tcs.system.model;

public class Result<T> {

	private Integer status;
	private String message;
	private T result;
	private String timestamp;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public T getResult() {
		return result;
	}

	public void setResult(T result) {
		this.result = result;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	/**
	 * 返回成功
	 */
	public Result<T> success() {
		return success("操作成功！");
	}

	/**
	 * 返回成功
	 */
	public Result<T> success(String message) {
		return success(200, message);
	}

	/**
	 * 返回成功
	 */
	public Result<T> success(ResponseConstant constant) {
		return success(constant.getResult(), constant.getMsg());
	}

	/**
	 * 返回成功
	 */
	public Result<T> success(Integer status, String message) {
		this.setStatus(status);
		this.setMessage(message);
		return this;
	}

	/**
	 * 返回失败
	 */
	public Result<T> error() {
		return error("操作失败！");
	}

	/**
	 * 返回失败
	 */
	public Result<T> error(String messag) {
		return error(500, messag);
	}

	/**
	 * 返回失败
	 */
	public Result<T> error(int code, String message) {
		return success(code, message);
	}

	/**
	 * 返回信息
	 */
	public Result<T> error(ResponseConstant constant) {
		return success(constant.getResult(), constant.getMsg());
	}

	/**
	 * 放入object
	 */
	public Result<T> put(T object) {
		this.setResult(object);
		return this;
	}

}
