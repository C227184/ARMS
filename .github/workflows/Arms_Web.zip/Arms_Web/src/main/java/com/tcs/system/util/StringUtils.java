package com.tcs.system.util;

import java.io.FileInputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;


public class StringUtils {

	private static String PROPERTIES_NAME = "database.properties";

	public static String SPLIT_SIGN_SPECIAL = "`~`";

	public static String SPLIT_SIGN_SPECIAL2 = "`-`";

	public static String SPLIT_UNDERLINE = "_";

	public static String SPLIT_SIGN = ",";

	/** date format */
	public static String FORMAT_DATE_M = "MM";

	public static String FORMAT_DATE_YEAR = "yyyy";

	public static String FORMAT_DATE_DAY = "dd";

	public static String FORMAT_DATE_MD = "MM/dd";

	public static String FORMAT_DATE_YMD = "yyyy-MM-dd";

	public static String FORMAT_DATE_YMDHMS = "yyyy-MM-dd hh:mm:ss";

	public static String FORMAT_DATE_YMDHM = "yyyy-MM-dd hh:mm";

	public static String FORMAT_DATE_HM = "hh:mm";

	public static String FORMAT_DATE_CSV = "yyyy/MM/dd";

	/** data format */

	public static String FORMAT_DECIMAL_NOSEPARATOR = "####.00;-####.00";

	public static String FORMAT_DECIMAL_SEPARATOR = "#,###,###,###.00;-#,###,###,###.00";

	public static String FORMAT_DECIMAL_NOSEPARATOR_IGNORE = "####.00;-####.0#";

	public static String FORMAT_DECIMAL_SEPARATOR_IGNORE = "#,###,###,###.00;-#,###.0#";

	public static String FORMAT_DECIMAL_NOSEPARATOR_CN = "####.00;负####.00";

	public static String FORMAT_DECIMAL_SEPARATOR_CN = "#,###,###,###.00;负#,###,###,###.00";

	/**
	 * @param string
	 * @return
	 */
	public static String convertToString(Object[] string) {
		StringBuffer sta = new StringBuffer("('");
		for (int i = 0; i < string.length; i++) {
			sta.append(string[i].toString().trim()).append("'");
			if (i < string.length - 1)
				sta.append(",'");
			else if (i == string.length - 1)
				sta.append(")");
		}
		return sta.toString();
	}

	public static String convertToString(List str) {
		StringBuffer sta = new StringBuffer();
		int length = str.size();
		for (int i = 0; i < length; i++) {
			sta.append(str.get(i).toString().trim());
			if (i < length - 1)
				sta.append(",");
			else if (i == length - 1)
				sta.append("");
		}
		return sta.toString();
	}

	public static String convertToStringOfUserTrust(Object[][] userIds) {
		StringBuffer sta = new StringBuffer();
		int length = userIds.length;
		if (!StringUtils.isNull(userIds)) {
			for (int i = 0; i < length; i++) {
				sta.append(userIds[i][1].toString().trim());
				if (i < length - 1)
					sta.append(",");
				else if (i == length - 1)
					sta.append("");
			}
		}
		return sta.toString();
	}

	public static String convertToString2(Object[] string) {
		StringBuffer sta = new StringBuffer("(");
		for (int i = 0; i < string.length; i++) {
			sta.append(string[i].toString().trim());
			if (i < string.length - 1)
				sta.append(",");
			else if (i == string.length - 1)
				sta.append(")");
		}
		return sta.toString();
	}

	public static String convertToStringCommaSplit(Object[] string) {
		StringBuffer sta = new StringBuffer();
		for (int i = 0; i < string.length; i++) {
			sta.append(string[i].toString().trim());
			if (i < string.length - 1)
				sta.append(",");
			else if (i == string.length - 1)
				sta.append("");
		}
		return sta.toString();
	}

	public static Date formatDate(String dateStr) {
		Date date = null;
		try {
			java.text.DateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd");
			dateStr = dateStr.trim();
			date = (java.util.Date)formatter.parse(dateStr);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			// e.printStackTrace(System.out);
			return null;
		}
		return date;
	}

	// caiyu add
	/*
	 * change date to string as "yyyy-mm-dd"
	 */
	public static String DateToYMD(Date date) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String dateStr = formatter.format(date);
		return dateStr;
	}

	public static String DateToY(Date date) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
		String dateStr = formatter.format(date);
		return dateStr;
	}

	// caiyu add
	/*
	 * change date to string as "yyyy-mm-dd"
	 */
	public static String DateToYMDWithoutLine(Date date) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		String dateStr = formatter.format(date);
		return dateStr;
	}

	/*
	 * change date to string as "yyyy-mm-dd HH:mm"
	 */
	public static String DateToYMDHM(Date date) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String dateStr = formatter.format(date);
		return dateStr;

	}

	/*
	 * change date to string as "yyyy-mm-dd HH:mm"
	 */
	public static String DateToYMDHMS(Date date) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateStr = formatter.format(date);
		return dateStr;

	}

	/*
	 * change date to string as "yyyy/mm"
	 */
	public static String DateToYM(Date date) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM");
		String dateStr = formatter.format(date);
		return dateStr;
	}

	public static String DateToYM2(Date date, String str) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat formatter = new SimpleDateFormat(str);
		String dateStr = formatter.format(date);
		return dateStr;
	}

	/*
	 * change date to only has date and set the hour,minute,second as 0"
	 */
	public static Date toYMDDate(Date date) {
		if (date == null) {
			return null;
		}

		String strYmd = DateToYMD(date);
		return formatDate(strYmd);
	}

	/*
	 * union date and time for example: date = 2006-10-15, time = 12:30, will
	 * return 2006-10-15 12:30
	 * @param dateStr date @param timeStr time
	 */
	public static Date UnitTime(Date dateStr, String timeStr) {
		String dateStrTemp = StringUtils.DateToYMD(dateStr);
		return UnitTime(dateStrTemp, timeStr);
	}

	/*
	 * union date and time for example: date = 2006-10-15, time = 12:30, will
	 * return 2006-10-15 12:30
	 * @param dateStr date @param timeStr time
	 */
	public static Date UnitTime(String dateStr, String timeStr) {

		if (dateStr == null || "".equals(dateStr)) {
			return null;
		}

		java.text.DateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateStr = dateStr + " " + timeStr + ":00";

		dateStr = dateStr.trim();
		Date date = null;
		try {
			date = (java.util.Date)formatter.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}

	public static String formatMoney(BigDecimal money) {
		money.setScale(2);
		NumberFormat formatter = NumberFormat.getNumberInstance();
		formatter.setMinimumFractionDigits(2);
		try {
			String result = formatter.format(money);
			return result;
		} catch (RuntimeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return money.toString();
		}

	}

	/**
	 * add by zhangzhi
	 * @param money
	 * @return
	 */
	public static String formatMoney(double money) {
		DecimalFormat formatter = new DecimalFormat("###,###.00");
		String result = formatter.format(money);
		if (".00".equals(result)) {
			result = "";
		}
		return result;
	}

	/**
	 * @author Kevin
	 * @param money
	 * @param scale
	 * @return
	 */
	public static Double formatMoney(String money, int scale) {
		if (money == null || "".equals(money))
			return null;
		return new Double(new BigDecimal(money).setScale(scale > 0 ? scale : 0, BigDecimal.ROUND_HALF_UP).doubleValue());
	}

	/**
	 * add by zhangzhi
	 * @param money
	 * @return
	 */
	public static String formatMoney(String money) {
		if (StringUtils.isEmpty(money)) {
			return "";
		}
		Double value = Double.valueOf(money);
		DecimalFormat formatter = new DecimalFormat("###,###.00");
		String result = formatter.format(value);
		if (".00".equals(result)) {
			result = "";
		}
		return result;
	}

	/**
	 * add by zhangzhi
	 * @param money
	 * @return
	 */
	public static String formatMoney(float money) {
		DecimalFormat formatter = new DecimalFormat("###,###.00");
		String result = formatter.format(money);
		if (".00".equals(result)) {
			result = "";
		}
		return result;
	}

	/**
	 * add by zhangzhi
	 * @param money
	 * @return
	 */
	public static String formatMoney(Float money) {
		if (money == null) {
			return null;
		}
		DecimalFormat formatter = new DecimalFormat("###,###.00");
		String result = formatter.format(money);
		if (".00".equals(result)) {
			result = "";
		}
		return result;
	}

	/**
	 * add by zhangzhi
	 * @param money
	 * @return
	 */
	public static String formatMoney(Double money) {
		if (money == null) {
			return null;
		}
		DecimalFormat formatter = new DecimalFormat("###,###.00");
		String result = formatter.format(money);
		if (".00".equals(result)) {
			result = "";
		}
		return result;
	}

	/**
	 * @author Kevin
	 * @return
	 */
	public static String formatMoneyII(Double money) {
		if (money == null) {
			return null;
		}
		DecimalFormat formatter = new DecimalFormat("###,###.00");
		String result = formatter.format(money);
		if (".00".equals(result)) {
			result = "0.00";
		}
		return result;

	}

	public static String formatMoneyIII(Double money) {
		if (money == null) {
			return null;
		}
		DecimalFormat formatter = new DecimalFormat("######.00");
		String result = formatter.format(money);
		if (".00".equals(result)) {
			result = "0.00";
		}
		return result;

	}

	public static String formatMumber(BigDecimal number, int fraction) {

		number.setScale(fraction);
		NumberFormat formatter = NumberFormat.getNumberInstance();
		formatter.setMaximumFractionDigits(fraction);
		try {
			String result = formatter.format(number);
			return result;
		} catch (RuntimeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return number.toString();
		}
	}

	/*
	 * add days base date for example: date = 2006-10-15, dayNum = 3, will
	 * return 2006-10-18
	 * @param dateStr base date @param dayNum add days
	 */
	public static String addDay(String dateStr, int dayNum) {
		java.text.DateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd");

		dateStr = dateStr.trim();

		String toDateStr = "";
		try {
			if (dateStr != null && !"".equals(dateStr)) {
				Date date = (java.util.Date)formatter.parse(dateStr);
				Calendar nextDay = formatter.getCalendar();
				nextDay.add(Calendar.DAY_OF_MONTH, dayNum);
				toDateStr = DateToYMDHM(nextDay.getTime());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return toDateStr;
	}

	/*
	 * add days base date for example: date = 2006-10-15, dayNum = 3, will
	 * return 2006-10-18
	 * @param dateStr base date @param dayNum add days
	 */
	public static String addDayToYMD(String dateStr, int dayNum) {
		java.text.DateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd");

		dateStr = dateStr.trim();

		String toDateStr = "";
		try {
			if (dateStr != null && !"".equals(dateStr)) {
				Date date = (java.util.Date)formatter.parse(dateStr);
				Calendar nextDay = formatter.getCalendar();
				nextDay.add(Calendar.DAY_OF_MONTH, dayNum);
				toDateStr = DateToYMD(nextDay.getTime());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return toDateStr;
	}

	/*
	 * get time according to date for example: date = 2006-10-15 12:30, will
	 * return 12:30
	 * @param date date include time
	 */
	public static String DateToHM(Date date) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
		String dateStr = formatter.format(date);
		return dateStr;
	}

	/*
	 * get time according to date for example: date = 2006-10-15 12:30, will
	 * return 12:30
	 * @param date date include time
	 */
	public static Date toHMSDate(String strTime) {
		try {
			if (strTime == null || "".equals(strTime)) {
				return null;
			} else {
				strTime = strTime + ":00";
			}

			SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
			Date dateStr = formatter.parse(strTime);
			return dateStr;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/*
	 * get start day and end day for one month according to date for example:
	 * date = 2006-10-15, will return 2006-10-01 and 2006-10-31 in list
	 * @param date date in some month
	 */
	public static List getMonthPeriod(Date date) {

		List listPeriod = new ArrayList();
		if (date == null) {
			return listPeriod;
		}

		java.text.DateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd");

		// get current calendar
		Calendar rightNow = Calendar.getInstance();
		rightNow.setTime(date);

		rightNow.set(Calendar.MONTH, rightNow.get(Calendar.MONTH));
		rightNow.set(Calendar.DAY_OF_MONTH, 1);
		listPeriod.add(formatter.format(rightNow.getTime()));

		rightNow.set(Calendar.DAY_OF_MONTH, rightNow.getActualMaximum(Calendar.DAY_OF_MONTH));
		listPeriod.add(formatter.format(rightNow.getTime()));

		return listPeriod;

	}

	/*
	 * get start day and end day for one quarter according to date for example:
	 * date = 2006-10-15, will return 2006-10-01 and 2006-12-31 in list
	 * @param date date in some quarter
	 */
	public static List getQuarterPeriod(Date date) {
		List listPeriod = new ArrayList();
		if (date == null) {
			return listPeriod;
		}

		java.text.DateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd");

		// get current calendar
		Calendar rightNow = Calendar.getInstance();
		rightNow.setTime(date);

		// month start from 0
		int iQuarter = rightNow.get(Calendar.MONTH) / 3;

		rightNow.set(Calendar.MONTH, iQuarter * 3);
		rightNow.set(Calendar.DAY_OF_MONTH, 1);
		listPeriod.add(formatter.format(rightNow.getTime()));

		rightNow.set(Calendar.MONTH, (iQuarter + 1) * 3 - 1);
		rightNow.set(Calendar.DAY_OF_MONTH, 1);
		rightNow.set(Calendar.DAY_OF_MONTH, rightNow.getActualMaximum(Calendar.DAY_OF_MONTH));
		listPeriod.add(formatter.format(rightNow.getTime()));

		return listPeriod;
	}

	/*
	 * compare fromdate and todate fromdate<=todate return true fromdate>todate
	 * return false
	 */
	public static boolean dayEquals(Date fromDate, Date toDate) {
		if ((DateToYMD(fromDate)).compareTo(DateToYMD(toDate)) == 0) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * compare fromdate and todate fromdate<=todate return true fromdate>todate
	 * return false
	 */
	public static boolean dayLessEquals(Date fromDate, Date toDate) {
		if ((DateToYMD(fromDate)).compareTo(DateToYMD(toDate)) <= 0) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * compare fromdate and todate fromdate>=todate return true fromdate<todate
	 * return false
	 */
	public static boolean dayGreaterEquals(Date fromDate, Date toDate) {
		if ((DateToYMD(fromDate)).compareTo(DateToYMD(toDate)) >= 0) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * compare fromdate and todate fromdate<=todate return true fromdate>todate
	 * return false
	 */
	public static boolean timeLessEquals(Date fromDate, Date toDate) {
		if ((DateToYMDHMS(fromDate)).compareTo(DateToYMDHMS(toDate)) <= 0) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * compare fromdate and todate fromdate>=todate return true fromdate<todate
	 * return false
	 */
	public static boolean timeGreaterEquals(Date fromDate, Date toDate) {
		if ((DateToYMDHMS(fromDate)).compareTo(DateToYMDHMS(toDate)) >= 0) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * get Millisecond string
	 */
	public static String formatDate16(Date myDate) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		String strDate = formatter.format(myDate);
		return strDate;
	}

	/*
	 * get upload file path
	 */
	public static String initUpdPath(String realPath) {

		String updPath = "/";

		try {
			if (!realPath.endsWith(System.getProperty("file.separator"))) {
				realPath = realPath + System.getProperty("file.separator");
			}
			String path = realPath + "/WEB-INF/" + PROPERTIES_NAME;

			java.util.Properties pro = new java.util.Properties();
			//
			FileInputStream in = new java.io.FileInputStream(path);
			pro.load(in);

			updPath = pro.getProperty("db.UPDFILE.path");

			if (!updPath.endsWith(System.getProperty("file.separator"))) {
				updPath = updPath + System.getProperty("file.separator");
			}
			in.close();
			pro.clear();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return updPath;
	}

	/*
	 * get proPerty Value
	 */
	public static String getPropertyFromKey(HttpServletRequest req, String fileName, String key) {
		String returnValue = "";

		try {
			String separator = System.getProperty("file.separator");
			String path = req.getRealPath(separator + "WEB-INF" + separator + fileName);

			java.util.Properties pro = new java.util.Properties();
			FileInputStream in = new java.io.FileInputStream(path);
			pro.load(in);
			if (pro.getProperty(key) != null)
				returnValue = pro.getProperty(key);

			in.close();
			pro.clear();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return returnValue;
	}

	public static boolean isNull(Object arg) {
		if (arg == null) {
			return true;
		}

		if (arg instanceof String) {
			if ("".equals((String)arg)) {
				return true;
			}
		}

		return false;
	}

	public static boolean isDateFormatter(String dateArg) {

		try {
			java.text.DateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd");
			Date date = (java.util.Date)formatter.parse(dateArg);
			String newTime = formatter.format(date);

			return newTime.equals(dateArg);

		} catch (Exception e) {
			return false;
		}
	}

	public static boolean isFloatFormatter(String charge) {

		try {
			Float.parseFloat(charge);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean isDoubleFormatter(String charge) {

		try {
			Double.parseDouble(charge);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// likai add
	public static boolean isIntegerFormatter(String charge) {
		try {
			Integer.parseInt(charge);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static Integer integerFormatter(String charge) {
		try {
			return new Integer(Integer.parseInt(charge));
		} catch (Exception e) {
			return null;
		}
	}

	public static Integer integerFormatter(Object obj) {
		try {
			String charge = obj.toString();
			return new Integer(Integer.parseInt(charge));
		} catch (Exception e) {
			return null;
		}
	}

	public static Date dateFormatter(String dateArg) {

		try {
			java.text.DateFormat formatter = new java.text.SimpleDateFormat("yyyy-MM-dd");
			Date date = (java.util.Date)formatter.parse(dateArg);
			String newTime = formatter.format(date);

			if (newTime.equals(dateArg)) {
				return date;
			} else {
				return null;
			}

		} catch (Exception e) {
			return null;
		}
	}

	public static Double doubleFormatter(String charge) {

		try {
			return new Double(Double.parseDouble(charge));
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 检查输入字符串是否为空
	 * @author Sin
	 * @param inputStr 输入字符
	 * @return empty:false notEmpty:true
	 */
	public static boolean isNotEmpty(String inputStr) {
		if (inputStr == null || "".equals(inputStr)) {
			return false;
		}
		return true;
	}

	public static Float floatFormatter(String charge) {

		try {
			return new Float(Float.parseFloat(charge));
		} catch (Exception e) {
			return null;
		}
	}

	// likai end
	/**
	 * �ֽ�staffTypeContent,�õ�JOB_TYPE, CONTRACT_TYPE, JOB_GRADE_TYPE, LE,
	 * EMPLYEE_STATUS, SHIFTֵ������ap
	 * @param staffTypeContent
	 *            the staffTypeContent
	 * @return the Map associated with the staffTypeContent
	 */

	public static String htmltotext(String htmlstr) {
		htmlstr = htmlstr.replaceAll("<B>", "");
		htmlstr = htmlstr.replaceAll("<b>", "");
		htmlstr = htmlstr.replaceAll("</B>", "");
		htmlstr = htmlstr.replaceAll("</b>", "");
		htmlstr = htmlstr.replaceAll("<BR>", "\r\n");
		htmlstr = htmlstr.replaceAll("<Br>", "\r\n");
		htmlstr = htmlstr.replaceAll("<br>", "\r\n");
		htmlstr = htmlstr.replaceAll("<bR>", "\r\n");
		htmlstr = htmlstr.replaceAll("<i>", "");
		htmlstr = htmlstr.replaceAll("</i>", "");
		htmlstr = htmlstr.replaceAll("<I>", "");
		htmlstr = htmlstr.replaceAll("</I>", "");
		return htmlstr;
	}

	public static String texttohtml(String text) {
		text = text.replaceAll(" ", "&nbsp;");
		text = text.replaceAll("\n", "<br>");
		// text=text.replaceAll("<", "&lt;");
		// text=text.replaceAll(">", "&gt;");

		return text;
	}

	public static String formatNumber(String sValue, int iDecimalDigits) {
		if (sValue.indexOf(".") > -1) {
			String sNew = "";

			String integral = sValue.substring(0, sValue.indexOf("."));
			String decimal = sValue.substring(sValue.indexOf(".") + 1, sValue.length());

			if (decimal == null) {
				sNew = integral + "." + multiChar("0", iDecimalDigits);
			} else if (decimal.length() <= iDecimalDigits) {
				sNew = integral + "." + decimal + multiChar("0", iDecimalDigits - decimal.length());
			} else if (decimal.length() > iDecimalDigits) {
				sNew = integral + "." + decimal.substring(0, iDecimalDigits);
			}
			return sNew;
		} else {
			if (sValue.equals(""))
				return "0." + multiChar("0", iDecimalDigits);
			else
				return sValue + "." + multiChar("0", iDecimalDigits);
		}
	}

	public static String multiChar(String c, int n) {
		String s = "";
		for (int i = 0; i < n; i++) {
			s = s + c;
		}
		return s;
	}

	/**
	 * string convert array
	 * @return type java.util.List
	 */
	public static List array2List(String[] arr) {
		if (arr == null) {
			return null;
		}

		if (arr.length == 0) {
			return new ArrayList();
		}
		List list = new ArrayList();
		for (int i = 0; i < arr.length; i++) {
			list.add(arr[i]);
		}
		return list;
	}

	/**
	 * @param string
	 * @param format
	 *            description:[,]
	 * @return
	 */
	public static String convertToString(Object[] string, String format) {
		String[] formatSign = null;
		if (StringUtils.isRealEmpty(format)) {
			throw new RuntimeException("format is error");
		} else {
			formatSign = format.split(StringUtils.SPLIT_SIGN);
		}

		StringBuffer sta = new StringBuffer();
		for (int i = 0; i < string.length; i++) {
			sta.append(formatSign[0]);
			sta.append(string[i].toString().trim());
			sta.append(formatSign[1]);
			if (i != string.length - 1) {
				sta.append(StringUtils.SPLIT_SIGN);
			}
		}
		return sta.toString();
	}

	/**
	 * @param string
	 * @return
	 */
	public static String[] toStringArray(String string) {
		String[] stringarray = { "" };
		if (string != null) {
			java.util.StringTokenizer st = new java.util.StringTokenizer(string, ",");
			stringarray = new String[st.countTokens()];
			int index = 0;
			while (st.hasMoreTokens()) {
				stringarray[index++] = st.nextToken();
			}
		}
		return stringarray;
	}

	/**
	 * string convert dateStr depend on dateformat
	 * @param dateformat
	 *            string
	 */
	public static Date stringToDate(String dateStr, String dateFormat) {
		Date date = null;
		if (StringUtils.isRealEmpty(dateFormat)) {
			dateFormat = StringUtils.FORMAT_DATE_YMD;
		}

		try {
			java.text.DateFormat formatter = new java.text.SimpleDateFormat(dateFormat);
			dateStr = dateStr.trim();
			date = (java.util.Date)formatter.parse(dateStr);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return date;
	}

	/**
	 * @param dateStr
	 *            :2007-11-12
	 * @return
	 */
	public static Calendar stringToCalendar(String dateStr) {
		Calendar calendar = Calendar.getInstance();
		String[] date = dateStr.split("-");
		calendar.set(Calendar.YEAR, Integer.parseInt(date[0]));
		calendar.set(Calendar.MONTH, Integer.parseInt(date[1]) - 1);
		calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(date[2]));
		return calendar;
	}

	/**
	 * @param name
	 *            description: ju
	 * @return
	 */
	public static boolean isEmpty(String str) {
		return str == null || str.length() == 0 || "null".equals(str);
	}

	public static boolean isRealEmpty(String str) {
		return str == null || str.length() == 0 || str.trim().equals("") || str.trim().equals("null") || str.trim().equals("undefined");
	}

	/**
	 * change date to string as "yyyy-mm-dd"
	 * @param date
	 * @String dateFormat
	 */
	public static String DateToString(Date date, String dateFormat) {
		if (date == null) {
			return "";
		}

		if (StringUtils.isRealEmpty(dateFormat)) {
			dateFormat = StringUtils.FORMAT_DATE_YMD;
		}

		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
		String dateStr = formatter.format(date);
		return dateStr;
	}

	/**
	 * add days base date for example: date = 2006-10-15, dayNum = 3, will
	 * return 2006-10-18
	 * @param dateStr
	 *            base date
	 * @param dayNum
	 *            add days
	 */

	public static String addDay(int dayNum) {

		String toDateStr = "";
		try {
			Calendar nextDay = Calendar.getInstance();
			nextDay.add(Calendar.DAY_OF_MONTH, dayNum);
			toDateStr = DateToString(nextDay.getTime(), StringUtils.FORMAT_DATE_YMD);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return toDateStr;
	}

	/*
	 * compare fromdate and todate fromdate<=todate return true fromdate>todate
	 * return false
	 */
	public static boolean isDayEquals(Date fromDate, Date toDate) {
		if ((DateToString(fromDate, StringUtils.FORMAT_DATE_YMD)).compareTo(DateToString(toDate, StringUtils.FORMAT_DATE_YMD)) == 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * compare fromdate and todate fromdate>=todate return true fromdate<todate
	 * @return false
	 */
	public static boolean dateCompare(Date fromDate, Date toDate, String dateFormat) {
		if ((DateToString(fromDate, dateFormat)).compareTo(DateToString(toDate, dateFormat)) >= 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * number convert string by numberFormat and locale numberFormat="####.00"
	 * 10000.2001----->10000.20 if locale==null use default locale
	 * @param number
	 * @param numberFormat
	 *            description:data fromat
	 * @param locale
	 *            description:support i18n
	 */

	public static String numberToString(Number number, String numberFormat, Locale locale) {
		NumberFormat nf = null;
		DecimalFormat df = null;

		if (locale == null) {
			nf = NumberFormat.getNumberInstance();
		} else {
			nf = NumberFormat.getNumberInstance(locale);
		}

		if (nf instanceof DecimalFormat) {
			df = ((DecimalFormat)nf);
		} else {
			throw new RuntimeException("Don't convert");
		}

		if (!isRealEmpty(numberFormat)) {
			df.applyPattern(numberFormat);
		}

		df.setDecimalSeparatorAlwaysShown(true);
		return df.format(number);
	}

	/**
	 * string convert number depend on locale
	 * @param numberStr
	 * @param locale
	 */

	public static Number stringToNumber(String numberStr, Locale locale) {
		NumberFormat nf = null;
		Number number = null;
		if (locale == null) {
			nf = NumberFormat.getNumberInstance();
		} else {
			nf = NumberFormat.getNumberInstance(locale);
		}

		try {
			number = nf.parse(numberStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return number;
	}

	/**
	 * currency of number convert string depond on locale
	 * 1000.12----convert----->￥1,000.12
	 * @param currency
	 *            description:currency
	 * @param locale
	 *            description:i18n
	 * @return string description:
	 */
	public static String currencyToString(Number currency, Locale locale) {
		NumberFormat nf = null;
		if (locale == null) {
			nf = NumberFormat.getCurrencyInstance();
		} else {
			nf = NumberFormat.getCurrencyInstance(locale);
		}
		return nf.format(currency);
	}

	/**
	 * string convert number depond on locale eg:
	 * ￥1,000.12------convert----->1000.12
	 * @param currency
	 * @param locale
	 */
	public static Number stringToCurrency(String currency, Locale locale) {
		NumberFormat nf = null;
		Number number = null;

		if (locale == null) {
			nf = NumberFormat.getCurrencyInstance();
		} else {
			nf = NumberFormat.getCurrencyInstance(locale);
		}

		if (!currency.trim().startsWith("￥")) {
			currency = "￥" + currency;
		}

		try {
			number = nf.parse(currency);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return number;
	}

	/**
	 * string convert percent by locale if locale==null use default locale
	 * @param numberStr
	 * @param locale
	 */
	public static Number stringToPercent(String numberStr, Locale locale) {
		NumberFormat nf = null;
		Number number = null;

		if (locale == null) {
			nf = NumberFormat.getPercentInstance();
		} else {
			nf = NumberFormat.getPercentInstance(locale);
		}

		try {
			number = nf.parse(numberStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return number;
	}

	/**
	 * percent convert string by locale if locale==null use default locale
	 * @param number
	 * @param locale
	 */
	public static String percentToString(Number number, Locale locale) {
		NumberFormat nf = null;
		if (locale == null) {
			nf = NumberFormat.getPercentInstance();
		} else {
			nf = NumberFormat.getPercentInstance(locale);
		}
		return nf.format(number);
	}

	
	public static int getYear(Date date) {
		java.util.Calendar c = java.util.Calendar.getInstance();
		c.setTime(date);
		return c.get(java.util.Calendar.YEAR);
	}

	public static int getMonth(Date date) {
		java.util.Calendar c = java.util.Calendar.getInstance();
		c.setTime(date);
		return c.get(java.util.Calendar.MONTH);
	}

	public static int getDay(Date date) {
		java.util.Calendar c = java.util.Calendar.getInstance();
		c.setTime(date);
		return c.get(java.util.Calendar.DAY_OF_MONTH);
	}

	public static String[] stringToArray(String str) {
		if (isEmpty(str)) {
			return null;
		}
		return str.split(",");
	}

	public static boolean isTime(String str) {
		Pattern p = Pattern.compile("^[0-2]?[0-9]:[0-5][0-9]?$");
		Matcher m = p.matcher(str);
		return m.matches();
	}

	public static String[] listToArray(List strList) {
		String[] str = new String[strList.size()];
		for (int i = 0; i < strList.size(); i++) {
			str[i] = strList.get(i).toString();
		}
		return str;
	}

	public static String wrapSoft(String str, int cols) {
		if (str == null)
			return null;
		System.out.println(str.indexOf("\n"));
		if (str.indexOf("\n") > 0 && str.indexOf("\n") < str.length() - 3)
			return str;
		StringBuffer sb = new StringBuffer();
		int length = str.length();
		if (length <= cols)
			return str;
		int startpoint = 0;
		int endpoint = cols;
		while (endpoint < length) {
			sb.append(str.substring(startpoint, endpoint));
			sb.append("\n");
			startpoint = endpoint;
			endpoint = endpoint + cols;
		}
		sb.append(str.substring(startpoint, length));
		return sb.toString();
	}

	public static String wrapSoft(String str, boolean issplit) {
		if (!issplit)
			return str;
		if (str == null)
			return null;
		if (str.indexOf("\n") > 0)
			return str;
		int cols = 30;
		StringBuffer sb = new StringBuffer();
		int length = str.length();
		if (length <= cols)
			return str;
		int startpoint = 0;
		int endpoint = cols;
		while (endpoint < length) {
			sb.append(str.substring(startpoint, endpoint));
			sb.append("\n");
			startpoint = endpoint;
			endpoint = endpoint + cols;
		}
		sb.append(str.substring(startpoint, length));
		return sb.toString();
	}

	public static Double stringToDouble(String str) {
		if (isRealEmpty(str)) {
			return null;
		} else {
			return new Double(str);
		}
	}

	public static double add(double a, double b) {
		BigDecimal bd1 = new BigDecimal(a);
		BigDecimal bd2 = new BigDecimal(b);
		return bd1.add(bd2).doubleValue();
	}
}