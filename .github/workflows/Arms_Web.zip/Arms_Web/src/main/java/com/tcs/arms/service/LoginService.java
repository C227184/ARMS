package com.tcs.arms.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

import javax.naming.AuthenticationException;
import javax.naming.CommunicationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.PagedResultsControl;
import javax.naming.ldap.PagedResultsResponseControl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tcs.common.utils.TokenUtils;
import com.tcs.arms.model.UserInfo;

import io.jsonwebtoken.Claims;

/*
 * 文件名：LoginService.java
 * 描述：用户登录服务
 * 作者：Haijun Huang
 * 创建时间：2023-06-01
*/


@Service
public class LoginService {

	@Value("${ldap.url}")
	private String ldapUrl;

	@Value("${ldap.base}")
	private String ldapBase;

	@Value("${ldap.userName}")
	private String ldapUserName;

	@Value("${ldap.userPwd}")
	private String ldapUserPwd;

	@Value("${ldap.referral}")
	private String ldapReferral;

	@Value("${jwt.key}")
	private String jwtKey;

	@Value("${jwt.expiration}")
	private long expiration;

	@Value("${arms.role.admin}")
	private String roleAdmin;

	@Value("${arms.role.user}")
	private String roleUser;

	public UserInfo Login(String username, String password) {

		// 模擬賬號
		String name = username;
		if (name.equalsIgnoreCase("admin") || name.equalsIgnoreCase("L003828") || name.equalsIgnoreCase("user")) {

			String token = TokenUtils.createJWT(username, password, "", expiration, jwtKey);
			UserInfo user = GetUserInfo(username, username, username, "", token);
			return user;
		}

		Hashtable<String, String> HashEnv = new Hashtable<>();
		// LDAP Url
		HashEnv.put(Context.PROVIDER_URL, ldapUrl);
		// LDAP Dns
		// HashEnv.put(Context.DNS_URL, ldapBase);
		// LDAP访问安全级别(none,simple,strong);
		HashEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
		// AD的用户名
		HashEnv.put(Context.SECURITY_PRINCIPAL, "AP\\" + username);
		// AD的密码
		HashEnv.put(Context.SECURITY_CREDENTIALS, password);

		// LDAP工厂类
		HashEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		// 连接超时设置为5秒
		HashEnv.put("com.sun.jndi.ldap.connect.timeout", "5000");

		try {

			InitialDirContext dc = new InitialDirContext(HashEnv);// 初始化上下文
			InitialLdapContext ctx1 = new InitialLdapContext(HashEnv, null);

			// 没有报错，说明认证成功
			String token = TokenUtils.createJWT(username, password, "", expiration, jwtKey);

			UserInfo user = GetUserInfo(username, username, username, "", token);
			// 返回Token
			return user;

		} catch (javax.naming.AuthenticationException e) {
			System.out.println("认证失败");
			return null;
		} catch (Exception e) {
			System.out.println("认证出错：" + e);
			return null;
		}
	}

	public Claims parserToken(String token) {
		return TokenUtils.parserToken(token, jwtKey);
	}

	
	/*
	 * 方法名：Logout
	 * 描述：用户登录并获取域控信息
	 * 作者：Haijun Huang
	 * 创建时间：2023-06-01
	*/
	public UserInfo Login2(String username, String password, String token) {

		Hashtable<String, String> HashEnv = new Hashtable<>();
		// LDAP Url
		HashEnv.put(Context.PROVIDER_URL, ldapUrl);
		// LDAP Dns
		// HashEnv.put(Context.DNS_URL, ldapBase);
		// LDAP访问安全级别(none,simple,strong);
		HashEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
		// AD的用户名
		HashEnv.put(Context.SECURITY_PRINCIPAL, "AP\\" + username);
		// AD的密码
		HashEnv.put(Context.SECURITY_CREDENTIALS, password);

		// LDAP工厂类
		HashEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		// 连接超时设置为5秒
		HashEnv.put("com.sun.jndi.ldap.connect.timeout", "5000");

		try {

			InitialDirContext dc = new InitialDirContext(HashEnv);// 初始化上下文
			InitialLdapContext ctx1 = new InitialLdapContext(HashEnv, null);
			// 域节点
			String searchBase = ldapBase;
			String searchFilter = "cn=" + username;
			// String searchFilter = "cn=SUZ_AUTO_ARMS_REPORT";

			SearchControls searchCtls = new SearchControls();
			// 设置查询的属性,根据登陆用户姓名获取ou
			String[] returnedAtts = { "mail", "givenName", "displayName", "cn", "sn", "objectSid", "distinguishedName",
					"memberOf" };// 定制返回属性
			searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE); // Create the Specify
			searchCtls.setReturningAttributes(returnedAtts); // 设置返回属性集

			// 根据设置的域节点、过滤器类和搜索控制器搜索LDAP得到结果
			NamingEnumeration<SearchResult> entries = ctx1.search(searchBase, searchFilter, searchCtls);
			if (!entries.hasMore()) {
				return null;
			}
			SearchResult entry = entries.next();
			Attributes attrs = entry.getAttributes();

			String displayName = attrs.get("displayName").toString();
			String[] displayArray = displayName.split(":");
			if (displayArray.length > 1) {
				displayName = displayArray[1].toString().replace("- Network", "").replace("-Network", "");
				displayName = displayName.trim();
			}

			String disName = attrs.get("distinguishedname").toString();
			String distinguishedname = disName;
			String[] disNameArray = disName.split(":");
			if (disNameArray.length > 1) {
				distinguishedname = disNameArray[1].trim();
			}

			// 获取权限信息: memberOf
			String roles = "";
			Attribute memberOf = attrs.get("memberOf");
			if (memberOf != null) {
				NamingEnumeration<?> memberEnum = memberOf.getAll();
				while (memberEnum.hasMore()) {

					String memOf = memberEnum.next().toString();
					String[] memOfArray = memOf.split(",");
					if (memOfArray.length > 0) {
						String itemGroup = memOfArray[0].toString();
						String[] itemArray = itemGroup.split("=");

						if (itemArray.length > 1) {
							String memName = itemArray[1].toString();

							String adminGroup = roleAdmin.toUpperCase();
							String userGroup = roleUser.toUpperCase();
							String mem_Name = memName.toUpperCase();
							if (adminGroup.contains(mem_Name)) {
								String[] roleArray = roleAdmin.split("=");
								if (roleArray.length > 0) {
									roles = roleArray[0].toString();
								}
							} else if (userGroup.contains(mem_Name)) {
								String[] roleArray = roleUser.split("=");
								if (roleArray.length > 0) {
									roles = roleArray[0].toString();
								}
							}
						}
					}
				}
			}

			UserInfo user = GetUserInfo(username, distinguishedname, displayName, roles, token);
			// 返回Token
			return user;

		} catch (javax.naming.AuthenticationException e) {
			System.out.println("认证失败");
			return null;
		} catch (Exception e) {
			System.out.println("认证出错：" + e);
			return null;
		}
	}

	
	public UserInfo GetUserInfo(String userId, String name, String userName, String roles, String token) {
		UserInfo userVo = new UserInfo();
		userVo.setUserId(userId);
		userVo.setName(name);
		userVo.setUserName(userName);
		userVo.setAvatar("avatar2.jpg");
		userVo.setStatus(1);
		userVo.setLastLoginTime(String.valueOf(System.currentTimeMillis()));
		if (roles != "") {
			userVo.setRole(roles);
			userVo.setRoleId(roles);
		}
		userVo.setCreateTime(String.valueOf(System.currentTimeMillis()));
		userVo.setRoleId(roles);
		userVo.setLang("zh-CN");
		if (token != "") {
			userVo.setToken(token);
		}
		return userVo;
	}

	public String Test() {
		List<String> list = new ArrayList<>();
		List<String> addressList = new ArrayList<>();

		DirContext ctx = null;
		LdapContext ctx1 = null;

		Hashtable<String, String> HashEnv = new Hashtable<>();
		// LDAP Url
		HashEnv.put(Context.PROVIDER_URL, ldapUrl);

		// LDAP访问安全级别(none,simple,strong);
		HashEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
		// AD的用户名
		HashEnv.put(Context.SECURITY_PRINCIPAL, ldapUserName);
		// AD的密码
		HashEnv.put(Context.SECURITY_CREDENTIALS, ldapUserPwd);
		HashEnv.put(Context.DNS_URL, ldapBase);

		// LDAP工厂类
		HashEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		// 连接超时设置为10秒
		HashEnv.put("com.sun.jndi.ldap.connect.timeout", "10000");

		int pageSize = 980; // 每次获取多少条
		int total; // 总共获取的条数
		byte[] cookie = null;

		try {
			// 初始化上下文
			ctx = new InitialDirContext(HashEnv);
			ctx1 = new InitialLdapContext(HashEnv, null);
			ctx1.setRequestControls(new Control[] { new PagedResultsControl(pageSize, Control.CRITICAL) });// 分页读取控制---因为LDAP
																											// 默认情况只能读取1000条数据
			System.out.println("身份验证成功");
			do {
				// 搜索控制器
				SearchControls searchCtls = new SearchControls();
				// 创建搜索控制器
				searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
				// LDAP搜索过滤器类，此处只获取AD域用户，所以条件为用户user或者person均可
				// (&(objectCategory=person)(objectClass=user)(name=*))
				// String searchFilter = "objectClass=user";
				String searchFilter = "(&(cn=aq3apadds03)(objectClass=user))";

				// AD域节点结构
				String searchBase = "dc=ap,dc=lilly,dc=com";
				// 定制返回属性
				String[] returnedArrary = { "mail", "givenName", "cn", "sn", "department", "distinguishedName" };

				searchCtls.setReturningAttributes(returnedArrary);
//            NamingEnumeration<SearchResult> answer = ctx.search(searchBase, searchFilter, searchCtls);
				NamingEnumeration<SearchResult> answer = ctx1.search(searchBase, searchFilter, searchCtls);

				while (answer.hasMoreElements()) {
					SearchResult sr = (SearchResult) answer.next();
					String cwid = sr.getName().split("CN=")[1].split(",")[0];
					System.out.println(cwid);

					// 得到符合条件的属性集
					Attributes Attrs = sr.getAttributes();
					if (Attrs != null) {
						Map<String, String> maps = new HashMap<>();
						for (NamingEnumeration ne = Attrs.getAll(); ne.hasMore();) {
							// 得到下一个属性
							Attribute Attr = (Attribute) ne.next();
							String key = Attr.getID();
							// 读取属性值
							for (NamingEnumeration e = Attr.getAll(); e.hasMore();) {
								String value = e.next().toString();
								maps.put(key, value);
							}
						}
					}
				}

				Control[] controls = ctx1.getResponseControls();
				if (controls != null) {
					for (int i = 0; i < controls.length; i++) {
						if (controls[i] instanceof PagedResultsResponseControl) {
							PagedResultsResponseControl prrc = (PagedResultsResponseControl) controls[i];
							total = prrc.getResultSize();
							cookie = prrc.getCookie();
						} else {
						}
					}
				}

				ctx1.setRequestControls(new Control[] { new PagedResultsControl(pageSize, cookie, Control.CRITICAL) });
			} while (cookie != null);

		} catch (AuthenticationException e) {

			System.out.println(e);
		} catch (CommunicationException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (null != ctx) {
				try {
					ctx.close();
				} catch (Exception e) {
					e.getMessage();
				}
			}
		}

		return "success";

	}
}