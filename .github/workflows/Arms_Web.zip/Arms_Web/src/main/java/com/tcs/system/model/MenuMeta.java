package com.tcs.system.model;

public class MenuMeta {
    private String title;
    private String icon;
    private String target;
    private boolean show;
    
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}
	
	public String getTarget() {
		return target;
	}
	
	public void setTarget(String target) {
		this.target = target;
	}

	public void setShow(boolean show) {
		this.show = show;
	}
	
	public boolean getShow() {
		return show;
	}
}