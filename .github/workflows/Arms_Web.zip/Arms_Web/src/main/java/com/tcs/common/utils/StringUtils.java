package com.tcs.common.utils;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class StringUtils extends org.apache.commons.lang3.StringUtils {

	public final static String DATE_PATTERN = "yyyy-MM-dd";

	public final static String DATE_PATTERN_NEW = "yyyyMMdd";

	public final static String DATE_PATTERN_HOURS = "yyyy-MM-dd HH:mm";

	public final static String TIME_PATTERN = "HH:mm:ss";

	public final static String DATE_MONTH = "MM-dd";

	public final static String DATETIME_PATTERN = "yyyy-MM-dd HH:mm:ss";

	public static String addMonths(String pattern, int months, Date dt){
		Calendar c = Calendar.getInstance();
		c.setTime(dt);
		c.add(Calendar.MONTH, months);
		return formatDate(pattern, c.getTime());
	}
	
	public static String DateToYMD(Date date) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String dateStr = formatter.format(date);
		return dateStr;
	}

	public static String addHours(String pattern, int hours, Date dt) {
		Calendar c = Calendar.getInstance();
		c.setTime(dt);
		c.add(Calendar.HOUR, hours);
		return formatDate(pattern, c.getTime());
	}

	public static String addMinutes(String pattern, int minutes, Date dt)   {
		Calendar c = Calendar.getInstance();
		c.setTime(dt);
		c.add(Calendar.MINUTE, minutes);
		return formatDate(pattern, c.getTime());
	}

	public static Date addMinutes(int minutes, Date dt)   {
		Calendar c = Calendar.getInstance();
		c.setTime(dt);
		c.add(Calendar.MINUTE, minutes);
		return c.getTime();
	}

	public static String[] toStringArray(String string) {
		String[] stringarray = { "" };
		if (string != null) {
			StringTokenizer st = new StringTokenizer(string, ",");
			if (st.countTokens() > 0) {
				stringarray = new String[st.countTokens()];
				int index = 0;
				while (st.hasMoreTokens()) {
					stringarray[index++] = st.nextToken();
				}
			}
		}
		return stringarray;
	}

	public static String formatDate(String pattern, Date time)   {
		if (time == null) {
			return null;
		}
		SimpleDateFormat df = new SimpleDateFormat(pattern);
		return df.format(time);
	}
	
	public static Date formatDate(String dateStr) {
		Date date = null;
		try {
			java.text.DateFormat formatter = new java.text.SimpleDateFormat(
					"yyyy-MM-dd");
			dateStr = dateStr.trim();
			date = (java.util.Date) formatter.parse(dateStr);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			// e.printStackTrace(System.out);
			return null;
		}
		return date;
	}

	public static String Date2String() {
		Date myDate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String strDate = formatter.format(myDate);
		return strDate;
	}

	public static String formatDate2Short(String dateStr) {
		Date date = null;
		if (dateStr == null || dateStr.equals("")) {
			return "";
		}
		try {
			java.text.DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			dateStr = dateStr.trim();
			date = (Date)formatter.parse(dateStr);
			java.text.DateFormat formatter1 = new SimpleDateFormat("yyyyMMdd");
			return formatter1.format(date);
		} catch (Exception e) {
			e.printStackTrace();
			;
			return null;
		}

	}

	public static String formatDate2Long(String dateStr) {
		Date date = null;
		if (dateStr == null || dateStr.equals("")) {
			return "";
		}
		try {
			java.text.DateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			dateStr = dateStr.trim();
			date = (Date)formatter.parse(dateStr);
			java.text.DateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
			return formatter1.format(date);
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return null;
		}
	}

	public static List<String> convertString2List(String arg, String gapSymbol) {
		if (arg == null || "".equals(arg) || gapSymbol == null || "".equals(gapSymbol)) {
			return null;
		}
		List<String> result = new ArrayList<String>();
		String[] str = arg.split(gapSymbol);
		for (int index = 0; index < str.length; index++) {
			if (str[index] != null) {
				result.add(str[index]);
			}
		}
		return result;
	}

	public static String convertList2String(List<?> arg, String gapSymbol) {
		if (arg == null || arg.isEmpty() || gapSymbol == null || "".equals(gapSymbol)) {
			return null;
		}
		StringBuilder result = new StringBuilder();
		for (int index = 0; index < arg.size(); index++) {
			if (arg.get(index) != null) {
				result.append(arg.get(index) + gapSymbol);
			}
		}
		return result.substring(0, result.length() - 1).toString();
	}

	/**
	 * 把字符串转换为Long
	 * @param longStr
	 * @return
	 */
	public static Long setStringConvertLong(String longStr) {
		if (longStr == null || "".equals(longStr.trim())) {
			longStr = "0";
		}
		return Long.valueOf(longStr);
	}

	public static boolean isRealEmpty(String str) {
		return str == null || str.length() == 0 || str.trim().equals("") || str.trim().equals("null");
	}

	public static boolean isEmpty(Object str) {
		return str == null || StringUtils.isBlank(str.toString());
	}

	public static String getNowDate(Date date) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd  hh:mm:ss");
		return formatter.format(date);
	}

	public static Date stringToDate(String strDate, String pattern) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.parse(strDate);
	}

	public static Integer convertObjectToInteger(Object obj) {
		if (obj != null) {
			return new Integer(obj.toString());
		} else {
			return null;
		}
	}

	public static String formatMoney(double money) {
		DecimalFormat formatter = new DecimalFormat("###,##0.00");
		String result = formatter.format(money);
		if (".00".equals(result)) {
			result = "";
		}
		return result;
	}

	public static List<Date> getHoliday(String year, String month) throws ParseException {
		// 方法返回值
		List<Date> reList = new ArrayList<Date>();
		// 判断年份不能为空
		if (null == year || year.trim().length() == 0) {
			return null;
		}
		// 判断月份不能为空
		if (null == month || month.trim().length() == 0) {
			return null;
		}

		// 设置第一天
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		// 读取当前年月中的所有周六和周日信息，保持到List中
		Date date = sdf.parse(year + "-" + month + "-" + "1");
		cal.setTime(date);
		int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		for (int i = 1; i < maxDay; i++) {
			if (isWeekend(date)) {
				reList.add(date);
			}
			cal.add(Calendar.DATE, 1);// 把日期往后增加一天.整数往后推,负数往前移动
			date = cal.getTime(); // 这个时间就是日期往后推一天的结果
		}

		return reList;
	}

	public static List<String> getHolidayToString(String year, String month) throws ParseException {
		// 判断年份不能为空
		if (null == year || year.trim().length() == 0) {
			return null;
		}
		// 判断月份不能为空
		if (null == month || month.trim().length() == 0) {
			return null;
		}

		// 方法返回值
		List<String> reList = new ArrayList<String>();

		// 设置第一天
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		// 读取当前年月中的所有周六和周日信息，保持到List中
		Date date = sdf.parse(year + "-" + month + "-" + "1");
		cal.setTime(date);
		int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		for (int i = 1; i < maxDay; i++) {
			if (isWeekend(date)) {
				reList.add(formatDate(StringUtils.DATE_MONTH, date));
			}
			cal.add(Calendar.DATE, 1);// 把日期往后增加一天.整数往后推,负数往前移动
			date = cal.getTime(); // 这个时间就是日期往后推一天的结果
		}
		return reList;
	}

	/**
	 * 周六周日判断
	 * @param date
	 * @return
	 */
	public static boolean isWeekend(Date date) {
		boolean weekend = false;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
			weekend = true;
		}
		return weekend;
	}

	/**
	 * 自动升级版本号，版本号+1
	 * @param version
	 * @return
	 */
	public static String autoUpgradeVersion(String version) {
		if (null == version || "".equals(version)) {
			version = "1.0";
		}
		// 将版本号拆解成整数数组
		String[] arr = version.split("\\.");
		int[] ints = new int[arr.length];
		for (int i = 0; i < arr.length; i++) {
			ints[i] = Integer.valueOf(arr[i]);
		}

		// 递归调用
		autoUpgradeVersion(ints, ints.length - 1);

		// 数组转字符串
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < ints.length; i++) {
			sb.append(ints[i]);
			if ((i + 1) != ints.length) {
				sb.append(".");
			}
		}
		return sb.toString();
	}

	/**
	 * 自动升级版本号，版本号+1
	 * @param ints
	 * @param index
	 */
	private static void autoUpgradeVersion(int[] ints, int index) {
		if (index == 0) {
			ints[0] = ints[0] + 1;
		} else {
			int value = ints[index] + 1;
			if (value < 10) {
				ints[index] = value;
			} else {
				ints[index] = 0;
				autoUpgradeVersion(ints, index - 1);
			}
		}
	}
	
	public static String DateToYMDHMS(Date date) {
		if (date == null) {
			return "";
		}

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateStr = formatter.format(date);
		return dateStr;

	}



	public static String getUUID() {
		return UUID.randomUUID().toString().replace("-", "");
	}

}