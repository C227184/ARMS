package com.tcs.mail.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tcs.mail.pojo.BatchCompleteMail;

@Mapper
public interface BatchCompleteMailMapper extends BaseMapper<BatchCompleteMail> {



}