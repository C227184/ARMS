package com.tcs.arms.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class TaskSyncLog {

	private int id;

	private String taskName;

	private String syncFileName;

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
	private Date executeTime;

	private String message;

	private boolean syncFlag;

	private int mainId;
	
	private String executeType;

	public int getId() {

		return id;
	}

	public int getMainId() {

		return mainId;
	}

	public void setMainId(int mainId) {
		this.mainId = mainId;
	}

	public String getTaskName() {

		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getSyncFileName() {

		return syncFileName;
	}

	public void setSyncFileName(String syncFileName) {

		this.syncFileName = syncFileName;
	}

	public Date getExecuteTime() {

		return executeTime;
	}

	public void setExecuteTime(Date executeTime) {

		this.executeTime = executeTime;
	}

	public String getMessage() {

		return message;
	}

	public void setMessage(String message) {

		this.message = message;
	}

	public boolean getSyncFlag() {

		return syncFlag;
	}

	public void setSyncFlag(boolean syncFlag) {

		this.syncFlag = syncFlag;
	}
	
	public String getExecuteType() {

		return executeType;
	}

	public void setExecuteType(String executeType) {

		this.executeType = executeType;
	}
}