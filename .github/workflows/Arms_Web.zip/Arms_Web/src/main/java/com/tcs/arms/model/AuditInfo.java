package com.tcs.arms.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class AuditInfo {

	private int id;

	private int changeId;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date date;

	private int level;

	private String source;

	private String objectname;

	private String eventIdName;

	private int eventId;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date createdDate;

	private String createdBy;

	private String createdByFullName;

	private String computer;

	private String processId;

	private String message;

	private String data;

	private int mainId;

	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	private Date rowCreatedTime;

	public int getId() {

		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getChangeId() {

		return changeId;
	}

	public void setChangeId(int changeId) {
		this.changeId = changeId;
	}

	public int getMainId() {

		return mainId;
	}

	public void setMainId(int mainId) {
		this.mainId = mainId;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getLevel() {

		return level;
	}

	public void setLevel(int level) {

		this.level = level;
	}

	public String getSource() {

		return source;
	}

	public void setSource(String source) {

		this.source = source;
	}

	public String getObjectName() {

		return objectname;
	}

	public void setObjectName(String objectname) {

		this.objectname = objectname;
	}

	public String getEventIdName() {

		return eventIdName;
	}

	public void setEventIdName(String eventIdName) {

		this.eventIdName = eventIdName;
	}

	public int getEventId() {

		return eventId;
	}

	public void setEventId(int eventId) {

		this.eventId = eventId;
	}

	public Date getCreatedDate() {

		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {

		this.createdDate = createdDate;
	}

	public String getCreatedBy() {

		return createdBy;
	}

	public void setCreatedBy(String createdBy) {

		this.createdBy = createdBy;
	}

	public String getCreatedByFullName() {

		return createdByFullName;
	}

	public void setCreatedByFullName(String createdByFullName) {

		this.createdByFullName = createdByFullName;
	}

	public String getComputer() {

		return computer;
	}

	public void setComputer(String computer) {

		this.computer = computer;
	}

	public String getProcessId() {

		return processId;
	}

	public void setProcessId(String processId) {

		this.processId = processId;
	}

	public String getMessage() {

		return message;
	}

	public void setMessage(String message) {

		this.message = message;
	}

	public String getData() {

		return data;
	}

	public void setData(String data) {

		this.data = data;
	}

	public Date getRowCreatedTime() {
		return rowCreatedTime;
	}

	public void setRowCreatedTime(Date rowCreatedTime) {
		this.rowCreatedTime = rowCreatedTime;
	}

}