package com.tcs.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;


@Component
@ConfigurationProperties(prefix ="aad")
public class AzureConfig {

	private String clientId;
    private String authority;
    private String redirectUriSignin;
    private String redirectUriGraph;
    private String secretKey;
    private String msGraphEndpointHost;
    private String createEventUrl;
    private String proxIp;
    private Integer proxPort;
    private Boolean openProxy;


    public String getAuthority(){
        return authority;
    }


	public String getClientId() {
		return clientId;
	}


	public void setClientId(String clientId) {
		this.clientId = clientId;
	}


	public String getRedirectUriSignin() {
		return redirectUriSignin;
	}


	public void setRedirectUriSignin(String redirectUriSignin) {
		this.redirectUriSignin = redirectUriSignin;
	}


	public String getRedirectUriGraph() {
		return redirectUriGraph;
	}


	public void setRedirectUriGraph(String redirectUriGraph) {
		this.redirectUriGraph = redirectUriGraph;
	}


	public String getSecretKey() {
		return secretKey;
	}


	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}


	public String getMsGraphEndpointHost() {
		return msGraphEndpointHost;
	}


	public void setMsGraphEndpointHost(String msGraphEndpointHost) {
		this.msGraphEndpointHost = msGraphEndpointHost;
	}


	public String getCreateEventUrl() {
		return createEventUrl;
	}


	public void setCreateEventUrl(String createEventUrl) {
		this.createEventUrl = createEventUrl;
	}


	public String getProxIp() {
		return proxIp;
	}


	public void setProxIp(String proxIp) {
		this.proxIp = proxIp;
	}


	public Integer getProxPort() {
		return proxPort;
	}


	public void setProxPort(Integer proxPort) {
		this.proxPort = proxPort;
	}


	public Boolean getOpenProxy() {
		return openProxy;
	}


	public void setOpenProxy(Boolean openProxy) {
		this.openProxy = openProxy;
	}


	public void setAuthority(String authority) {
		this.authority = authority;
	}
    
    
}
