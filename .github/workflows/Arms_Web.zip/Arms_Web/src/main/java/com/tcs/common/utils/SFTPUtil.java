package com.tcs.common.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.ProxyHTTP;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class SFTPUtil {

	/**
	* 连接sftp服务器
	* @param host 主机
	* @param port 端口
	* @param username 用户名
	* @param password 密码
	* @return
	*/
	
	private String host;
	private Integer port=22;
	private String userName;
	private String password;
	
	
	public SFTPUtil (String host,Integer port,String userName,String password ) {
		this.host=host;
		this.port=port;
		this.userName=userName;
		this.password=password;
	}
	
	public ChannelSftp connect() {
		ChannelSftp sftp = null;
		try {
			JSch jsch = new JSch();
			Session sshSession = jsch.getSession(this.userName, this.host, this.port);
			System.out.println("Session created.");
			sshSession.setPassword(this.password);
			Properties sshConfig = new Properties();
			sshConfig.put("StrictHostKeyChecking", "no");
			sshSession.setConfig(sshConfig);
			sshSession.connect();
			System.out.println("Session connected.");
			System.out.println("Opening Channel.");
			Channel channel = sshSession.openChannel("sftp");
			channel.connect();
			sftp = (ChannelSftp) channel;
			System.out.println("Connected to " + host + ".");
		} catch (Exception e) {
               e.printStackTrace();
		}
		return sftp;
	}
	
	/**
	* 通过SOCKS5代理连接sftp服务器
	* @param host 主机
	* @param port 端口
	* @param username 用户名
	* @param password 密码
	* @param proxyHost 代理服务器的主机
	* @param proxyPort 代理服务器的端口
	* @param proxyName 代理服务器的用户名
	* @param proxyPwd 代理服务器的密码
	* @return
	*/
	public ChannelSftp connect(String host, int port, String username,
			String password,String proxyHost,int proxyPort,
			String proxyName,String proxyPwd) {
		ChannelSftp sftp = null;
		try {
			JSch jsch = new JSch();
			jsch.getSession(username, host, port);
			Session sshSession = jsch.getSession(username, host, port);
			
			//ProxySOCKS5 proxySOCKS5=new ProxySOCKS5(proxyHost, proxyPort); 
			//proxySOCKS5.setUserPasswd(proxyName, proxyPwd);
			
			ProxyHTTP proxyHTTP = new ProxyHTTP(proxyHost, proxyPort);
			proxyHTTP.setUserPasswd(proxyName, proxyPwd); 
			sshSession.setProxy(proxyHTTP);  
			System.out.println("Session created.");
			sshSession.setPassword(password);
			Properties sshConfig = new Properties();
			sshConfig.put("StrictHostKeyChecking", "no");
			sshSession.setConfig(sshConfig);
			sshSession.connect();
			System.out.println("Session connected.");
			System.out.println("Opening Channel.");
			Channel channel = sshSession.openChannel("sftp");
			channel.connect();
			sftp = (ChannelSftp) channel;
			System.out.println("Connected to " + host + ".");
		} catch (Exception e) {
               e.printStackTrace();
		}
		return sftp;
	}


	/**
	* 上传文件
	* @param directory 上传的目录
	* @param uploadFile 要上传的文件
	* @param sftp
	*/
	public void upload(String directory, String uploadFile, ChannelSftp sftp) {
		try {
			sftp.cd(directory);
			File file = new File(uploadFile);
			sftp.put(new FileInputStream(file), file.getName());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/**
	* 下载文件
	* @param directory 下载目录
	* @param downloadFile 下载的文件
	* @param saveFile 存在本地的路径
	* @param sftp
	*/

	public void download(String directory, String downloadFile,
			String saveFile, ChannelSftp sftp) {
		try {
			sftp.cd(directory);
			File file = new File(saveFile);
			sftp.get(downloadFile, new FileOutputStream(file));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/**
	* 删除文件
	* @param directory 要删除文件所在目录
	* @param deleteFile 要删除的文件
	* @param sftp
	*/
	public void delete(String directory, String deleteFile, ChannelSftp sftp) {
		try {
			sftp.cd(directory);
			sftp.rm(deleteFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	* 列出目录下的文件
	* @param directory 要列出的目录
	* @param sftp
	* @return
	* @throws SftpException
	*/
	public Vector listFiles(String directory, ChannelSftp sftp)
			throws SftpException {
		return sftp.ls(directory);
	}
	
	
	/**
	 * Gets file from remote host.
	 * 
	 * @param remore -
	 *            remote path
	 * @param os -
	 *            output stream
	 * @throws IOException
	 */
	public void get(String remore, OutputStream os
			, ChannelSftp sftp) {
		try {
			sftp.get(remore, os);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Posting report to SAP
	 * @param companyCode
	 * @param uploadFile
	 * @throws Exception
	 */
	public void uploadFileToSAPSFTP(String companyCode,String uploadFile) throws Exception{
		
		//目录
		String directory = "/airplus/0813/";
//		String directory = (String)((Map) FacesUtils.getConfigureMap()
//				.get("bayer.xml")).get("sap_sftp_url");
//		if(!StringUtils.isRealEmpty(directory)){
//			directory=directory+companyCode;
//		}
		String backupDirectory = "/BK/0813/";
//		String backupDirectory = (String)((Map) FacesUtils.getConfigureMap()
//				.get("bayer.xml")).get("sap_sftp_backup_url");
//		if(!StringUtils.isRealEmpty(directory)){
//			backupDirectory=backupDirectory+companyCode;
//		}
		
		File originalFile=new File(uploadFile);		
		if(!originalFile.exists()) {
			System.out.println("file not existing!");   
			return;
		}

		//[For 0813] 
		//Posting File: SXAP1ZETRIP.txt (unique for SAP to recognize) 
		//Backup file: SXAP1ZETRIP_yyyymmdd.txt 

		//[For 1566] 
		//Posting File: SXAP2ZETRIP.txt (unique for SAP to recognize) 
		//Backup file: SXAP2ZETRIP_yyyymmdd.txt 
		String yyyymmdd=DateUtils.format(new Date(),"yyyyMMdd");
		String fileName=null;
		String fileBackupName=null;
		if("0813".equals(companyCode)){
			fileName="MXAPJZETRIP.txt";   
			fileBackupName="MXAPJZETRIP_";
		}else if("0882".equals(companyCode)){
			fileName="SXCNAIRPLUSZETRIP.txt";
			fileBackupName="SXCNAIRPLUSZETRIP_";
		}else if("1566".equals(companyCode)){
			fileName="MXAPKZETRIP.txt";
			fileBackupName="MXAPKZETRIP_";
		}  else if("1554".equals(companyCode)){
			fileName="ZETRIP.txt";
			fileBackupName="ZETRIP_";
		}else if("1790".equals(companyCode)){
			fileName="ZETRIP.txt";
			fileBackupName="ZETRIP_";
		}else if("1705".equals(companyCode)){
			fileName="ZETRIP.txt";
			fileBackupName="ZETRIP_";
		} else if("1848".equals(companyCode)){
			fileName="ZETRIP.txt";
			fileBackupName="ZETRIP_";
		}else if("1836".equals(companyCode)){
			fileName="ZETRIP.txt";
			fileBackupName="ZETRIP_";
		}else if("0938".equals(companyCode)){
			fileName="MXAPMZETRIP.txt";
			fileBackupName="MXAPMZETRIP_";
		} else if ("0962".equals(companyCode)) {
		      fileName = "ZETRIP.txt";
		      fileBackupName = "ZETRIP_";
		} else{
			fileName="SXAP2ZETRIP.txt";
			fileBackupName="SXAP2ZETRIP_";
		}
		
		String targetFile = uploadFile.replaceAll(originalFile.getName(), fileName);
		String targetBackupFile = uploadFile.replaceAll(originalFile.getName(), fileBackupName+yyyymmdd+".txt");
		copyFile(originalFile,targetFile);
		copyFile(originalFile,targetBackupFile);
		//BCNSHGS0047.ap.bayer.cnb
		//IP:172.30.4.125
		//ChannelSftp sftp = sf.connect("BCNSHGS0047.ap.bayer.cnb", 22, "MYBZW", "SFS-China");
		ChannelSftp sftp = connect();
		try {
			System.out.println("begin upload file to SAP SFTP. fileName:"+targetFile);
			upload(directory, targetFile, sftp);
			System.out.println("end upload file to SAP SFTP.");
			System.out.println("begin upload bakup file to SAP SFTP. fileName:"+targetFile);
			upload(backupDirectory, targetBackupFile, sftp);
			System.out.println("end upload bakup file to SAP SFTP.");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			sftp.disconnect();
			System.out.println("finished");
		}
	}
	
	/**
	 * Posting report to SAP
	 * @param companyCode
	 * @param uploadFile
	 * @throws Exception
	 */
	public boolean hasFile(String path) throws Exception{
		boolean hasFile = false;
		
		//目录
		//String directory = "/airplus/PD/0813/";
//		String directory = (String)((Map) FacesUtils.getConfigureMap()
//				.get("bayer.xml")).get("sap_sftp_url");
//		if(!StringUtils.isRealEmpty(directory)){
////			directory=directory+companyCode;
//			
//		}

		ChannelSftp sftp = connect();
		try {
			Vector fileVector=listFiles(path, sftp);
			Iterator itr = fileVector.iterator();
			LsEntry entry;
			while (itr.hasNext()) {
				entry = (LsEntry) itr.next();
				System.out.println("file name:"+entry.getFilename());
				if(!entry.getFilename().equals("..")
						&& !entry.getFilename().equals(".")){
					hasFile=true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			sftp.disconnect();
			System.out.println("finished");
		}
		return hasFile;
	}
	/**
	 * copy file.
	 * @param originalFile
	 * @param targetFile
	 * @return
	 */
	public void copyFile(File originalFile
			, String targetFile) throws java.io.IOException {
		byte b[] = new byte[1024];
		FileInputStream fis = null;         
		FileOutputStream fos = null;
		File newFile = null;
		try {
			fis = new FileInputStream(originalFile); 
			newFile = new File(targetFile);
			if(!newFile.exists()) {
				newFile.createNewFile();              
			}else{
				//delete original file
				newFile.delete();
				newFile = new File(targetFile);
				if(!newFile.exists()) {
					newFile.createNewFile();  
				}
			}
			//获取输出到目标文件的输出流 
			fos = new FileOutputStream(newFile);
			//将输入流、输出流作为参数传进函数进行文件拷贝     
			
			int temp = 0;
			while ((temp = fis.read(b)) > 0) {
				fos.write(b, 0, temp);
			}
			fis.close();
			fos.close();
		} catch (IOException ex1) {
			if(fis!=null)
				fis.close();
			if(fos!=null)
				fos.close();
			throw ex1;
		}
	}

	public String getHost() {
		return host;
	}

	public void setHost(String hos) {
		this.host = host;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	

	
}