package com.tcs.arms.service;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.*;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Iterator;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tcs.common.utils.ConstInfo;
import com.tcs.arms.mapper.ArmsMapper;
import com.tcs.arms.model.AuditInfo;
import com.tcs.arms.model.MainInfo;
import com.tcs.arms.model.TaskSyncLog;

/*
 * 文件名：ResolveFileScheduleJob.java
 * 描述：数据文件同步
 * 作者：Haijun Huang
 * 创建时间：2023-06-01
*/

@Component
public class ResolveFileScheduleJob {

	@Autowired
	private TaskService taskService;

	/*
	 * 方法名：resolveXmlFile
	 * 描述：文件数据同步
	 * 作者：Haijun Huang
	 * 创建时间：2023-06-01
	*/
	//@Transactional
	@Scheduled(cron = "${schedule.update-ldap-users.cron}")
	public void resolveXmlFile() throws Exception {
		//taskService.resolveFile();
		taskService.resolveXmlFile();
	}
	
	
	/*
	 * 方法名：resolveStartedByName
	 * 描述：根据StartedByID更新StartedByName
	 * 作者：Haijun Huang
	 * 创建时间：2023-06-01
	*/
	@Scheduled(cron = "${schedule.update-ldap-usersname.cron}")
	public void resolveStartedByName() throws Exception {
		taskService.resolveStartedByName();
	}	
}