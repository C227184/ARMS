import request from '@/utils/request'

const api = {
  mainInfo: '/arms/queryMainInfo',
  auditInfo: '/arms/auditInfoList',
  taskLog: '/arms/taskSyncLog',
  operationLog: '/arms/operationLog',
  selectOperationLog:'/arms/selectPage',
  attributeControlInfo: '/arms/attributeControlInfo',
  attributeControlInfoIsActive: '/arms/attributeControlInfoIsActive',
  viewPdfFile: '/arms/getMainPdfFile',
  tableStructureInfo: '/arms/tableStructureInfo',
  saveAttributeControlInfo: '/arms/saveAttributeControlInfo',
  editAttributeControlInfo: '/arms/editAttributeControlInfo',
  deleteAttributeControlInfo: '/arms/deleteAttributeControlInfo',
  saveTaskSyncFilePath: '/arms/saveTaskSyncFilePath',
  taskSyncFilePathInfo: '/arms/getTaskSyncFilePathInfo',
  manualRunTask: '/arms/manualRunTask',
  exportMainInfoToExcel: '/arms/exportMainInfoToExcel',
  exportAuditInfoToExcel: '/arms/exportAuditInfoToExcel',
  login: '/arms/login'
}

export default api

export function Login(parameter) {
  return request({
    url: api.login,
    method: 'post',
    data: parameter
  })
}


export function GetMainInfoList(parameter) {
  return request({
    url: api.mainInfo,
    method: 'post',
    data: parameter
  })
}

export function GetAuditInfoList(parameter) {
  return request({
    url: api.auditInfo,
    method: 'get',
    params: parameter
  })
}

export function GetTaskSyncLogList(parameter) {
  return request({
    url: api.taskLog,
    method: 'post',
    data: parameter
  })
}

export function GetOperationLogList(parameter) {
  return request({
    url: api.operationLog,
    method: 'post',
    data: parameter
  })
}

export function SelectOperationLogList(parameter) {
  return request({
    url: api.selectOperationLog,
    method: 'get',
    params: parameter
  })
}

export function GetAttributeControlInfo(parameter) {
  return request({
    url: api.attributeControlInfo,
    method: 'get',
    params: parameter
  })
}

export function GetTableStructureInfo(parameter) {
  return request({
    url: api.tableStructureInfo,
    method: 'get',
    params: parameter
  })
}

export function GetAttributeControlInfoIsActive() {
  return request({
    url: api.attributeControlInfoIsActive,
    method: 'get'
  })
}

export function SaveAttributeControlInfo(parameter) {
  return request({
    url: api.saveAttributeControlInfo,
    method: 'post',
    data: parameter
  })
}

export function EditAttributeControlInfo(parameter) {
  return request({
    url: api.editAttributeControlInfo,
    method: 'post',
    data: parameter
  })
}

export function DeleteAttributeControlInfo(parameter) {
  return request({
    url: api.deleteAttributeControlInfo,
    method: 'get',
    params: parameter
  })
}


export function GetMainPdfFile(parameter) {
  return request({
    url: api.viewPdfFile,
    method: 'get',
    params: parameter,
    responseType: 'blob',
    header: { "Content-Type": 'multipart/form-data' }
  })
}

export function ExportMainInfoToExcel(parameter) {
  return request({
    url: api.exportMainInfoToExcel,
    method: 'post',
    data: parameter,
    //params: parameter,
    responseType: 'blob',
    header: { "Content-Type": 'multipart/form-data' }
  })
}

export function ExportAuditInfoToExcel(parameter) {
  return request({
    url: api.exportAuditInfoToExcel,
    method: 'get',
    //data:parameter,
    params: parameter,
    responseType: 'blob',
    header: { "Content-Type": 'multipart/form-data' }
  })
}


export function DownloadFile(res, fileName) {
  if (typeof window.navigator.msSaveBlob !== 'undefined') {
    window.navigator.msSaveBlob(new Blob([res]), fileName)
  }
  else {
    let blob = window.URL.createObjectURL(new Blob([res]))
    let link = document.createElement('a')
    link.style.display = 'none'
    link.href = blob
    link.setAttribute('download', fileName)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link) //下载完成移除元素
    window.URL.revokeObjectURL(blob) //释放掉 blob 对象
  }
}

export function SaveTaskSyncFilePath(parameter) {
  return request({
    url: api.saveTaskSyncFilePath,
    method: 'post',
    data: parameter
  })
}

export function GetTaskSyncFilePathInfo(parameter) {
  return request({
    url: api.taskSyncFilePathInfo,
    method: 'get',
    params: parameter
  })
}


export function manualRunTask(parameter) {
  return request({
    url: api.manualRunTask,
    method: 'get',
    params: parameter
  })
}