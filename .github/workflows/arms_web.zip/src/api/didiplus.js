import request from '@/utils/request'

const api = {
  processing: '/didiPlus/GetDidiProcessList',
  completed: '/didiPlus/GetDidiCompletedList',
  updateInvoice: '/didiPlus/UpdateDidiPlusFileWithInvoice',
  changeToProcess: '/didiPlus/ChangeToProcess',
  didiPlusPosting: '/didiPlus/DidiPosting',
  actionDidiCheckFile: '/didiPlus/ActionDidiCheckFile',
  getDidiPostingFile: '/didiPlus/GetDidiPostingFile',
  downFileForDidiPlusXLS: '/didiPlus/DownFileForDidiPlusXLS',
  downFileCompletedDetatils: '/didiPlus/DownFileCompletedDetatils',
  companyCodeData: '/company/GetAllCompany'
}

export default api

export function GetDidiPlusProcessList(parameter) {
  return request({
    url: api.processing,
    method: 'get',
    params: parameter
  })
}


export function GetDidiPlusCompletedList(parameter) {
  return request({
    url: api.completed,
    method: 'get',
    params: parameter
  })
}

export function UpdateInvoice(parameter) {
  return request({
    url: api.updateInvoice,
    method: 'post',
    params: parameter
  })
}

export function ChangeToProcess(parameter) {
  return request({
    url: api.changeToProcess,
    method: 'post',
    params: parameter
  })
}

export function DidiPlusDoPosting(parameter) {
  return request({
    url: api.didiPlusPosting,
    method: 'post',
    params: parameter
  })
}

export function ActionDidiCheckFile(parameter) {
  return request({
    url: api.actionDidiCheckFile,
    method: 'post',
    params: parameter
  })
}

export function GetDidiPostingFile(parameter) {
  return request({
    url: api.getDidiPostingFile,
    method: 'post',
    params: parameter
  })
}

export function DownFileForDidiPlusXLS(parameter) {
  return request({
    url: api.downFileForDidiPlusXLS,
    method: 'get',
    params: parameter,
    responseType: 'blob'
  })
}

export function DownFileCompletedDetatils(parameter) {
  return request({
    url: api.downFileCompletedDetatils,
    method: 'get',
    params: parameter,
    responseType: 'blob'
  })
}


function GetNowTime() {
  var date = new Date();
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var monthStr = month >= 10 ? month : "0" + month;
  var day = date.getDate();
  var dayStr = day >= 10 ? day : "0" + day;
  var hour = date.getHours() < 10 ? "0" + date.getHours() : date.getHours();
  var minute = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
  var second = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
  return year + "-" + monthStr + "-" + dayStr + " " + hour + "-" + minute + "-" + second;
}

export function DownloadFileXLS(res, fileName) {
  if (typeof window.navigator.msSaveBlob !== 'undefined') {
    window.navigator.msSaveBlob(new Blob([res]), fileName)
  }
  else {
    let blob = window.URL.createObjectURL(new Blob([res]))
    let link = document.createElement('a')
    link.style.display = 'none'
    link.href = blob
    link.setAttribute('download', fileName)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link) //下载完成移除元素
    window.URL.revokeObjectURL(blob) //释放掉 blob 对象
  }
}


export function GetAllCompanyData() {
  return request({
    url: api.companyCodeData,
    method: 'get'
  })
}