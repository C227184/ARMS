import request from '@/utils/request'
import { ACCESS_TOKEN } from '@/store/mutation-types'
import { downloadExcelLocation } from '@/utils/util'
import storage from 'store'

const airPlusApi = {
    processList:'airplus/processList',
    detailList:'airplus/detailList',
    getInvoiceById:'airplus/getInvoiceById',
    saveInvoiceById:'airplus/saveInvoice',
    downLoad:'airplus/downLoad',
    saveAction:'airplus/saveAction',
    acceptAction:'airplus/acceptAction',
    cancelAction:'airplus/cancelAction',
    doPosting:"airplus/actionPosting",
    queryLockStatus:"airplus/getLockDetail",
    getCostCenter:'airplus/getCostCenter'
  }

export default airPlusApi


export function getCostCenter(param){
  return request({
    url: airPlusApi.getCostCenter,
    method: 'get',
    params: param
    })
}

export function getLockCostCenter(param){
  return request({
    url: airPlusApi.queryLockStatus,
    method: 'get',
    params: param
    })
}

export function getProcessList(param) {
    return request({
        url: airPlusApi.processList,
        method: 'get',
        params: param
        })
      }

export function getDetailList(param) {
    return request({
        url: airPlusApi.detailList,
        method: 'get',
        params: param
        })
      }

export function getInvoiceById(param) {
    return request({
      url: airPlusApi.getInvoiceById,
      method: 'get',
      params: param
      })
    }

export function saveInvoiceById(param){
  return request({
    url: airPlusApi.saveInvoiceById,
    method: 'post',
    data: param
  })
}

export function saveDetailInfo(param){
  return request({
    url: airPlusApi.saveAction,
    method: 'post',
    data: param
  })
}

export function acceptDetailInfo(param){
  return request({
    url: airPlusApi.acceptAction,
    method: 'post',
    data: param
  })
}

export function cancelDetailInfo(param){
  return request({
    url: airPlusApi.cancelAction,
    method: 'post',
    data: param
  })
}

export function doPosting(param){
  return request({
    url: airPlusApi.doPosting,
    method: 'post',
    data: param
  })
}


export function downLoad(param){
  return request({
    url: airPlusApi.downLoad,
    method: 'get',
    params: param,
  responseType: 'blob'
  })
  // let url = `${airPlusApi.downLoad}?token=${storage.get(ACCESS_TOKEN)}&fileId=`+param
  // downloadExcelLocation(url)
}


export function DownloadFileXLS(res, fileName) {
  if (typeof window.navigator.msSaveBlob !== 'undefined') {
    window.navigator.msSaveBlob(new Blob([res]), fileName)
  }
  else {
    let blob = window.URL.createObjectURL(new Blob([res]))
    let link = document.createElement('a')
    link.style.display = 'none'
    link.href = blob
    link.setAttribute('download', fileName)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link) //下载完成移除元素
    window.URL.revokeObjectURL(blob) //释放掉 blob 对象
  }
}