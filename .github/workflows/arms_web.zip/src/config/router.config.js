// eslint-disable-next-line
import { UserLayout, BasicLayout, BlankLayout } from '@/layouts'
import { bxAnaalyse } from '@/core/icons'

const RouteView = {
  name: 'RouteView',
  render: h => h('router-view')
}

export const asyncRouterMap = [
  {
    path: '/',
    name: 'index',
    component: BasicLayout,
    meta: { title: 'menu.home' },
    redirect: '/report/mainInfo',
    children: [
      {
        path: '/report',
        name: 'report',
        component: RouteView,
        redirect: '/report/mainInfo',
        meta: { title: 'menu.report.display', icon: 'table' },
        children: [
          {
            path: '/report/mainInfo',
            name: 'reportDisplay',
            component: () => import('@/views/report/mainInfo'),
            meta: { title: 'menu.report.display', keepAlive: true }
          },
          {
            path: '/report/auditInfo',
            name: 'reportAuditInfo',
            hidden: true,
            component: () => import('@/views/report/auditInfo'),
            meta: { title: 'menu.report.detail', keepAlive: true }
          },
          {
            path: '/report/viewPdf',
            name: 'viewPdf',
            hidden: true,
            component: () => import('@/views/report/vuePdf'),
            meta: { title: 'viewPdf', keepAlive: true }
          }
        ]
      },
      {
        path: '/task',
        name: 'taskLog',
        component: RouteView,
        redirect: '/task/taskLog',
        meta: { title: 'menu.task.execute.result', icon: 'check-circle-o' },
        children: [
          {
            path: '/task/taskLog',
            name: 'TaskResult',
            component: () => import('@/views/task/taskLog'),
            meta: { title: 'menu.task.execute.result', hiddenHeaderContent: false, keepAlive: true }
          }
        ]
      },
      {
        path: '/behavior',
        name: 'behavior',
        component: RouteView,
        redirect: '/behavior/operationLog',
        meta: { title: 'menu.user.tracking', icon: 'profile' },
        children: [
          {
            path: '/behavior/operationLog',
            name: 'userBehavior',
            component: () => import('@/views/behavior/operationLog'),
            meta: { title: 'menu.user.behavior', keepAlive: true }
          }
        ]
      },
      {
        path: '/system',
        name: 'system',
        component: RouteView,
        redirect: '/system/config',
        meta: { title: 'menu.system.config', icon: 'layout', permission: ['admin'] },
        children: [
          {
            path: '/system/config',
            name: 'systemConfig',
            component: () => import('@/views/system/config'),
            meta: { title: 'menu.system.config', keepAlive: true }
          }
        ]
      }
    ]
  },
  {
    path: '*',
    redirect: '/404',
    hidden: true
  }
]

/**
 * 基础路由
 * @type { *[] }
 */
export const constantRouterMap = [
  {
    path: '/user',
    component: UserLayout,
    redirect: '/user/login',
    hidden: true,
    children: [
      {
        path: 'login',
        name: 'login',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Login')
      },
      {
        path: 'register',
        name: 'register',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Register')
      },
      {
        path: 'register-result',
        name: 'registerResult',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/RegisterResult')
      },
      {
        path: 'recover',
        name: 'recover',
        component: undefined
      }
    ]
  },
  {
    path: '/404',
    component: () => import('@/views/exception/404')
  }
]