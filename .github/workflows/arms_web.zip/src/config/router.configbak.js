// eslint-disable-next-line
import { UserLayout, BasicLayout, BlankLayout } from '@/layouts'
import { bxAnaalyse } from '@/core/icons'

const RouteView = {
  name: 'RouteView',
  render: h => h('router-view')
}

export const asyncRouterMap = [
  {
    path: '/',
    name: 'index',
    component: BasicLayout,
    meta: { title: 'menu.home' },
    redirect: '/report/mainInfo',
    children: [
      {
        path: '/report',
        name: 'report',
        component: RouteView,
        redirect: '/report/mainInfo',
        meta: { title: 'menu.report.display', icon: 'table' },
        children: [
          {
            path: '/report/mainInfo',
            name: 'reportDisplay',
            component: () => import(/* webpackChunkName: "result" */ '@/views/report/mainInfo'),
            meta: { title: 'menu.report.display', keepAlive: true }
          },
          {
            path: '/report/auditInfo',
            name: 'reportAuditInfo',
            hidden: true,
            component: () => import(/* webpackChunkName: "result" */ '@/views/report/auditInfo'),
            meta: { title: 'menu.report.detail', keepAlive: true }
          },
          {
            path: '/report/viewPdf',
            name: 'viewPdf',
            hidden: true,
            component: () => import(/* webpackChunkName: "result" */ '@/views/report/vuePdf'),
            meta: { title: 'viewPdf', keepAlive: true }
          }
        ]
      },
      {
        path: '/task',
        name: 'taskLog',
        component: RouteView,
        redirect: '/task/taskLog',
        meta: { title: 'menu.task.execute.result', icon: 'check-circle-o', permission: ['task'] },
        children: [
          {
            path: '/task/taskLog',
            name: 'TaskResult',
            component: () => import('@/views/task/taskLog'),
            meta: { title: 'menu.task.execute.result', keepAlive: true, permission: ['task'] }
          }
        ]
      },
      {
        path: '/behavior',
        name: 'behavior',
        component: RouteView,
        redirect: '/behavior/operationLog',
        meta: { title: 'menu.user.tracking', icon: 'profile', permission: ['behavior'] },
        children: [
          {
            path: '/behavior/operationLog',
            name: 'userBehavior',
            component: () => import(/* webpackChunkName: "result" */ '@/views/behavior/operationLog'),
            meta: { title: 'menu.user.behavior', keepAlive: true, permission: ['behavior'] }
          }
        ]
      },
      {
        path: '/system',
        name: 'system',
        component: RouteView,
        redirect: '/system/config',
        meta: { title: 'menu.system.config', icon: 'layout', permission: ['admin'] },
        children: [
          {
            path: '/system/config',
            name: 'systemConfig',
            component: () => import(/* webpackChunkName: "result" */ '@/views/system/config'),
            meta: { title: 'menu.system.config', keepAlive: true, permission: ['admin'] }
          }
        ]
      },
      // account
      {
        path: '/account',
        component: RouteView,
        redirect: '/account/center',
        name: 'account',
        hidden: true,
        meta: { title: 'menu.account', icon: 'user', keepAlive: true, permission: ['user'] },
        children: [
          {
            path: '/account/center',
            name: 'center',
            component: () => import('@/views/account/center'),
            meta: { title: 'menu.account.center', keepAlive: true, permission: ['user'] }
          },
          {
            path: '/account/settings',
            name: 'settings',
            component: () => import('@/views/account/settings/Index'),
            meta: { title: 'menu.account.settings', hideHeader: true, permission: ['user'] },
            redirect: '/account/settings/basic',
            hideChildrenInMenu: true,
            children: [
              {
                path: '/account/settings/basic',
                name: 'BasicSettings',
                component: () => import('@/views/account/settings/BasicSetting'),
                meta: { title: 'account.settings.menuMap.basic', hidden: true, permission: ['user'] }
              },
              {
                path: '/account/settings/security',
                name: 'SecuritySettings',
                component: () => import('@/views/account/settings/Security'),
                meta: {
                  title: 'account.settings.menuMap.security',
                  hidden: true,
                  keepAlive: true,
                  permission: ['user']
                }
              },
              {
                path: '/account/settings/custom',
                name: 'CustomSettings',
                component: () => import('@/views/account/settings/Custom'),
                meta: { title: 'account.settings.menuMap.custom', hidden: true, keepAlive: true, permission: ['user'] }
              },
              {
                path: '/account/settings/binding',
                name: 'BindingSettings',
                component: () => import('@/views/account/settings/Binding'),
                meta: { title: 'account.settings.menuMap.binding', hidden: true, keepAlive: true, permission: ['user'] }
              },
              {
                path: '/account/settings/notification',
                name: 'NotificationSettings',
                component: () => import('@/views/account/settings/Notification'),
                meta: {
                  title: 'account.settings.menuMap.notification',
                  hidden: true,
                  keepAlive: true,
                  permission: ['user']
                }
              }
            ]
          }
        ]
      },
      {
        path: '/exception',
        name: 'exception',
        component: RouteView,
        redirect: '/exception/403',
        hidden:true,
        meta: { title: 'menu.exception', icon: 'warning', permission: ['exception'] },
        children: [
          {
            path: '/exception/403',
            name: 'Exception403',
            component: () => import('@/views/exception/403'),
            meta: { title: 'menu.exception.not-permission', permission: ['exception'] }
          },
          {
            path: '/exception/404',
            name: 'Exception404',
            component: () => import('@/views/exception/404'),
            meta: { title: 'menu.exception.not-find', permission: ['exception'] }
          },
          {
            path: '/exception/500',
            name: 'Exception500',
            component: () => import('@/views/exception/500'),
            meta: { title: 'menu.exception.server-error', permission: ['exception'] }
          }
        ]
      }
    ]
  },
  {
    path: '*',
    redirect: '/404',
    hidden: true
  }
]

/**
 * 基础路由
 * @type { *[] }
 */
export const constantRouterMap = [
  {
    path: '/user',
    component: UserLayout,
    redirect: '/user/login',
    hidden: true,
    children: [
      {
        path: 'login',
        name: 'login',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Login')
      },
      {
        path: 'register',
        name: 'register',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Register')
      },
      {
        path: 'register-result',
        name: 'registerResult',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/RegisterResult')
      },
      {
        path: 'recover',
        name: 'recover',
        component: undefined
      }
    ]
  },

  {
    path: '/404',
    component: () => import('@/views/exception/404')
  }
]