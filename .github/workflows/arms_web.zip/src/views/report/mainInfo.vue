<template>
  <page-header-wrapper :title="false">
    <a-card :bordered="false">
      <div class="table-page-search-wrapper">
        <a-form layout="inline" size="small">
          <a-row :gutter="24" size="small">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="StartDate">
                <a-range-picker @change="onChange" v-model="selectTime" :show-time="{
                  hideDisabledOptions: true,
                  defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                }" format="YYYY-MM-DD HH:mm:ss" />
                <a-input v-model="queryParam.startTime" placeholder="" v-show="false" />
                <a-input v-model="queryParam.endTime" placeholder="" v-show="false" />
              </a-form-item>
            </a-col>
            <a-col :md="!advanced && 8 || 24" :sm="24">
              <span class="table-page-search-submitButtons"
                :style="advanced && { float: 'right', overflow: 'hidden' } || {}">
                <a-button type="primary" shape="round" @click="$refs.table.refresh(true)">Search</a-button>
                <a-button style="margin-left: 8px" shape="round" @click="resetSearchControl()">Reset</a-button>
                <a-button style="margin-left: 8px" type="primary" shape="round" @click="ExportData()">Export
                  Data</a-button>
              </span>
            </a-col>
          </a-row>

          <a-row :gutter="24" size="small" v-show="isArchive">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="ArchiveDate">
                <a-range-picker @change="onArchiveChange" v-model="selectArchiveTime" :show-time="{
                  hideDisabledOptions: true,
                  defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                }" format="YYYY-MM-DD HH:mm:ss" />
                <a-input v-model="queryParam.startArchiveTime" placeholder="" v-show="false" />
                <a-input v-model="queryParam.endArchiveTime" placeholder="" v-show="false" />
              </a-form-item>
            </a-col>
          </a-row>

          <a-row :gutter="24" size="small" v-show="isComplete">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="CompleteDate">
                <a-range-picker @change="onCompleteChange" v-model="selectCompleteTime" :show-time="{
                  hideDisabledOptions: true,
                  defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                }" format="YYYY-MM-DD HH:mm:ss" />
                <a-input v-model="queryParam.startCompleteTime" placeholder="" v-show="false" />
                <a-input v-model="queryParam.endCompleteTime" placeholder="" v-show="false" />
              </a-form-item>
            </a-col>
          </a-row>

          <a-row :gutter="24" size="small" v-show="isCalibration">
            <a-col :md="24" :sm="24" size="small">
              <a-form-item label="LastCalibrationDate">
                <a-range-picker @change="onCalibrationChange" v-model="selectCalibrationTime" :show-time="{
                  hideDisabledOptions: true,
                  defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                }" format="YYYY-MM-DD HH:mm:ss" />
                <a-input v-model="queryParam.startCalibrationTime" placeholder="" v-show="false" />
                <a-input v-model="queryParam.endCalibrationTime" placeholder="" v-show="false" />
              </a-form-item>
            </a-col>
          </a-row>

          <a-row :gutter="24" size="small" v-show="isBatchID">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="BatchID">
                <a-input v-model="queryParam.BatchID" />
              </a-form-item>
            </a-col>
          </a-row>

          <a-row :gutter="24" size="small" v-show="isTestName">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="TestName">
                <a-input v-model="queryParam.TestName" />
              </a-form-item>
            </a-col>
          </a-row>

          <a-row :gutter="24" size="small" v-show="isStartedBy">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="StartedBy">
                <a-input v-model="queryParam.StartedBy" />
              </a-form-item>
            </a-col>
          </a-row>

          <a-row :gutter="24" size="small" v-show="isInstrumentSerialNumber">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="InstrumentSerialNumber">
                <a-input v-model="queryParam.InstrumentSerialNumber" />
              </a-form-item>
            </a-col>
          </a-row>

          <a-row :gutter="24" size="small" v-show="isTestPassed">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="TestPassed">
                <a-select v-model="queryParam.TestPassed">
                  <a-select-option value="1" key="1">PASSED</a-select-option>
                  <a-select-option value="0" key="0">FAILED</a-select-option>
                  <a-select-option value="2" key="2">INVALID</a-select-option>
                  <a-select-option value="99" key="99">NULL</a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
          </a-row>

          <a-row :gutter="24" size="small" v-show="isRunNotes">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="RunNotes">
                <a-input v-model="queryParam.RunNotes" />
              </a-form-item>
            </a-col>
          </a-row>
          <a-row :gutter="24" size="small" v-show="isSelfCheckPassed">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="SelfCheckPassed">
                <a-select v-model="queryParam.SelfCheckPassed">
                  <a-select-option value="1" key="1">PASSED</a-select-option>
                  <a-select-option value="0" key="0">FAILED</a-select-option>
                  <a-select-option value="2" key="2">INVALID</a-select-option>
                  <a-select-option value="99" key="99">NULL</a-select-option>
                </a-select>
              </a-form-item>
            </a-col>
          </a-row>
          <a-row :gutter="24" size="small" v-show="isTestDescription">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="TestDescription">
                <a-input v-model="queryParam.TestDescription" />
              </a-form-item>
            </a-col>
          </a-row>
          <!--<a-row style="height: 20px;" :gutter="24" v-for="item in attributeControlInfo" :key="item.id">
            <a-col :md="8" :sm="24">
              <a-form-item :label="item.name">
                <a-input v-model="queryParam[item.name]" />
              </a-form-item>
            </a-col>
          </a-row> -->
        </a-form>
      </div>

      <s-table ref="table" size="small" rowKey="mainId" :columns="columns" :data="loadData" :alert="false"
        :loading="loading" showPagination="auto" :scroll="{ x: 3500 }" :row-class-name="setRowClassName">
        <!--<template #footer>Footer</template>-->
        <span slot="serial" slot-scope="text, record, index">
          {{ index + 1 }}
        </span>
        <span slot="status" slot-scope="text">
          <a-badge :status="text | statusTypeFilter" :text="text | statusFilter" />
        </span>

        <span slot="testPassed" slot-scope="text">
          {{ text === '1' ? 'Passed' : 'Not Passed' }}
        </span>

        <span slot="actionAudit" slot-scope="text, record">
          <template>
            <a @click="viewAuditInfo(record)">View</a>
          </template>
        </span>
        <span slot="actionPdf" slot-scope="text, record">
          <template>
            <a style="display: none;;" @click="downLoadPdf(record)">DownLoad</a>
            <a @click="viewPdf(record)">View</a>
          </template>
        </span>
      </s-table>

      <a-modal defaultFullscreen="true" :fullscreen="true" :bodyStyle="{ padding: 0 }" :destroyOnClose="true"
        :visible="previewShow" width="100%" :closable="true" :footer="null" :maskClosable="false"
        @cancel="() => { previewShow = false }" cancelText="Close" wrap-class-name="full-modal">
        <a-spin :spinning="previewLoading" :delay="100">
          <span style="position:fixed;right:12px;top:12px;">
            <a-button type="primary" danger shape="circle" @click="() => { previewShow = false }"></a-button>
          </span>
          <iframe :src='pdfUrl + "#view=FitH,top"' border="0" frameborder="0" allowfullscreen="true"
            style="width: 100%; height: 99vh"></iframe>
          <!--#view=FitH,top"-->
        </a-spin>
      </a-modal>

    </a-card>
  </page-header-wrapper>
</div></template>
  
<script>
import moment from 'moment'
import { STable, Ellipsis } from '@/components'
import { GetMainInfoList, GetMainPdfFile, GetAttributeControlInfoIsActive, ExportMainInfoToExcel, DownloadFile } from '@/api/arms'
import pdf from 'vue-pdf'
import { lowerCase } from 'lodash'

const columns = [
  {
    title: 'BatchID',
    width: 90,
    dataIndex: 'batchId',
    ellipsis: true
  },
  {
    title: 'StartedBy',
    width: 100,
    dataIndex: 'startedBy'
  },
  {
    title: 'UserName',
    width: 100,
    dataIndex: 'startedByName'
  },
  {
    title: 'TestPassed',
    width: 90,
    dataIndex: 'testPassed',
    customRender: (text, row, index) => {
      if (text == "0") return 'FAILED'
      else if (text == "1") return 'PASSED'
      else if (text == "2") return 'INVALID'
      else if (text == "99") return 'NULL'
      else return ''
    }
  },
  {
    title: 'TestName',
    width: 180,
    dataIndex: 'testName',
    ellipsis: true
  },
  {
    title: 'TestDescription',
    width: 230,
    dataIndex: 'testDescription',
    ellipsis: true
  },
  {
    title: 'StartDate',
    width: 140,
    dataIndex: 'startDate'
    //sorter: true
  },
  {
    title: 'RunNotes',
    width: 230,
    dataIndex: 'runNotes',
    ellipsis: true
  },
  {
    title: 'ArchiveDate',
    width: 140,
    dataIndex: 'archiveDate'
    //sorter: true
  },
  {
    title: 'CompleteDate',
    width: 140,
    dataIndex: 'completeDate'
    //sorter: true
  },
  {
    title: 'FlowRate',
    width: 90,
    dataIndex: 'flowRate'
  },
  {
    title: 'FlowRateAtConst',
    width: 140,
    dataIndex: 'flowRateAtConst'
  },
  {
    title: 'ActualTestPressure',
    width: 140,
    dataIndex: 'actualTestPressure'
  },
  {
    title: 'SystemSize',
    width: 140,
    dataIndex: 'systemSize'
  },
  {
    title: 'FilterSize',
    width: 120,
    dataIndex: 'filterSize'
  },
  {
    title: 'InstrumentSerialNumber',
    width: 170,
    dataIndex: 'instrumentSerialNumber'
  },
  {
    title: 'SelfCheckPassed',
    width: 140,
    dataIndex: 'selfCheckPassed',
    customRender: (text, row, index) => {
      if (text == "0") return 'FAILED'
      else if (text == "1") return 'PASSED'
      else if (text == "2") return 'INVALID'
      else if (text == "99") return 'NULL'
      else return ''
    }
    //scopedSlots: { customRender: 'testPassed' }
  },

  {
    title: 'NumOfRounds',
    width: 100,
    dataIndex: 'numOfRounds'
  },

  {
    title: 'LastCalibrationDate',
    width: 140,
    dataIndex: 'lastCalibrationDate'
    //sorter: true
  },
  {
    title: 'CalibrationOverdue',
    width: 140,
    dataIndex: 'calibrationOverdue'
  },
  {
    title: 'SizeAtTemperature',
    width: 140,
    dataIndex: 'sizeAtTemperature'
  },
  {
    title: 'Audit',
    width: 80,
    scopedSlots: { customRender: 'actionAudit' },
    fixed: 'right',
  },
  {
    title: 'Report Link',
    width: 120,
    scopedSlots: { customRender: 'actionPdf' },
    fixed: 'right',
  }
]

export default {
  name: 'TableList',
  components: {
    STable,
    Ellipsis,
    pdf,
    moment
  },
  data() {
    this.columns = columns
    return {
      // create model
      visible: false,
      loading: false,
      confirmLoading: false,
      mdl: null,
      // 高级搜索 展开/关闭
      advanced: false,
      // 查询参数
      queryParam: {},
      //attributeControlInfo: [],
      // 加载数据方法 必须为 Promise 对象
      loadData: parameter => {
        //console.log(parameter)
        const requestParameters = Object.assign({}, parameter, this.queryParam)
        //console.log('loadData request parameters:', requestParameters)
        return GetMainInfoList(requestParameters)
          .then(res => {
            if (res.status == '500') {
              this.$message.error(res.message)
              return;
            }
            return res.result
          })
      },
      selectedRowKeys: [],
      selectedRows: [],
      size: 'small',
      numPages: 0,
      pdfSrc: '',
      pdfUrl: '',
      previewShow: false,
      previewLoading: false,
      startTime: null,
      endTime: null,
      selectTime: [],
      startArchiveTime: null,
      endArchiveTime: null,
      selectArchiveTime: [],

      startCompleteTime: null,
      endCompleteTime: null,
      selectCompleteTime: [],

      startCalibrationTime: null,
      endCalibrationTime: null,
      selectCalibrationTime: [],
      isArchive: false,
      isComplete: false,
      isBatchID: false,
      isCalibration: false,
      isRunNotes: false,
      isSelfCheckPassed: false,
      isStartedBy: false,
      isInstrumentSerialNumber: false,
      isTestName: false,
      isTestDescription: false,
      isTestPassed: false
    }
  },
  mounted() {
    //this.fetch();
  },
  filters: {
    statusFilter(type) {
      return statusMap[type].text
    },
    statusTypeFilter(type) {
      return statusMap[type].status
    }
  },
  computed: {
    rowSelection() {
      return {
        selectedRowKeys: this.selectedRowKeys,
        //selectedRows: this.selectedRows,
        onChange: this.onSelectChange
      }
    }
  },
  created() {
    this.loadAttributeControlInfo()
    this.initTime()
  },
  methods: {
    moment,
    setRowClassName(record, index) {
      let rowSTyle = null
      if (record.testPassed !== "1" || record.testPassed != true) {
        return "table-striped_click"
      } else {
        return rowSTyle
      }
    },
    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
    },
    initTime() {
      this.selectTime = []
      this.selectTime = [moment().utcOffset(8).subtract(1, 'month').format('YYYY-MM-DD')]
      this.queryParam.startTime = this.selectTime[0]
    },
    loadAttributeControlInfo() {
      return GetAttributeControlInfoIsActive()
        .then(res => {
          //console.log(res)
          //console.log(res.result)
          if (res != null) {
            if (res.result == null) {
              return;
            }
            res.result.forEach((r) => {
              let attName = r.attributeName;
              if (attName.toLowerCase() == "archivedate") {
                this.isArchive = true;
              }
              if (attName.toLowerCase() == "completedate") {
                this.isComplete = true;
              }
              if (attName.toLowerCase() == "batchid") {
                this.isBatchID = true;
              }
              if (attName.toLowerCase() == "testname") {
                this.isTestName = true;
              }
              if (attName.toLowerCase() == "testpassed") {
                this.isTestPassed = true;
              }
              if (attName.toLowerCase() == "testdescription") {
                this.isTestDescription = true;
              }
              if (attName.toLowerCase() == "runnotes") {
                this.isRunNotes = true;
              }
              //debugger
              if (attName.toLowerCase() == "lastcalibrationdate") {
                this.isCalibration = true;
              }
              if (attName.toLowerCase() == "startedby") {
                this.isStartedBy = true;
              }
              if (attName.toLowerCase() == "instrumentserialnumber") {
                this.isInstrumentSerialNumber = true;
              }
              if (attName.toLowerCase() == "selfcheckpassed") {
                this.isSelfCheckPassed = true;
              }
              //this.attributeControlInfo.push({ id: r.attributeId, name: r.attributeName });
            });
          }
        }).catch(ex => {
          return;
        })
    },
    fetch(parameter = {}) {
      this.loading = true;
      this.queryParam
      const requestParameters = { pageNo: 1, pageSize: 10 }
      return GetMainInfoList(requestParameters)
        .then(res => {
          //console.log(res);
          if (res.status == '500') {
            this.$message.error(res.message)
            //this.$refs.table.refresh()
            return;
          }
          return res.result
        })
    },
    viewAuditInfo(record) {
      this.$router.push({ path: '/report/auditInfo', query: { mainId: record.mainId } });
    },
    downLoadPdf(record) {
      //this.spinning = true;
      let params = { 'mainId': record.mainId }
      //接口函数传入id,返回的文件流
      GetMainPdfFile(params).then(res => {
        //console.log(res);
        DownloadFile(res, record.pdfFileName);
      }
      )
    },
    ExportData() {
      const requestParameters = Object.assign({}, '', this.queryParam)
      //接口函数传入id,返回的文件流
      ExportMainInfoToExcel(requestParameters).then(res => {
        let fileName = moment().utcOffset(8).format('YYYY-MM-DD HH:mm:ss') + "_MainInfo.xls";
        DownloadFile(res, fileName);
      }
      )
    },
    viewPdf(record) {
      let params = { 'mainId': record.mainId }
      //接口函数传入id,返回的文件流
      GetMainPdfFile(params).then(res => {
        this.previewShow = true;
        this.previewLoading = true;

        this.pdfUrl = this.getObjectUrl(res)

        this.previewLoading = false;
      }
      )
    },
    getObjectUrl(data) {
      let url = null
      var binaryData = []
      binaryData.push(data);
      let file = new Blob(binaryData, { type: "application/pdf" });
      if (window.createObjectURL != undefined) {
        // 通用
        url = window.createObjectURL(file);
      } else if (window.webkitURL != undefined) {
        // 兼容谷歌
        try {
          url = window.webkitURL.createObjectURL(file);
        } catch (error) { }
      } else if (window.URL != undefined) {
        // 兼容其他
        try {
          url = window.URL.createObjectURL(file);
        } catch (error) { }
      }
      //debugger
      return url;
    },
    getNumPages(src) {
      let loadingTask = pdf.createLoadingTask(src);
      loadingTask.promise.then(pdf => {
        this.pdfSrc = loadingTask,
          this.numPages = pdf.numPages
      }).catch(err => {
        console.log("Loading pdf error!" + err);
      });
    },
    onChange(date, dateString) {
      this.startTime = dateString[0];
      this.endTime = dateString[1];
      if (date.length === 0) {
        this.selectTime = [];
        this.queryParam.startTime = null
        this.queryParam.endTime = null
      } else {
        this.queryParam.startTime = this.startTime;
        this.queryParam.endTime = this.endTime;
        //console.log("这是开始时间", this.moment(this.selectTime[0]).format('YYYY-MM-DD HH:mm:ss'));
        //console.log("这是结束时间", this.moment(this.selectTime[1]).format('YYYY-MM-DD HH:mm:ss'));
      }
      //console.log(this.selectTime.length);
    },
    onArchiveChange(date, dateString) {
      this.startArchiveTime = dateString[0];
      this.endArchiveTime = dateString[1];
      if (date.length === 0) {
        this.selectArchiveTime = [];
        this.queryParam.startArchiveTime = null
        this.queryParam.endArchiveTime = null
      } else {
        this.queryParam.startArchiveTime = this.startArchiveTime;
        this.queryParam.endArchiveTime = this.endArchiveTime;
      }
    },

    onCompleteChange(date, dateString) {
      this.startCompleteTime = dateString[0];
      this.endCompleteTime = dateString[1];
      if (date.length === 0) {
        this.selectCompleteTime = [];
        this.queryParam.startCompleteTime = null
        this.queryParam.endCompleteTime = null
      } else {
        this.queryParam.startCompleteTime = this.startCompleteTime;
        this.queryParam.endCompleteTime = this.endCompleteTime;
      }
    },

    onCalibrationChange(date, dateString) {
      this.startCalibrationTime = dateString[0];
      this.endCalibrationTime = dateString[1];
      if (date.length === 0) {
        this.selectCalibrationTime = [];
        this.queryParam.startCalibrationTime = null
        this.queryParam.endCalibrationTime = null
      } else {
        this.queryParam.startCalibrationTime = this.startCalibrationTime;
        this.queryParam.endCalibrationTime = this.endCalibrationTime;
      }
    },

    resetSearchControl() {
      this.queryParam = {}
      this.selectTime = []
      this.queryParam.startTime = null
      this.queryParam.endTime = null
      this.selectArchiveTime = []
      this.queryParam.startArchiveTime = null
      this.queryParam.endArchiveTime = null
      this.selectCompleteTime = []
      this.queryParam.startCompleteTime = null
      this.queryParam.endCompleteTime = null

      this.selectCalibrationTime = []
      this.queryParam.startCalibrationTime = null
      this.queryParam.endCalibrationTime = null
    },
    resetSearchForm() {
      this.queryParam = {
        date: moment(new Date())
      }
    }
  }
}
</script>
<style less>
.full-modal {
  .ant-modal {
    max-width: 100%;
    max-height: 100%;
    top: 0;
    padding-bottom: 0;
    margin: 0;
  }

  .ant-modal-content {
    display: flex;
    flex-direction: column;
    height: calc(100vh);
  }

  .ant-modal-body {
    flex: 1;
  }
}

.table-striped_click td {
  color: red;
}
</style>