<template>
    <page-header-wrapper :title="false">
        <a-card :bordered="false">
            <div class="table-page-search-wrapper">
                <a-form layout="inline">
                    <a-row :gutter="48" style="height: 30px;">
                        <a-col :md="8" :sm="24">
                        </a-col>
                        <a-col :md="16" :sm="24">
                            <span style="float:right;">
                                <a-button size="small" type="primary" shape="round" @click="ExportData()">Export
                                    Data</a-button>
                            </span>
                        </a-col>
                    </a-row>
                </a-form>
            </div>
            <s-table ref="table" size="small" rowKey="id" :columns="columns" :data="loadData" :alert="false"
                :loading="loading" showPagination="auto" :scroll="{ x: 2300 }">
                <span slot="serial" slot-scope="text, record, index">
                    {{ index + 1 }}
                </span>
                <!--<template #footer>Footer</template> -->
            </s-table>
        </a-card>
    </page-header-wrapper>
</div></template>
    
<script>
import moment from 'moment'
import { STable, Ellipsis } from '@/components'
import { GetAuditInfoList, ExportAuditInfoToExcel, DownloadFile } from '@/api/arms'

const columns = [
    {
        title: 'Date',
        width: 120,
        dataIndex: 'date'
    },
    {
        title: 'Level',
        width: 60,
        dataIndex: 'level'
    },
    {
        title: 'Source',
        width: 60,
        dataIndex: 'source'
    },
    {
        title: 'Event ID',
        width: 70,
        dataIndex: 'eventId'
    },
    {
        title: 'Event ID Name',
        width: 130,
        dataIndex: 'eventIdName'
    },
    {
        title: 'Created Date',
        width: 120,
        dataIndex: 'createdDate'
    },

    {
        title: 'Created By',
        width: 100,
        dataIndex: 'createdBy'
    },
    {
        title: 'Created By Full Name',
        width: 130,
        dataIndex: 'createdByFullName'
    },
    {
        title: 'Computer',
        width: 80,
        dataIndex: 'computer'
    },
    {
        title: 'Change ID',
        width: 80,
        dataIndex: 'changeId'
    },
    {
        title: 'Process ID',
        width: 80,
        dataIndex: 'processId'
    },
    {
        title: 'Message',
        width: 250,
        dataIndex: 'message',
        ellipsis: true
    },
    {
        title: 'Data',
        width: 450,
        dataIndex: 'data',
        ellipsis: true
    },
]

export default {
    name: 'TableList',
    components: {
        STable,
        Ellipsis
    },
    data() {
        this.columns = columns
        return {
            // create model
            visible: false,
            loading: false,
            confirmLoading: false,
            mdl: null,
            // 高级搜索 展开/关闭
            advanced: false,
            // 查询参数
            queryParam: {},
            attributeControlInfo: [],
            // 加载数据方法 必须为 Promise 对象
            loadData: parameter => {
                let mainId = this.$route.query.mainId;
                //console.log(mainId);
                const requestParameters = Object.assign({}, parameter, { mainId: mainId })
                //console.log('loadData request parameters:', requestParameters)
                return GetAuditInfoList(requestParameters)
                    .then(res => {
                        if (res.status == '500') {
                            this.$message.error(res.message)
                            return;
                        }
                        return res.result
                    })
            },
            selectedRowKeys: [],
            selectedRows: []
        }
    },
    mounted() {
        //this.fetch();
    },
    filters: {
        statusFilter(type) {
            return statusMap[type].text
        },
        statusTypeFilter(type) {
            return statusMap[type].status
        }
    },
    computed: {
        rowSelection() {
            return {
                selectedRowKeys: this.selectedRowKeys,
                //selectedRows: this.selectedRows,
                onChange: this.onSelectChange
            }
        }
    },
    created() {
    },
    methods: {
        moment,
        onSelectChange(selectedRowKeys, selectedRows) {
            this.selectedRowKeys = selectedRowKeys
            this.selectedRows = selectedRows
        },
        ExportData() {
            let mainId = this.$route.query.mainId;
            const requestParameters = { "mainId": mainId }
            //接口函数传入id,返回的文件流
            ExportAuditInfoToExcel(requestParameters).then(res => {
                let fileName = moment().utcOffset(8).format('YYYY-MM-DD HH:mm:ss') + "_Audit.xls";
                DownloadFile(res, fileName);
            }
            )
        },
    }
}
</script>