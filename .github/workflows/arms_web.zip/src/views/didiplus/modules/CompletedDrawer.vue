<template>
  <div class="setting-drawer">
    <a-drawer>
    </a-drawer>
  </div>
</template>

<script>

import config from '@/config/defaultSettings'

export default {
  components: {
  },
  mixins: [],
  data () {
    return {
      visible: false
    }
  },
  watch: {

  },
  mounted () {
  },
  methods: {
    onClose () {
      this.visible = false
    },
    toggle () {
      this.visible = !this.visible
    }
  }
}
</script>
