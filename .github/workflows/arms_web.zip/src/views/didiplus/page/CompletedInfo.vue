import { i18nRender } from '@/locales'

<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline">
        <a-row :gutter="48">
          <a-col :md="8" :sm="24">
            <a-form-item label="Legal Entity">
              <a-select v-model="queryParam.companyCode" @change="handleChange">
                <a-select-option v-for="d in companyData" :value="d.code" :key="d.code">{{ d.name }}</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :md="16" :sm="24">
            <span style="float:right;">
              <a-button type="primary" v-show="false">DownLoad</a-button>
              <a-divider type="vertical" v-show="false" />
              <a-button type="primary" @click="ChangeBillRecord">Change</a-button>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>
    <s-table ref="table" size="default" rowKey="id" :columns="columns" :data="loadData" :alert="false"
      :rowSelection="rowSelection" showPagination="auto" :customRow="customRow">
      <span slot="serial" slot-scope="text, record, index">
        {{ index + 1 }}
      </span>
      <span slot="status" slot-scope="text">
        <a-badge :status="text | statusTypeFilter" :text="text | statusFilter" />
      </span>
      <span slot="ShowPostingFile" slot-scope="text, record">
        <template>
          <a @click="handleShowPostingFile(record)">{{ text }}</a>
        </template>
      </span>
      <span slot="action" slot-scope="text, record">
        <template>
          <a @click="handleDetail(record)">Detail</a>
        </template>
      </span>
    </s-table>

    <completed-form ref="createModal" :visible="visible" :loading="confirmLoading" :model="mdl" @cancel="handleCancel"
      @ok="handleCancel" />
    <step-by-step-modal ref="modal" @ok="handleOk" />

    <a-drawer title="Posting Information" width="30%" :visible="this.isDrawerShow" :showCloseflag="true"
      @close="onClose" :maskClosable="true">
      <table width="98%">
        <tr>
          <td width="120px" style="font-weight: bold; height: 30px;">
            Company Code:
          </td>
          <td width="200px">
            {{ this.rowRecord.companyCode }}
          </td>
        </tr>
        <tr>
          <td width="120px" style="font-weight: bold;height: 30px;">
            Posting Id:
          </td>
          <td width="200px">
            {{ this.rowRecord.id }}
          </td>
        </tr>
        <tr>
          <td width="120px" style="font-weight: bold;height: 30px;">
            Posting Time:
          </td>
          <td width="200px">
            {{ this.rowRecord.createdDate }}
          </td>
        </tr>
        <tr>
          <td width="120px" style="font-weight: bold;height: 30px;">
            File Name:
          </td>
          <td width="200px">
            {{ (this.rowRecord.postingFile) }}
          </td>
        </tr>
      </table>
    </a-drawer>
  </a-card>
</template>

<script>
import { STable, Ellipsis } from '@/components'
import { GetDidiPlusCompletedList, GetAllCompanyData, ChangeToProcess, GetDidiPostingFile, DownFileCompletedDetatils, DownloadFileXLS } from '@/api/didiplus'

import StepByStepModal from '../modules/StepByStepModal'
import CompletedForm from '../modules/CompletedForm'
import { Modal } from 'ant-design-vue'

const columns = [
  {
    title: 'File Name',
    width: 150,
    dataIndex: 'batchNo',
    scopedSlots: { customRender: 'ShowPostingFile' }
  },
  {
    title: 'Account No',
    width: 120,
    dataIndex: 'accountNo'
  },
  {
    title: 'Company Code',
    width: 120,
    dataIndex: 'companyCode'
  },
  {
    title: 'Status',
    width: 120,
    dataIndex: 'status'
  },
  {
    title: 'Posting Date',
    width: 150,
    dataIndex: 'updateDate'
  },
  {
    title: 'Export File',
    width: 120,
    scopedSlots: { customRender: 'action' }
  }
]

export default {
  name: 'TableList',
  components: {
    STable,
    Ellipsis,
    CompletedForm,
    StepByStepModal
  },
  inject: ['reload'],
  data() {
    this.columns = columns
    return {
      // create model
      visible: false,
      confirmLoading: false,
      mdl: null,
      // 高级搜索 展开/关闭
      advanced: false,
      // 查询参数
      queryParam: { companyCode: '0813' },
      // 加载数据方法 必须为 Promise 对象
      loadData: parameter => {
        const requestParameters = Object.assign({}, parameter, this.queryParam)
        //console.log('loadData request parameters:', requestParameters)
        return GetDidiPlusCompletedList(requestParameters)
          .then(res => {
            //console.log(res)
            if (res.status == '500') {
              this.$message.error(res.message)
              //this.$refs.table.refresh()
              return;
            }
            return res.result
          })
      },
      selectedRowKeys: [],
      selectedRows: [],
      companyData: [],
      isDrawerShow: false,
      rowRecord: { 'id': '', 'companyCode': '', 'createdDate': '', 'fileName': '', 'postingFileId': '', 'postingFile': '', 'statementDate': '' }
    }
  },
  filters: {
    statusFilter(type) {
      return statusMap[type].text
    },
    statusTypeFilter(type) {
      return statusMap[type].status
    }
  },
  computed: {
    rowSelection() {
      return {
        selectedRowKeys: this.selectedRowKeys,
        onChange: this.onSelectChange
      }
    }
  },
  created() {
    this.loadCompanyData()
  },
  methods: {
    customRow(record, index) {
      return {
        on: {
          dblclick: (e) => {
            var params = { 'postId': record.postingFileId }
            return GetDidiPostingFile(params).then((data) => {
              if (data.result == undefined || data.result == null) {
                this.$message.error('Get posting information error...')
                return;
              }
              this.isDrawerShow = true
              this.rowRecord = null;
              this.rowRecord = data.result;
              //console.log(this.rowRecord)
            }
            )
          }
        }
      }
    },
    loadCompanyData() {
      return GetAllCompanyData()
        .then(res => {
          if (res != null) {
            res.forEach((r) => {
              this.companyData.push({ code: r.code, name: r.name });
            });
          }
        })
    },
    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
    },
    rowClick(record, index) {
    },
    handleShowPostingFile(record) {
      var params = { 'postId': record.postingFileId }
      return GetDidiPostingFile(params).then((data) => {
        if (data.result == undefined || data.result == null) {
          this.$message.error('Get posting information error...')
          return;
        }
        this.isDrawerShow = true
        this.rowRecord = null;
        this.rowRecord = data.result;
        //console.log(this.rowRecord)
      }
      )
    },
    handleDetail(record) {
      var params = { 'postId': record.postingFileId }
      return GetDidiPostingFile(params).then((data) => {
        if (data.result == undefined || data.result == null) {
          this.$message.error('Get posting-details file error...')
          return;
        }
        var postingFile = data.result.postingFile;
        //console.log(postingFile)
        var params = { 'postingFile': postingFile }
        DownFileCompletedDetatils(params).then(res => {
          DownloadFileXLS(res, postingFile);
          return;
        })
      }).catch(ex => {
        this.$message.error('Get posting-details file error...\n' + ex)
        return
      })
    },
    handleInvoice(record) {
      this.visible = true
      this.mdl = { ...record }
    },
    handleChange(e) {
      this.$refs.table.refresh();
    },
    handleOk() {
      const form = this.$refs.createModal.form
      this.confirmLoading = true
      form.validateFields((errors, values) => {
        if (!errors) {
          //console.log('values', values)
        } else {
          this.confirmLoading = false
        }
      })
    },
    handleCancel() {
      this.visible = false
      const form = this.$refs.createModal.form
      form.resetFields() // 清理表单数据（可不做）
    },
    onClose() {
      this.isDrawerShow = false
    },
    ChangeBillRecord() {
      if (this.selectedRowKeys.length == 0) {
        this.$message.error("Please select the record which you want to change!")
        return;
      }
      var selectKey = ""
      this.selectedRowKeys.forEach(item => {
        selectKey += item + ","
      })
      selectKey = selectKey.slice(0, selectKey.length - 1)
      Modal.confirm({
        title: 'Prompt Confirm',
        content: 'Are you sure change this record?',
        onOk: () => {
          try {
            var rowKeys = { 'RowKeys': selectKey }
            ChangeToProcess(rowKeys).then(() => {
              this.$message.info("Change success...");
              this.$refs.table.refresh();
              setTimeout(() => {
                this.reload()
              }, 2000);
            })
          }
          catch (e) {
            this.$message.error("Operation error...\n" + e)
          }
        },
        onCancel() { }
      })
    }
  }
}
</script>