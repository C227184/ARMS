<template>
  <a-card :bordered="false">
    <div class="table-page-search-wrapper">
      <a-form layout="inline">
        <a-row :gutter="48">
          <a-col :md="8" :sm="24">
            <a-form-item label="Legal Entity">
              <a-select v-model="queryParam.companyCode" @change="handleChange">
                <a-select-option v-for="d in companyData" :value="d.code" :key="d.code">{{ d.name }}</a-select-option>
              </a-select>
            </a-form-item>
          </a-col>
          <a-col :md="16" :sm="24">
            <span style="float:right;">
              <a-button type="primary" @click="PostBillRecord">Posting</a-button>
            </span>
          </a-col>
        </a-row>
      </a-form>
    </div>
    <s-table ref="table" size="default" rowKey="id" :columns="columns" :data="loadData" :alert="false"
      :loading="loading" :rowSelection="rowSelection" showPagination="auto">
      <span slot="serial" slot-scope="text, record, index">
        {{ index + 1 }}
      </span>
      <span slot="status" slot-scope="text">
        <a-badge :status="text | statusTypeFilter" :text="text | statusFilter" />
      </span>
      <span slot="action" slot-scope="text, record">
        <template>
          <a @click="handleDown(record)">Detail</a>
          <a-divider type="vertical" />
          <a @click="handleInvoice(record)">Invoice</a>
        </template>
      </span>
    </s-table>

    <invoice-form ref="createModal" :visible="visible" :loading="confirmLoading" :model="mdl" @cancel="handleCancel"
      @ok="handleOk" />
    <step-by-step-modal ref="modal" @ok="handleOk" />
  </a-card>
</template>

<script>
import { STable, Ellipsis } from '@/components'
import { GetDidiPlusProcessList, GetAllCompanyData, UpdateInvoice, DidiPlusDoPosting, GetDidiPostingFile, DownloadFileXLS, ActionDidiCheckFile, DownFileForDidiPlusXLS } from '@/api/didiplus'

import StepByStepModal from '../modules/StepByStepModal'
import InvoiceForm from '../modules/InvoiceForm'
import moment from 'moment'


const columns = [
  {
    title: 'File Name',
    width: 130,
    dataIndex: 'batchNo'
  },
  {
    title: 'Company Code',
    width: 80,
    dataIndex: 'companyCode'
  },
  {
    title: 'Total Price',
    width: 80,
    dataIndex: 'totalPrice'
  },
  {
    title: 'Rebate Amount',
    width: 80,
    dataIndex: 'rebateAmount'
  },
  {
    title: 'Refund Amount',
    width: 80,
    dataIndex: 'refundAmount'
  },
  {
    title: 'Invocice Price',
    width: 80,
    dataIndex: 'invocicePrice'
  },
  {
    title: 'Status',
    width: 90,
    dataIndex: 'status',
    needTotal: true
  },
  {
    title: 'Time',
    width: 130,
    dataIndex: 'statementDate'
  },
  {
    title: 'Export File',
    width: 120,
    scopedSlots: { customRender: 'action' }
  }
]

export default {
  name: 'TableList',
  components: {
    STable,
    Ellipsis,
    InvoiceForm,
    StepByStepModal
  },
  data() {
    this.columns = columns
    return {
      // create model
      visible: false,
      loading: false,
      confirmLoading: false,
      mdl: null,
      // 高级搜索 展开/关闭
      advanced: false,
      // 查询参数
      queryParam: { companyCode: '0813' },
      // 加载数据方法 必须为 Promise 对象
      loadData: parameter => {
        const requestParameters = Object.assign({}, parameter, this.queryParam)
        //console.log('loadData request parameters:', requestParameters)
        return GetDidiPlusProcessList(requestParameters)
          .then(res => {
            //console.log(res);
            if (res.status == '500') {
              this.$message.error(res.message)
              //this.$refs.table.refresh()
              return;
            }
            return res.result
          })
      },
      selectedRowKeys: [],
      selectedRows: [],
      companyData: []
    }
  },
  mounted() {
    //this.fetch();
  },
  filters: {
    statusFilter(type) {
      return statusMap[type].text
    },
    statusTypeFilter(type) {
      return statusMap[type].status
    }
  },
  computed: {
    rowSelection() {
      return {
        selectedRowKeys: this.selectedRowKeys,
        //selectedRows: this.selectedRows,
        onChange: this.onSelectChange
      }
    }
  },
  created() {
    this.loadCompanyData()
  },
  methods: {
    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
    },
    loadCompanyData() {
      return GetAllCompanyData()
        .then(res => {
          if (res != null) {
            res.forEach((r) => {
              this.companyData.push({ code: r.code, name: r.name });
            });
          }
        }).catch(ex => {
          this.selectedRowKeys = []
          this.selectedRows = []
          this.$message.error("Posting error,please try again later.....\n" + ex)
          return;
        })
    },
    fetch(parameter = {}) {
      this.loading = true;
      this.queryParam
      const requestParameters = { pageNo: 1, pageSize: 10, companyCode: '0813' }
      //console.log('loadData request parameters:', requestParameters)
      return GetDidiPlusProcessList(requestParameters)
        .then(res => {
          //console.log(res);
          if (res.status == '500') {
            this.$message.error(res.message)
            //this.$refs.table.refresh()
            return;
          }
          return res.result
        })
    },
    handleDown(record) {
      try {
        if (record.statementFile == null || record.statementFile == undefined) {
          this.$message.error('File is not exist...')
          return
        }
        let data = { 'Id': record.id }
        return DownFileForDidiPlusXLS(data).then((res) => {
          if (!res || res.size === 0) {
            this.$message.error('DownLoad file error...')
            return
          }
          let fileName = record.statementFile.substring(record.statementFile.lastIndexOf("/") + 1)
          DownloadFileXLS(res, fileName);
          return;
        })
      } catch (ex) {
        this.$message.error(ex)
        return;
      }
    },
    handleInvoice(record) {
      //console.log(record)
      this.visible = true
      this.mdl = { ...record }
    },
    handleChange(e) {
      this.$refs.table.refresh();
    },
    handleOk() {
      const form = this.$refs.createModal.form
      this.confirmLoading = true
      form.validateFields((errors, values) => {
        if (!errors) {
          //console.log('values', values)
          if (values.id > 0) {
            // 修改 e.g.
            values.baseLineDate = moment(values.baseLineDate).format('YYYY-MM-DD HH:MM:ss')
            values.invoiceDate = moment(values.invoiceDate).format('YYYY-MM-DD HH:MM:ss')
            return UpdateInvoice(values).then(res => {
              setTimeout(() => {
                this.visible = false
                this.confirmLoading = false
                // 重置表单数据
                form.resetFields()
                // 刷新表格
                this.$refs.table.refresh();

                this.$message.info('Operation successful...')
              }, 1000)
            }).catch(ex => {
              this.$message.error("Operation error...\n" + ex)
              return;
            })
          }
        } else {
          this.confirmLoading = false
        }
      })
    },
    handleCancel() {
      this.visible = false
      const form = this.$refs.createModal.form
      form.resetFields() // 清理表单数据（可不做）
    },
    PostBillRecord() {

      if (this.selectedRowKeys.length == 0) {
        this.$message.error("Please select the record which you want to posting!")
        return;
      }
      if (this.selectedRowKeys.length > 1) {
        this.$message.error("Only one record which you can select!")
        return;
      }

      const id = this.selectedRows[0].id;
      const companyCode = this.selectedRows[0].companyCode;
      const selectRecord = { 'Id': id, 'companyCode': companyCode }

      return DidiPlusDoPosting(selectRecord).then((result) => {
        if (result.status != "200") {
          this.selectedRowKeys = []
          this.selectedRows = []
          this.$message.error('Posting error,please try again later.....')
          return;
        }
        this.$message.info('Posting success.....')
        // 重置表单数据
        this.$refs.table.refresh()
        return;
      }).catch(ex => {
        this.selectedRowKeys = []
        this.selectedRows = []
        this.$message.error("Posting error,please try again later.....\n" + ex)
        return;
      })
    }
  }
}
</script>
