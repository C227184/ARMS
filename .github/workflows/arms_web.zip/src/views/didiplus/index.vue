<template>
  <div>
    <a-row justify="start">
      <a-tabs :activeKey="activeKey" @change="changeTage">
        <a-tab-pane key="1" tab="In Process">
          <ProcessInfo></ProcessInfo>
        </a-tab-pane>
        <a-tab-pane key="2" tab="Completed" force-render>
          <CompletedInfo></CompletedInfo>
        </a-tab-pane>
      </a-tabs>
    </a-row>
  </div>
</template>

<script>
import { ref } from 'vue'

import ProcessInfo from './page/ProcessInfo'
import CompletedInfo from './page/CompletedInfo'

export default {
   name: 'Index',
   components: {
    ProcessInfo,
    CompletedInfo
   },
   data () {
      return {
         activeKey: ref('1'),
         selectLegalEntity: ''
      }
   },
   methods: {
    changeTage (activeKey) {
      //console.log(activeKey)
      this.activeKey = ref(activeKey)
    }
   }

}
</script>
<style scoped>
.row_title{
   background-color: rgb(153, 153, 153);
}
 .title{
   text-align: center;
   /* background-color: rgb(153, 153, 153); */
   font-size: 17px;
   border-right: 2px solid;
 }
 
</style>