<template>
    <a-modal title="Attribute Modify" :width="600" :visible="visible" :confirmLoading="confirmLoading" @ok="handleSubmit"
        @cancel="handleCancel">
        <a-spin :spinning="confirmLoading">
            <a-form :form="form">
                <a-form-item :labelCol="labelCol" v-show="false" :wrapperCol="wrapperCol">
                    <a-input v-decorator="['id']" />
                </a-form-item>
                <a-form-item :labelCol="labelCol" v-show="false" :wrapperCol="wrapperCol">
                    <a-input v-decorator="['attributeId']" />
                </a-form-item>
                <a-form-item label="AttributeName" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-input v-decorator="['attributeName']" disabled />
                </a-form-item>
                <a-form-item label="IsActive" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-switch v-decorator="['isActive',{ valuePropName: 'checked' }]" @change="onChange"></a-switch>
                </a-form-item>
                <a-form-item label="Sort" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-input-number v-decorator="['sort']" :min="1"></a-input-number>
                </a-form-item>

                <a-form-item label="Reason" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-textarea v-decorator="['changeReason', { rules: [{ required: true, message: 'Please input reason！' }] }]" style="height:100px" />        
                </a-form-item>

            </a-form>
        </a-spin>
    </a-modal>
</template>
<script>
import pick from 'lodash.pick'
import moment from 'moment'
import { EditAttributeControlInfo } from '@/api/arms'

export default {
    data() {
        return {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 5 }
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 18 }
            },
            visible: false,
            confirmLoading: false,
            visibleDef: false,
            form: this.$form.createForm(this)
        }
    },
    methods: {
        // 初始化方法
        edit(record) {
            this.visible = true
            setTimeout(() => {
                this.form.setFieldsValue(
                    {
                        id: record.id,
                        attributeId: record.attributeId,
                        attributeName: record.attributeName,
                        sort: record.sort,
                        isActive: record.isActive,
                        changeReason:''
                    }
                )
            }, 100)
        },
        handleSubmit() {
            const { form: { validateFields } } = this
            this.confirmLoading = true
            validateFields((errors, values) => {
                if (!errors) {
                    EditAttributeControlInfo(values).then((res) => {
                        if (res.status=="200") {
                            this.$message.success('Success')
                            this.visible = false
                            this.confirmLoading = false
                            this.$emit('ok', values)
                        } else {
                            this.$message.error('Failed：' + res.message)
                        }
                    }).finally((res) => {
                        this.confirmLoading = false
                    })
                } else {
                    this.confirmLoading = false
                }
            })
        },
        handleCancel() {
            this.form.resetFields()
            this.visible = false
        },
        onChange(checked) {
            this.checked = checked;
        }
    }
}
</script>  