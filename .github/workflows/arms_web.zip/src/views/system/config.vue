<template>
    <page-header-wrapper :title="false">
        <a-card :bordered="false">
            <div class="table-page-search-wrapper">
                <a-form layout="inline">
                    <a-row :gutter="24">
                        <a-col :md="12" :sm="24">
                            <a-form-item label="Source A">
                                <a-input id="pathId" v-model="pathId" v-show="false" />
                                <a-input id="sourceAPath" v-model="sourceAPath" disabled />
                            </a-form-item>
                        </a-col>
                    </a-row>
                    <a-row :gutter="24">
                        <a-col :md="12" :sm="24">
                            <a-form-item label="Source B">
                                <a-input id="sourceBPath" v-model="sourceBPath" disabled />
                            </a-form-item>
                        </a-col>
                        <a-col :md="!advanced && 8 || 24" :sm="24">
                            <span class="table-page-search-submitButtons"
                                :style="advanced && { float: 'right', overflow: 'hidden' } || {}">
                                <a-button type="primary" shape="round"
                                    @click="editFilePath({ 'id': pathId, 'sourceAPath': sourceAPath, 'sourceBPath': sourceBPath, 'targetPath': targetPath })">Modify</a-button>
                            </span>
                        </a-col>
                    </a-row>
                    <a-row :gutter="24" v-show="false">
                        <a-col :md="12" :sm="24">
                            <a-form-item label="Target Path">
                                <a-input id="targetPath" v-model="targetPath" disabled />
                            </a-form-item>
                        </a-col>
                    </a-row>

                </a-form>
            </div>

            <div class="table-operator">
                <a-button type="primary" shape="round" icon="plus" @click="$refs.createModal.add()">Add New
                    Configation</a-button>
            </div>
            <s-table ref="table" size="small" rowKey="attributeId" :columns="columns" :data="loadData" :alert="false"
                :loading="loading" showPagination="auto">

                <span slot="serial" slot-scope="text, record, index">
                    {{ index + 1 }}
                </span>

                <span slot="IsActive" slot-scope="text"> {{ text === true ? 'Yes' : 'No' }} </span>
                <span slot="action" slot-scope="text, record">
                    <a-button type="primary" size="small" shape="round" style="margin-right: 5px"
                        @click="handleEdit(record)">
                        <a-icon type="edit" />Modify</a-button>
                    <a-button type="danger" size="small" shape="round" style="margin-left: 5px" @click="() => del(record)">
                        <a-icon type="delete" />Delete</a-button>
                </span>
            </s-table>
            <add-form ref="createModal" @ok="handleOk" />
            <edit-form ref="editForm" @ok="handleOk"></edit-form>
            <edit-path-form ref="editPathForm" @ok="handleOk"></edit-path-form>
        </a-card>
    </page-header-wrapper>
</div></template>
    
<script>
import moment from 'moment'
import { STable, Ellipsis } from '@/components'
import { GetAttributeControlInfo, GetTableStructureInfo, GetTaskSyncFilePathInfo, DeleteAttributeControlInfo } from '@/api/arms'
import addForm from './addForm'
import editForm from './editForm'
import editPathForm from './editPathForm'

const columns = [
    {
        title: 'Attribute ID',
        width: 80,
        dataIndex: 'attributeId'
    },
    {
        title: 'Attribute Name',
        width: 180,
        dataIndex: 'attributeName'
    },
    {
        title: 'Table Name',
        width: 120,
        dataIndex: 'tableName'
    },
    {
        title: 'IsActive',
        width: 80,
        dataIndex: 'isActive',
        scopedSlots: { customRender: 'IsActive' }
    },
    {
        title: 'Sort',
        width: 80,
        dataIndex: 'sort'
    },
    {
        title: 'Operation',
        dataIndex: 'action',
        width: 180,
        scopedSlots: { customRender: 'action' }
    }
]

export default {
    name: 'TableList',
    components: {
        STable,
        Ellipsis,
        addForm,
        editForm,
        editPathForm
    },
    inject: ['reload'],
    data() {
        this.columns = columns
        return {
            // create model
            visible: false,
            loading: false,
            confirmLoading: false,
            mdl: null,
            // 高级搜索 展开/关闭
            advanced: false,
            // 查询参数
            queryParam: {},
            tableStructureInfo: [],
            // 加载数据方法 必须为 Promise 对象
            loadData: parameter => {
                //console.log(parameter)
                const requestParameters = Object.assign({}, parameter, this.queryParam)
                return GetAttributeControlInfo(requestParameters)
                    .then(res => {
                        if (res.status == '500') {
                            this.$message.error(res.message)
                            return;
                        }
                        return res.result
                    })
            },
            selectedRowKeys: [],
            selectedRows: [],
            pathId: 0,
            sourceAPath: '',
            sourceBPath: '',
            targetPath: ''
        }
    },
    mounted() {
        //this.fetch();
    },
    filters: {
        statusFilter(type) {
            return statusMap[type].text
        },
        statusTypeFilter(type) {
            return statusMap[type].status
        }
    },
    computed: {
        rowSelection() {
            return {
                selectedRowKeys: this.selectedRowKeys,
                //selectedRows: this.selectedRows,
                onChange: this.onSelectChange
            }
        }
    },
    created() {
        this.loadTableStructureInfo();
        this.loadTaskSyncFilePathInfo();
    },
    methods: {
        moment,
        onSelectChange(selectedRowKeys, selectedRows) {
            this.selectedRowKeys = selectedRowKeys
            this.selectedRows = selectedRows
        },
        handleOk() {
            this.$refs.table.refresh()
        },
        handleCancel() {
            this.visible = false
            const form = this.$refs.createModal.form
            form.resetFields() // 清理表单数据（可不做）
        },
        handleEdit(record) {
            this.$refs.editForm.edit(record)
        },

        del(record) {
            this.$confirm({
                title: 'Alert',
                content: `Do you really want to delete the data with attribute of ${record.attributeName}?`,
                okText: 'Delete',
                okType: 'danger',
                cancelText: 'Cancel',
                onOk() {
                    let params = { id: record.id }
                    DeleteAttributeControlInfo(params).then(
                        location.reload()
                        //this.reload()
                    )
                },
                onCancel() {
                    console.log('Cancel')
                }
            })
        },
        onChange(checked) {
            this.checked = checked;
        },
        editFilePath(record) {
            //alert(record)
            this.$refs.editPathForm.edit(record)
            //this.reload()
        },
        loadTableStructureInfo() {
            let params = { tableName: 'arms_maininfo' }
            return GetTableStructureInfo(params)
                .then(res => {
                    if (res != null) {
                        if (res.result == null) {
                            return;
                        }
                        res.result.forEach((r) => {
                            this.tableStructureInfo.push({ id: r.columnId, name: r.columnName });
                        });
                    }
                }).catch(ex => {
                    return;
                })
        },
        loadTaskSyncFilePathInfo() {
            let params = null;
            return GetTaskSyncFilePathInfo(params)
                .then(res => {
                    if (res != null) {
                        if (res.result == null) {
                            return;
                        }
                        this.pathId = res.result.id;
                        this.sourceAPath = res.result.sourceAPath;
                        this.sourceBPath = res.result.sourceBPath;
                        this.targetPath = res.result.targetPath;
                    }
                }).catch(ex => {
                    return;
                })
        }
    }
}
</script>
<style scoped>
.table-operator {
    margin-bottom: 18px;
}

button {
    margin-right: 8px;
}
</style>