<template>
    <a-modal title="File Path Modify" :width="600" :visible="visible" :confirmLoading="confirmLoading" @ok="handleSubmit"
        @cancel="handleCancel">
        <a-spin :spinning="confirmLoading">
            <a-form :form="form">
                <a-form-item :labelCol="labelCol" v-show="false" :wrapperCol="wrapperCol">
                    <a-input v-decorator="['id']" />
                </a-form-item>
                <a-form-item label="Source A" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-input v-decorator="['sourceAPath', { rules: [{ required: true, message: 'Please input Source A！' }] }]" />
                </a-form-item>
                <a-form-item label="Source B" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-input v-decorator="['sourceBPath', { rules: [{ required: true, message: 'Please input Source B！' }] }]" />
                </a-form-item>
                <a-form-item label="Change Reason" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-textarea v-decorator="['changeReason', { rules: [{ required: true, message: 'Please input Change Reason！' }] }]" style="height:100px" />        
                </a-form-item>
            </a-form>
        </a-spin>
    </a-modal>
</template>
<script>
import pick from 'lodash.pick'
import moment from 'moment'
import { SaveTaskSyncFilePath } from '@/api/arms'

export default {
    inject: ['reload'],
    data() {
        return {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 5 }
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 18 }
            },
            visible: false,
            confirmLoading: false,
            visibleDef: false,
            form: this.$form.createForm(this)
        }
    },
    methods: {
        // 初始化方法
        edit(record) {
            this.visible = true
            setTimeout(() => {
                this.form.setFieldsValue(
                    {
                        id: record.id,
                        sourceAPath: record.sourceAPath,
                        sourceBPath: record.sourceBPath,
                        changeReason:''
                    }
                )
            }, 100)
        },
        handleSubmit() {
            const { form: { validateFields } } = this
            this.confirmLoading = true
            validateFields((errors, values) => {
                if (!errors) {
                    SaveTaskSyncFilePath(values).then((res) => {
                        if (res.status=="200") {
                            this.$message.success('Success')
                            this.visible = false
                            this.confirmLoading = false
                            this.$emit('ok', values)
                            this.reload();
                        } else {
                            this.$message.error('Failed：' + res.message)
                        }
                    }).finally((res) => {
                        this.confirmLoading = false
                    })
                } else {
                    this.confirmLoading = false
                }
            })
        },
        handleCancel() {
            this.form.resetFields()
            this.visible = false
        },
        onChange(checked) {
            this.checked = checked;
        }
    }
}
</script>  