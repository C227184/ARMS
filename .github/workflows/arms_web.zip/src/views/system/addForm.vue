<template>
    <a-modal title="Add New Configation" :width="600" :visible="visible" :confirmLoading="confirmLoading" @ok="handleSubmit"
        @cancel="handleCancel">
        <a-spin :spinning="confirmLoading">
            <a-form :form="form">
                <a-form-item label="AttributeId" v-show="false">
                    <a-input v-decorator="['attributeId']"></a-input>
                </a-form-item>
                <a-form-item label="TableId" v-show="false">
                    <a-input v-decorator="['tableId']"></a-input>
                </a-form-item>
                <a-form-item label="TableName" v-show="false">
                    <a-input v-decorator="['tableName']"></a-input>
                </a-form-item>
                <a-form-item label="AttributeName" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-select v-decorator="['attributeName', { rules: [{ required: true, message: 'Please select attributeName！' }] }]"
                        @change="handleChange">
                        <a-select-option :value="item.name" v-for="item in tableStructureInfo" :key="item.id">{{ item.name
                        }}</a-select-option>
                    </a-select>
                </a-form-item>
                <a-form-item label="IsActive" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-switch v-decorator="['isActive', { initialValue: true, valuePropName: 'checked' }]"
                        @change="onChange"></a-switch>
                </a-form-item>

                <a-form-item label="Sort" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-input-number v-decorator="['sort', { initialValue: 1 }]" :min="1"></a-input-number>
                </a-form-item>

                <a-form-item label="Reason" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-textarea v-decorator="['changeReason', { rules: [{ required: true, message: 'Please input reason！' }] }]" style="height:100px" />        
                </a-form-item>
            </a-form>
        </a-spin>
    </a-modal>
</template>
  
<script>
import pick from 'lodash.pick'
import moment from 'moment'
import { GetTableStructureInfo, SaveAttributeControlInfo } from '@/api/arms'

export default {
    data() {
        return {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 5 }
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 18 }
            },
            entity: {},
            checked: true,
            visible: false,
            confirmLoading: false,
            tableStructureInfo: [],
            form: this.$form.createForm(this)
        }
    },
    created() {
        this.loadTableStructureInfo()
    },
    methods: {
        // 初始化方法
        add() {
            this.visible = true
            //this.form.getFieldDecorator('active', { initialValue: 'N' })
        },

        loadTableStructureInfo() {
            let params = { tableName: 'arms_maininfo' }
            return GetTableStructureInfo(params)
                .then(res => {
                    if (res != null) {
                        if (res.result == null) {
                            return;
                        }
                        res.result.forEach((r) => {
                            this.tableStructureInfo.push({ id: r.columnId, name: r.columnName, tableId: r.objectId, tableName: r.tableName });
                        });
                    }
                }).catch(ex => {
                    return;
                })
        },

        handleSubmit() {
            const { form: { validateFields } } = this
            this.confirmLoading = true
            validateFields((errors, values) => {
                //console.log(values);
                if (!errors) {
                    SaveAttributeControlInfo(values).then((res) => {
                        //console.log(res);
                        this.confirmLoading = false
                        if (res.status=="200") {
                            this.$message.success('Success')
                            this.handleCancel()
                            this.$emit('ok', values)
                        } else {
                            this.$message.error(res.result)
                        }
                    }).finally((res) => {
                        this.confirmLoading = false
                    })
                } else {
                    this.confirmLoading = false
                }
            })
        },
        handleCancel() {
            this.form.resetFields()
            this.visible = false
        },
        onChange(checked) {
            this.checked = checked;
        },
        handleChange(obj) {
            console.log(obj);
            var item = this.tableStructureInfo.find((p) => {
                if (p.name == obj) {
                    return p
                }
            })
            this.form.setFieldsValue({ attributeId: item.id, tableId: item.tableId, tableName: item.tableName });
        }
    }
}
</script>
