<template>
    <a-modal title="Re-run Task" :width="650" :visible="visible" :confirmLoading="confirmLoading" @ok="handleSubmit"
        @cancel="handleCancel">
        <a-spin :spinning="confirmLoading">
            <a-form :form="form">
                <a-form-item label="Re-run Reason" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-textarea v-decorator="['rerunReason', { rules: [{ required: true, message: 'Please input reason！' }] }]"
                        style="height:100px" />
                </a-form-item>

                <a-form-item label="Re-run FileName" :labelCol="labelCol" :wrapperCol="wrapperCol">
                    <a-input v-decorator="['rerunTaskFile', { rules: [{ required: true, message: 'Please input fileName！' }] }]" />
                </a-form-item>
            </a-form>
        </a-spin>
    </a-modal>
</template>
  
<script>
import pick from 'lodash.pick'
import moment from 'moment'
import { manualRunTask } from '@/api/arms'

export default {
    data() {
        return {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 5 }
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 18 }
            },
            entity: {},
            checked: true,
            visible: false,
            confirmLoading: false,
            tableStructureInfo: [],
            form: this.$form.createForm(this)
        }
    },
    created() {
    },
    methods: {
        // 初始化方法
        add() {
            this.visible = true
            //this.form.getFieldDecorator('active', { initialValue: 'N' })
        },
        handleSubmit() {
            const { form: { validateFields } } = this
            this.confirmLoading = true
            validateFields((errors, values) => {
                //console.log(values);
                if (!errors) {
                    let fileName = values.rerunTaskFile;
                    if (!/\.(xml)$/.test(fileName)) {
                        //this.$message.error("请輸入后缀为.xml格式的文件!")
                        //this.confirmLoading = false
                        //return;
                        fileName = fileName + ".xml";
                        values.rerunTaskFile = fileName;
                    }

                    manualRunTask(values).then((res) => {
                        //console.log(res);
                        this.confirmLoading = false
                        if (res.status == "200") {
                            this.$message.success('Success')
                            this.handleCancel()
                            this.$emit('ok', values)
                        } else {
                            this.$message.error(res.result)
                        }
                    }).finally((res) => {
                        this.confirmLoading = false
                    })
                } else {
                    this.confirmLoading = false
                }
            })
        },
        handleCancel() {
            this.form.resetFields()
            this.visible = false
        }
    }
}
</script>