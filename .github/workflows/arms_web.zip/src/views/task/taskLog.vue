<template>
  <page-header-wrapper :title="false">
    <a-card :bordered="false">
      <div class="table-page-search-wrapper">
        <a-form layout="inline">
          <a-row :gutter="48" style="vertical-align: top;height: 30px;">
            <a-col :md="16" :sm="24" size="small">
              <a-form-item label="ExecuteTime">
                <a-range-picker @change="onChange" v-model="selectTime" :show-time="{
                  hideDisabledOptions: true,
                  defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                }" format="YYYY-MM-DD HH:mm:ss" />
                <a-input v-model="queryParam.startTime" placeholder="" v-show="false" />
                <a-input v-model="queryParam.endTime" placeholder="" v-show="false" />
              </a-form-item>
            </a-col>
            <a-col :md="!advanced && 8 || 24" :sm="24">
              <span class="table-page-search-submitButtons" :style="{ float: 'right'}">
                <a-button type="primary" shape="round" @click="$refs.table.refresh(true)">Search</a-button>
                <a-button style="margin-left: 8px" shape="round" @click="resetSearchControl()">Reset</a-button>
                <a-button style="margin-left: 8px" v-show="canRunTask" type="primary" shape="round" @click="$refs.createModal.add()">Re-run
                  Task</a-button>
              </span>
            </a-col>
          </a-row>
        </a-form>
      </div>
      <s-table ref="table" size="small" rowKey="id" :columns="columns" :data="loadData" :alert="false" :loading="loading"
        showPagination="auto" :row-class-name="setRowClassName">
        <span slot="serial" slot-scope="text, record, index">
          {{ index + 1 }}
        </span>
        <span slot="exeResult" slot-scope="text">
          {{ text === true ? 'Success' : 'Error' }}
        </span>
      </s-table>
      <rerun-task ref="createModal" @ok="handleOk"></rerun-task>
    </a-card>
  </page-header-wrapper>
</template>
   
<script>
import { STable, Ellipsis } from '@/components'
import { GetTaskSyncLogList } from '@/api/arms'
import rerunTask from './rerunTask'

import moment from 'moment'

const columns = [
  {
    title: 'Execute Time',
    width: 120,
    dataIndex: 'executeTime'
  },
  {
    title: 'File Name',
    width: 250,
    dataIndex: 'syncFileName'
  },
  {
    title: 'Execute Type',
    width: 90,
    dataIndex: 'executeType'
  },
  {
    title: 'Execute Result',
    width: 90,
    dataIndex: 'syncFlag',
    scopedSlots: { customRender: 'exeResult' }
  },
  {
    title: 'Message',
    width: 150,
    dataIndex: 'message'
  }
]

export default {
  name: 'TableList',
  components: {
    STable,
    Ellipsis,
    rerunTask
  },
  data() {
    this.columns = columns
    return {
      moment,
      // create model
      visible: false,
      loading: false,
      confirmLoading: false,
      mdl: null,
      // 高级搜索 展开/关闭
      advanced: false,
      // 查询参数
      queryParam: {},
      // 加载数据方法 必须为 Promise 对象
      loadData: parameter => {
        const requestParameters = Object.assign({}, parameter, this.queryParam)
        //console.log('loadData request parameters:', requestParameters)
        return GetTaskSyncLogList(requestParameters)
          .then(res => {
            //console.log(res);
            if (res.status == '500') {
              this.$message.error(res.message)
              //this.$refs.table.refresh()
              return;
            }
            return res.result
          })
      },
      selectedRowKeys: [],
      selectedRows: [],
      canRunTask: false,
      startTime: null,
      endTime: null,
      selectTime: []
    }
  },
  mounted() {
    //this.fetch();
  },
  filters: {
    statusFilter(type) {
      return statusMap[type].text
    },
    statusTypeFilter(type) {
      return statusMap[type].status
    }
  },
  computed: {
    rowSelection() {
      return {
        selectedRowKeys: this.selectedRowKeys,
        //selectedRows: this.selectedRows,
        onChange: this.onSelectChange
      }
    },
    runTaskInfo() {
      let roles = this.$store.getters.roles
      //onsole.log(roles)
      if (roles == "admin") {
        return true
      }
      return false
    }
  },
  created() {
    this.canRunTask = this.runTaskInfo
    this.initTime()
  },
  methods: {
    setRowClassName(record, index) {
      let rowSTyle = null
      if (record.syncFlag !== true || record.message.indexOf("SPV验证不通过") > 0) {
        return "table-striped_click"
      } else {
        return rowSTyle
      }
    },
    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
    },
    initTime() {
      this.selectTime = []
      this.selectTime = [moment().utcOffset(8).subtract(1, 'month').format('YYYY-MM-DD')]
      this.queryParam.startTime = this.selectTime[0]
    },
    handleOk() {
      this.$refs.table.refresh()
    },
    onChange(date, dateString) {
      this.startTime = dateString[0];
      this.endTime = dateString[1];
      if (date.length === 0) {
        this.selectTime = [];
        this.queryParam.startTime = null
        this.queryParam.endTime = null
      } else {
        this.queryParam.startTime = this.startTime;
        this.queryParam.endTime = this.endTime;
      }
    },
    resetSearchControl() {
      this.queryParam = {}
      this.selectTime = []
      this.queryParam.startTime = null
      this.queryParam.endTime = null
    }
  }
}
</script> 
<style scope>
.table-striped_click td {
  color: red;
}
</style>