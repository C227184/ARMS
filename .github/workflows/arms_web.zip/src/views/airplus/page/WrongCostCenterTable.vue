<template>
    <div>
      <a-table :columns="columns" 
               :data-source="list" 
               :pagination="false"
               :scroll="{y:500}"
               :bordered="true"
               size='small'>
      <p slot="tags" slot-scope="id,record">
        <input :id="record.id" />
        <a-button @click="openChange(record)" size='small'>List</a-button>
      </p>
    </a-table>
    <a-modal 
    v-model="showCostCenter" 
      title="New CostCenter" 
      ok-text="确认" 
      cancel-text="取消" 
      :width="500"
      @ok="saveCostCenter"
     
    > 
        <a-table
        :columns="costCenterColumns"
        size='small'
        :bordered="true"
        :data-source="costCenterList"
        :pagination="pagination"
        :scroll="{y:500}"
        :customRow="rowClick"
        @change="handleTableChange"
        :row-class-name="setRowClassName"
        >

        </a-table>
    </a-modal>
    </div>
  </template>
  
  <script>
  
  import{getCostCenter } from '@/api/airplus'
  
  const costCenterColumns=[
     {
        title: 'Cost Center',
        dataIndex: 'code',
        key: 'code'
      },
      {
        title: 'Description',
        dataIndex: 'name',
        key: 'name'
      },
  ]

   const columnsInfo=[
     
      {
        title: 'Ref No',
        dataIndex: 'internalAccount',
        key: 'internalAccount'
      },
      {
        title: 'Order No',
        dataIndex: 'department',
        key: 'department'
      },
      {
        title: 'Ticket No',
        dataIndex: 'ticketNumber',
        key: 'ticketNumber'
      },
      {
        title: 'Old Cost Center',
        dataIndex: 'postingCostCenter',
        key: 'postingCostCenter'
      },
      {
        title: 'New Cost Center',
        dataIndex: 'newCostCenter',
        key: 'newCostCenter',
        scopedSlots: { customRender: 'tags' }

      }
    ]
  export default {
    name: 'WrongCostCenterTable',
    props:{
        list:{
              type:Array
          },
          companyCode:{
            type:String
          }
      },
    data () {
      return {
        columns: columnsInfo,
        costCenterColumns:costCenterColumns,
        data: [],
        selectedRowKeys:[],
        selectedCostCenter:'',
        showCostCenter:false,
        costCenterList:[],
        pagination:{
              current: 1,
              total:'',
              pageSize: 10, // 默认每页显示数量
              showTotal: total => `总共 ${total} 条`, // 显示总数
            },
        selectCostCenter:''
        
      }
    },
    methods:{

    setRowClassName(record, index){
        if(record.code===this.selectCostCenter){
          return "table-striped_click"
        }else{
          return ""
        }
       },
        rowClick (record, index) {
          return {
           on: {
               click: () => {
                 this.selectCostCenter=record.code
                }
             }
           }
        },

        handleTableChange(pagination, filters, sorter){
          
          this.loading=true
          
        debugger
          let param={
            pageNo:this.pagination.current,
            pageSize:this.pagination.pageSize,
            leCode:this.companyCode,
         
          }

          if(typeof pagination!=='undefined'){
            param.pageNo=pagination.current
          }
          
          getCostCenter(param).then(res=>{
            console.log(res);
            this.loading=false
            let{list,pageSize,totalCount,totalPage,currPage}=res.data
            this.costCenterList=list
            this.pagination.total=totalCount
            this.pagination.totalPage=totalPage
            this.pagination.pageSize=pageSize
            this.pagination.currPage=currPage

          })
          
        },
     
        openChange(record){
            this.showCostCenter=true
            this.selectedCostCenter=record.code
            this.handleTableChange()

        },

        saveCostCenter(){
            this.showCostCenter=false
            for (let index = 0; index < this.list.length; index++) {
                const element = this.list[index];
                if(element.code===this.selectedCostCenter){
                    document.getElementById(element.id).value=this.selectCostCenter
                }
                
            }


        },

        acceptCostCenter(){

            let infoList= new Array()
            for (let index = 0; index < this.list.length; index++) {
                const element = this.list[index];
                if(element.code===this.selectedCostCenter){
                    const  inf={
                        "id":element.id,
                        "markInfo":" ",
                        "costCenter":document.getElementById(element.id).value
                    }
                    infoList.push(inf)
                } 
            }

            const params={
            newCostCenterInfo:JSON.stringify(infoList),
            fileId:this.list[0].fileId,
            remark:' '
             }

             acceptDetailInfo(params).then(res=>{
            console.log(res);
          })
        } 
     
     
      }
  
  
    
  
    
  }
  </script>
  
  <style>
  .table-striped_click td {
  background-color: rgb(135, 250, 139);
  height: 0.8rem;
 }
  </style>