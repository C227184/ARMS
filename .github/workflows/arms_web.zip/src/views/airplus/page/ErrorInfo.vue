<template>
  <div>
    <div class="legal_entity_text">
      Legal Entity
    </div>
    <div class="legal_entity_select">
    <a-select :value="selectLegalEntity" @change="changeLE" class="legal_entity">
      <a-select-option value="0813">BCL</a-select-option>
      <a-select-option value="1391">BCS</a-select-option>
      <a-select-option value="0882">BHC</a-select-option>
    </a-select>
  </div>
    <a-divider />
  <div> 
    <a-table
    bordered
    size="small"
    :loading="loading"
    :data-source="data"
    :columns="columns"
    :row-class-name="(_record, index) => (index % 2 === 1 ? 'table-striped' : null)"
    :customRow="rowClick"
    :pagination="pagination"
    @change="handleTableChange"
    >
    <p slot="tags" slot-scope="status,record">
      <a-button @click="downLoadDetail(record)" size='small'>Download</a-button>
    </p>
    </a-table>
  </div>

  <a-divider />
  <div> 
     <div class="detail_text_style"> Error Detail</div>
     <div><ErrorTable :errorList="errorList"  :status="detailStatus"></ErrorTable></div>
     <div class="detail_text_style"> Warning Detail</div>
     <div><WarningTableC :warningList="warningList" :status="detailStatus" ref="warningInfo"></WarningTableC></div>
  </div>

  <div>
    <table width="100%" border="0" cellpadding="0" cellspacing="0">
         <tbody><tr class="tbborder-down3" >
      <td width="4%" class="tbborder-down3"></td>
      <td width="15%" class="tbborder-down3"><font color="#1F6FBE"><strong> <span id="form1:title_signature_view">Signature</span> </strong> </font></td>
      <td colspan="5" class="tbborder-down3" >
        <ul >
          <li v-for="(item,index) in signatureList" :key="index">{{item}}</li>
        </ul>

      </td>
    </tr>
    <tr class="tbborder-down3">
      <td width="4%" class="tbborder-down3">&nbsp;</td>
      <td width="15%" class="tbborder-down3"><font color="#1F6FBE"><strong> 
         <span id="form1:title_remark_view">Remark</span> </strong> </font>
      </td>
      <td colspan="5" class="tbborder-down3" style="word-break:break-all; width:500px;">
        
         <ul >
          <li v-for="(item,index) in remarkList" :key="index">{{item}}</li>
        </ul>
      </td>
    </tr>
  </tbody></table>
  </div>

  </div>
  
  
</template>


<script>
import { ref } from 'vue'
import moment from 'moment' 
import{getProcessList,getDetailList,getInvoiceById,saveInvoiceById,downLoad } from '@/api/airplus'
import ErrorTable from './ErrorTable.vue'
import WarningTableC from './WarningTableC.vue'
const tableColumns=[

            {
              title: 'Billing File Name',
              key: 'fileName',
              dataIndex: 'fileName'
            },
            {
              title: 'Accounting No',
              key: 'accountNo',
              dataIndex: 'accountNo'
            },
            {
              title: 'Company Code',
              key: 'companyCode',
              dataIndex: 'companyCode'
            },
            {
              title: 'Status',
              key: 'status',
              dataIndex: 'status'
            },
            {
              title: 'Billing Soruce',
              key: 'sourceType',
              dataIndex: 'sourceType'
            },
            {
              title: 'Time',
              key: 'createdDate',
              dataIndex: 'createdDate'
            },
            {
              title: 'Export File',
              key: 'exportFile',
              dataIndex: 'exportFile',
              scopedSlots: { customRender: 'tags' }
            }
          ]
export default {
    name: 'ErrorInfo',
    components: {
    ErrorTable,
    WarningTableC
  },
    data () {
        return {
          columns: tableColumns,
          data: [],
          selectLegalEntity: ref('0813'),
          companyCode:'0813',
          detailStatus:'',
          detailFileId:'',
          pagination:{
            current: 1,
            total:'',
            pageSize: 10, // 默认每页显示数量
            showTotal: total => `总共 ${total} 条`, // 显示总数
          },
          errorList:[],
          warningList:[],
          remarkList:[],
          signatureList:[]
        }
    },
    mounted(){
    this.fetch();
  },
  methods:{
    changeLE (value) {
          this.selectLegalEntity = ref(value)
          this.companyCode=value
      },
     rowClick (record, index) {
        return {
         on: {

             click: () => {
              console.log(record)
              debugger
              this.detailStatus=record.status
              this.detailFileId=record.id
                }
           }
         }
      },

    fetch(params = {}) {
      
      this.loading = true;
      let param={
       pageNo:this.pagination.current,
       pageSize:this.pagination.pageSize,
       companyCode:this.companyCode,
       type:'Error'
      }
      getProcessList(param).then(res=>{
       this.loading = false;
       debugger
           console.log(res);
           let{list,pageSize,totalCount,totalPage}=res.data
           list.forEach(item => {
             const time=moment(item.createdDate).format("YYYY-MM-DD HH:mm:ss")
             item.createdDate=time
           });
           this.data=list
           this.pagination.total=totalCount
           this.pagination.totalPage=totalPage
           this.pagination.pageSize=pageSize
           
         })
   
   },

  getDetailListById(id,type ){

const params={
fileId:id,
type:type
}
if(id !==null){
getDetailList(params).then(res=>{
const list=  res.data.detail
this.errorList=[]
this.warningList=[]
for (let index = 0; index < list.length; index++) {
  const item = list[index];
  if('Warning'===item.type){
    this.warningList.push(item)
  }else if('Error'===item.type){
    this.errorList.push(item)
  }else{
    console.log("special item");
    console.log(item);
  }
  
}
  this.signatureList=res.data.signatureList
  this.remarkList=res.data.remarkList
  console.log(res);
})
}
},

   handleTableChange(pagination){
        
        this.loading=true
        this.pagination.current = pagination.current;
        this.pagination.pageSize = pagination.pageSize;
        let param={
          pageNo:pagination.current,
          pageSize:pagination.pageSize,
          companyCode:this.companyCode,
          type:'process'
        }
        getProcessList(param).then(res=>{
          console.log(res);
          this.loading=false
          let{list,pageSize,totalCount,totalPage}=res.data
          list.forEach(item => {
            const time=moment(item.createdDate).format("YYYY-MM-DD HH:mm:ss")
            item.createdDate=time
          });
          this.data=list
          this.pagination.total=totalCount
          this.pagination.totalPage=totalPage
          this.pagination.pageSize=pageSize
        })
        console.log("change table");
      }
  },
  watch:{
    companyCode(newVal, oldVal){
      this.fetch()
    },
    data(newVal, oldVal){
      console.log(newVal);
      if(newVal.length>0){
        
        const fileId=newVal[0].id
        this.detailStatus=newVal[0].status
        this.detailFileId=newVal[0].id
        this.getDetailListById(fileId," ")
       
      }
    },
    detailFileId(newVal, oldVal){
      debugger
      if(newVal!==''){
        this.getDetailListById(newVal," ")
       
      }
    },
  }

}
</script>

<style>
.legal_entity_text{
   font-size: 17px;
   color: blue;
   /* margin-top: 10px; */
   margin-left: 20px;
   width: 120px;
   float: left;
   width: 120px;
   font-weight: bold;
 }
 .legal_entity{
    width: 120px;
    margin-left: -20px;
 }
</style>