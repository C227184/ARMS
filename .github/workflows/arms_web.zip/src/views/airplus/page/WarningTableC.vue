<template>
    <div>
      <a-table :columns="columns" 
               :data-source="warningList" 
               :bordered="true"
               :scroll="{y:500}"
               size='small'>
               
    </a-table>
    </div>
  </template>
  
  <script>
  
   const columnsInfo=[
     {
        title: 'Ref No',
        dataIndex: 'referenceNo',
        key: 'referenceNo',
      },
      {
        title: 'Ref No',
        dataIndex: 'referenceNo',
        key: 'referenceNo'
      },
      {
        title: 'Order No',
        dataIndex: 'orderNo',
        key: 'orderNo'
      },
      {
        title: 'Ticket No',
        dataIndex: 'ticketNo',
        key: 'ticketNo'
      },
      {
        title: 'D/I',
        dataIndex: 'tripType',
        key: 'tripType'
      },
      {
        title: 'Type',
        dataIndex: 'categoryName',
        key: 'categoryName'
      },
      {
        title: 'Description',
        dataIndex: 'description',
        key: 'description'
      },
      {
        title: 'Remark Indication',
        dataIndex: 'remark',
        key: 'remark',
      },
    ]
  export default {
    name: 'WarningTableC',
    props:{
      warningList:{
              type:Array
          },
      status:{
        type:String
      }
      },
    data () {
      return {
        columns: columnsInfo,
        data: [],
        selectedRowKeys:[]
        
      }
    },
    methods:{
     
    
    },
  
    
  }
  </script>
  
  <style>
  
  </style>