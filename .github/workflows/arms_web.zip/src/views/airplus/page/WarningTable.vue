<template>
  <div>
    <a-table :columns="columns" 
             :data-source="warningList" 
             :row-selection="{ selectedRowKeys: selectedRowKeys, onChange: onSelectChange }"
             :pagination="false"
             :scroll="{y:500}"
             :bordered="true"
             @change="handleTableChange"
             size='small'>
             <p slot="remark" slot-scope="remakValue,record" >
                  <input :value="remakValue" v-if="status!=='Confirmed'" :id="record.id"/>
                  <pre v-else>{{remakValue}}</pre>
             </p>
  </a-table>
  </div>
</template>

<script>

import{saveDetailInfo,acceptDetailInfo,cancelDetailInfo } from '@/api/airplus'

 const columnsInfo=[
   {
      title: 'Ref No',
      dataIndex: 'referenceNo',
      key: 'referenceNo',
      scopedSlots: { customRender: 'referenceNo' },
    },
    {
      title: 'Ref No',
      dataIndex: 'referenceNo',
      key: 'referenceNo'
    },
    {
      title: 'Order No',
      dataIndex: 'orderNo',
      key: 'orderNo'
    },
    {
      title: 'Ticket No',
      dataIndex: 'ticketNo',
      key: 'ticketNo'
    },
    {
      title: 'D/I',
      dataIndex: 'tripType',
      key: 'tripType'
    },
    {
      title: 'Type',
      dataIndex: 'categoryName',
      key: 'categoryName'
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description'
    },
    {
      title: 'Remark Indication',
      dataIndex: 'remark',
      key: 'remark',
      scopedSlots: { customRender: 'remark' }
    },
  ]
export default {
  name: 'WarningTable',
  props:{
    warningList:{
            type:Array
        },
    status:{
      type:String
    }
    },
  data () {
    return {
      columns: columnsInfo,
      data: [],
      selectedRowKeys:[]
      
    }
  },
  methods:{
    onSelectChange(selectedRowKeys) {
      console.log('selectedRowKeys changed: ', selectedRowKeys);
      this.selectedRowKeys = selectedRowKeys;
    },
    saveRemark(remark ){
       if(this.selectedRowKeys.length==0){
          this.$message.warning("Please choose your records to save!")
        }else{
          let infoList= new Array()

          for (let index = 0; index < this.selectedRowKeys.length; index++) {
            const detail = this.selectedRowKeys[index];
            let record= this.warningList[detail]
          let dom=  document.getElementById(record.id)
            const item={
                "id":record.id,
                "markInfo":dom.value,
                "costCenter":''
               }
               infoList.push(item)
          }

          const params={
            detailInfo:JSON.stringify(infoList),
            fileId:this.warningList[0].fileId,
            type:"remark",
            remark:remark
          }

          saveDetailInfo(params).then(res=>{
            console.log(res);
          })
          console.log(params);

        }
    },

     acceptRemark(remark){
     if(this.selectedRowKeys.length!==this.warningList.length){
          this.$message.warning("All warning details must be ticked!")
        }else{
          let infoList= new Array()

          for (let index = 0; index < this.warningList.length; index++) {
            let record= this.warningList[index]
          let dom=  document.getElementById(record.id)
            const item={
                "id":record.id,
                "markInfo":dom.value,
                "costCenter":''
               }
               infoList.push(item)
          }

          const params={
            // detailInfo:JSON.stringify(infoList),
            fileId:this.warningList[0].fileId,
            remark:remark
          }

          acceptDetailInfo(params).then(res=>{
            console.log(res);
          })
          console.log(params);

        }
    },
    cancelRecord(remark){
      const param={
        fileId:this.warningList[0].id,
        remark:remark
      }
      cancelDetailInfo(param).then(res=>{
        console.log(res);
      })
    }


  },

  watch:{
    warningList(newVal, oldVal){
     
    }
  }
}
</script>

<style>

</style>