<template>
  <div>
    <div>
      <div class="legal_entity_text">
        Legal Entity
      </div>
    <div class="legal_entity_select">
      <a-select :value="selectLegalEntity" @change="changeLE" class="legal_entity">
        <a-select-option value="0813">BCL</a-select-option>
        <a-select-option value="1391">BCS</a-select-option>
        <a-select-option value="0882">BHC</a-select-option>
      </a-select>
    </div>
    <div style="float:right">
      <a-button type="primary" class="posting_buttn" @click="handelPosting">Posting</a-button>
    </div>
    </div>
    <a-divider />
    <div style="margin-top:20px">
      <a-table
      :bordered="true"
      size="small"
      :loading="loading"
      :data-source="data"
      :columns="columns"
      :row-class-name="setRowClassName"
      :customRow="rowClick"
      :pagination="pagination"
      @change="handleTableChange"
      >
      <div  slot="checkBoxId" slot-scope="id,record">
        <input type="checkbox" :value="id"  v-model="selectboxvalue" v-if="record.status==='Confirmed'"/>
      </div>
      
      <p slot="tags" slot-scope="status,record">
        <a-button @click="downLoadDetail(record)" size='small'>Detail</a-button>
        <a-button @click="openInvoice(record)" size='small' v-show="record.status=='Confirmed'">Invoice</a-button>
      </p>
      </a-table>
    </div>
    <a-divider />
    <div class="button_div">
      <a-button type="primary" @click="handleAccepted" v-if="detailStatus!=='Confirmed' || lockDeatil.length>0 " >Accept</a-button>
      <a-button type="primary" @click="handleSave" v-if="detailStatus!=='Confirmed' ">Save</a-button>
      <a-button type="primary" @click="handleCancel" class="posting_buttn" v-if="detailStatus!=='Confirmed' ">Cancel</a-button>
    </div>
    <a-divider />
    <div> 
       <div class="detail_text_style" v-if="lockDeatil.length>0"> Wrong Cost Center</div>
       <div>
        <WrongCostCenterTable v-if="lockDeatil.length>0" :list="lockDeatil"  :companyCode="companyCode" ></WrongCostCenterTable>
       </div>
       <div class="detail_text_style"> Error Detail</div>
       <div><ErrorTable :errorList="errorList"  :status="detailStatus"></ErrorTable></div>
       <div class="detail_text_style"> Warning Detail</div>
       <div><WarningTable :warningList="warningList" :status="detailStatus" ref="warningInfo"></WarningTable></div>
    </div>
    <div>
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
           <tbody><tr class="tbborder-down3" v-if="detailStatus=='Confirmed'">
				<td width="4%" class="tbborder-down3"></td>
				<td width="15%" class="tbborder-down3"><font color="#1F6FBE"><strong> <span id="form1:title_signature_view">Signature</span> </strong> </font></td>
				<td colspan="5" class="tbborder-down3" >
          <ul >
            <li v-for="(item,index) in signatureList" :key="index">{{item}}</li>
          </ul>

				</td>
			</tr>
			<tr class="tbborder-down3">
				<td width="4%" class="tbborder-down3">&nbsp;</td>
				<td width="15%" class="tbborder-down3"><font color="#1F6FBE"><strong> 
				   <span id="form1:title_remark_view">Remark</span> </strong> </font>
				</td>
				<td colspan="5" class="tbborder-down3" style="word-break:break-all; width:500px;">
				  
           <ul v-if="detailStatus=='Confirmed'">
            <li v-for="(item,index) in remarkList" :key="index">{{item}}</li>
          </ul>
          <a-textarea v-else allow-clear v-model="remark" />
        </td>
			</tr>
    </tbody></table>
    </div>
    <a-modal 
      v-model="showInvoice" 
      title="Posting Information" 
      ok-text="确认" 
      cancel-text="取消" 
      @ok="saveInvoice">
      <div>
        <table border=0 cellpadding=0 cellspacing=0 width=100%>
					<tr>
						<td width=20px></td>
						<td>
							<TABLE width="100%">
								<TR>
									<TD colspan=2 class="txt" align="center" valign="center"
										bgcolor="#e7f3ff" height="30">
                    Posting Information
									</TD>
								</TR>

								<TR>
									<TD class="txt" width="34%" height="20">
										Invoice Date
									</TD>
									<td class="tbborder-down3" id="employee_static">
                    <a-date-picker 
                    v-model="form.invoiceDate" 
                    style="width: 100%" />
									</td>
								</TR>
								<TR>
									<TD class="txt" width="34%" height="20">
										Invoice No
									</TD>
									<td class="tbborder-down3" id="employee_static">
										<a-input v-model="form.invoiceNo" size="small"/>
									</td>
								</TR>
								<TR>
									<TD class="txt" width="34%" height="20">
										BaseLine Date
									</TD>
									<td class="tbborder-down3" id="employee_static">
                    <a-date-picker 
                     v-model="form.baselineDate" 
                     style="width: 100%" />
									</td>
								</TR>
								<TR>
									<TD class="txt" width="34%" height="20">
										Bar Code
									</TD>
									<td class="tbborder-down3" id="employee_static">
										<a-input v-model="form.barCode" size="small"></a-input>
									</td>
								</TR>
								
								<TR>
									<td>
										&nbsp;
									</td>
									<td></td>
								</TR>
								<TR>
									<TD class="txt" width="34%" height="20">
										VAT Invoice Date
									</TD>
									<td class="tbborder-down3" id="employee_static">
										<a-date-picker
                     v-model="form.vatInvoiceDate" 
                     style="width: 100%" />
									</td>
								</TR>
								<TR>
									<TD class="txt" width="34%" height="20">
										VAT Invoice No
									</TD>
									<td class="tbborder-down3" id="employee_static">
										<a-input 
                      v-model="form.vatInvoiceNo" 
                      size="small"/>
									</td>
								</TR>
								<TR>
									<TD class="txt" width="34%" height="20">
										VAT BaseLine Date
									</TD>
									<td class="tbborder-down3" id="employee_static">
                    <a-date-picker
                     v-model="form.vatBaselineDate"
                    style="width: 100%" />
									</td>
								</TR>
								<TR>
									<TD class="txt" width="34%" height="20">
										VAT Bar Code
									</TD>
									<td class="tbborder-down3" id="employee_static">
										<a-input 
                     v-model="form.vatBarCode" size="small"></a-input>
									</td>
								</TR>
								<TR>
									<TD class="txt" colspan="2" width="34%" height="20">
										Note:Mutiple invoice number is not allowed to input.
									</TD>
								</TR>
							</table>
						</td>
					</tr>
				</table>
      </div>
    </a-modal>
  </div>
</template>

<script>
import { ref } from 'vue'
import moment from 'moment' 
import{getProcessList,getDetailList,getInvoiceById,saveInvoiceById,downLoad,DownloadFileXLS,doPosting,getLockCostCenter,acceptDetailInfo} from '@/api/airplus'
import ErrorTable from './ErrorTable.vue'
import WarningTable from './WarningTable.vue'
import WrongCostCenterTable from './WrongCostCenterTable.vue'

const tableColumns=[
              {
                title: '',
                key: 'id',
                dataIndex: 'id',
                scopedSlots: { customRender: 'checkBoxId' }
              },
              {
                title: 'Billing File Name',
                key: 'fileName',
                dataIndex: 'fileName'
              },
              {
                title: 'Accounting No',
                key: 'accountNo',
                dataIndex: 'accountNo'
              },
              {
                title: 'Company Code',
                key: 'companyCode',
                dataIndex: 'companyCode'
              },
              {
                title: 'Status',
                key: 'status',
                dataIndex: 'status'
              },
              {
                title: 'Billing Soruce',
                key: 'sourceType',
                dataIndex: 'sourceType'
              },
              {
                title: 'Time',
                key: 'createdDate',
                dataIndex: 'createdDate'
              },
              {
                title: 'Export File',
                key: 'exportFile',
                dataIndex: 'exportFile',
                scopedSlots: { customRender: 'tags' }
              }
            ]
export default {
    name: 'ProcessInfo',
    components: {
      ErrorTable,
      WarningTable,
      WrongCostCenterTable
    },
    data () {
        return {
            columns: tableColumns,
            data: [],
            selectLegalEntity: ref('0813'),
            detailStatus:'',
            detailFileId:'',
            detailSourceType:'',
            loading:false,
            companyCode:'0813',
            remarkList:[],
            signatureList:[],
            lockDeatil:[],
            pagination:{
              current: 1,
              total:'',
              pageSize: 10, // 默认每页显示数量
              showTotal: total => `总共 ${total} 条`, // 显示总数
            },
            selectboxvalue:[],
            errorList:[],
            warningList:[],
            detailId:'',
            showInvoice:false,
            remark:'',
            form:{
              id:'',
              fileId:'',
              invoiceDate:'',
              invoiceNo:'',
              baselineDate:'',
              barCode:'',
              vatInvoiceDate:'',
              vatInvoiceNo:'',
              vatBaselineDate:'',
              vatBarCode:''
            }
        }
    },
    mounted(){
      this.fetch();
    },
 
    methods: {
     
       changeLE (value) {
            this.selectLegalEntity = ref(value)
            this.companyCode=value
        },
       setRowClassName(record, index){
       let rowSTyle= index % 2 === 1 ? 'table-striped' : null
        if(record.id===this.detailFileId){
          return "table-striped_click"
        }else{
          return rowSTyle
        }
       }
       ,
       rowClick (record, index) {
          return {
           on: {
               click: () => {
                debugger
                const{ status,id,sourceType}=record
                this.detailStatus=status
                this.detailFileId=id
                this.detailSourceType=sourceType

                this.getDetailListById(id," ")
                if(status==='Confirmed'){
                   this.getLockStatus(id)
                }
                }
             }
           }
        },
        
        handleTableChange(pagination){
          
          this.loading=true
          this.pagination.current = pagination.current;
          this.pagination.pageSize = pagination.pageSize;
          let param={
            pageNo:pagination.current,
            pageSize:pagination.pageSize,
            companyCode:this.companyCode,
            type:'process'
          }
          getProcessList(param).then(res=>{
            console.log(res);
            this.loading=false
            let{list,pageSize,totalCount,totalPage}=res.data
            list.forEach(item => {
              const time=moment(item.createdDate).format("YYYY-MM-DD HH:mm:ss")
              item.createdDate=time
            });
            this.data=list
            this.pagination.total=totalCount
            this.pagination.totalPage=totalPage
            this.pagination.pageSize=pageSize

          })
          console.log("change table");
        },

      fetch(params = {}) {
        
       this.loading = true;
       let param={
        pageNo:this.pagination.current,
        pageSize:this.pagination.pageSize,
        companyCode:this.companyCode,
        type:'process'
       }
       getProcessList(param).then(res=>{
        this.loading = false;
            let{list,pageSize,totalCount,totalPage}=res.data
            list.forEach(item => {
              const time=moment(item.createdDate).format("YYYY-MM-DD HH:mm:ss")
              item.createdDate=time
            });
            this.data=list
            this.pagination.total=totalCount
            this.pagination.totalPage=totalPage
            this.pagination.pageSize=pageSize

            if(list.length>0){
              const fileId=list[0].id
              this.detailStatus=list[0].status
              this.detailFileId=list[0].id
              this.detailSourceType=list[0].sourceType
              this.getDetailListById(fileId," ")
            }
            
          }).catch((res)=>{
            this.loading = false;
            this.$message.error("System error!")
          });
    },
   
    getDetailListById(id,type ){

      const params={
        fileId:id,
        type:type
      }
       if(id !==null){
        getDetailList(params).then(res=>{
        const list=  res.data.detail
        this.errorList=[]
        this.warningList=[]
        for (let index = 0; index < list.length; index++) {
          const item = list[index];
          if('Warning'===item.type){
            this.warningList.push(item)
          }else if('Error'===item.type){
            this.errorList.push(item)
          }else{
            console.log("special item");
            console.log(item);
          }
          
        }
          this.signatureList=res.data.signatureList
          this.remarkList=res.data.remarkList
          console.log(res);
        })
       }
    },

    //查看invoice info
    openInvoice(item){
      debugger
      console.log(item);
      this.showInvoice=true

      if(item.id!==''){
        
        const param={
          fileId:item.id
        }
        getInvoiceById(param).then(res=>{
          if(res.data==null){
            this.form.fileId=item.id
          }else{
            this.form=res.data
          }
          
        })
      }
    },
  // 保存invoice info
    saveInvoice(){
        if(this.form.invoiceDate==null || this.form.invoiceDate==''){
          this.$message.warning("Invoice Date is Required!")
          return
        }else if(this.form.invoiceNo==null || this.form.invoiceNo==''){
          this.$message.warning("Invoice No is Required!")
          return
        }else if(this.form.baselineDate==null || this.form.baselineDate==''){
          this.$message.warning("Baseline Date is Required!")
          return
        }else if(this.form.barCode==null || this.form.barCode==''){
          this.$message.warning("Bar Code is Required!")
          return
        }else if(this.form.vatInvoiceDate==null || this.form.vatInvoiceDate==''){
          this.$message.warning("VAT Invoice Date is Required!")
          return
        }else if(this.form.vatInvoiceNo==null || this.form.vatInvoiceNo==''){
          this.$message.warning("VAT Invoice No is Required!")
          return
        }else if(this.form.vatBaselineDate==null || this.form.vatBaselineDate==''){
          this.$message.warning("VAT Baseline Date is Required!")
          return
        }else if(this.form.vatBarCode==null || this.form.vatBarCode==''){
          this.$message.warning("VAT Bar Code is Required!")
          return
        }

        debugger
        const params={
          id:this.form.id,
          fileId:this.form.fileId,
          invoiceDate: moment(this.form.invoiceDate).format("YYYY-MM-DD"),
          invoiceNo:this.form.invoiceNo,
          baselineDate:moment(this.form.baselineDate).format("YYYY-MM-DD"),
          barCode:this.form.barCode,
          vatInvoiceDate: moment(this.form.vatInvoiceDate).format("YYYY-MM-DD"),
          vatInvoiceNo:this.form.vatInvoiceNo,
          vatBaselineDate:moment(this.form.vatBaselineDate).format("YYYY-MM-DD"),
          vatBarCode:this.form.vatBarCode,

        }
        saveInvoiceById(params).then(res=>{
          if(res.msg==='success'){
            this.$message.success("success")
          }
        })
        
        this.showInvoice=false
      },
    // 下载对应文件信息
    downLoadDetail(item){

      if(item.id!=''){

        const param={
          fileId:item.id
        }
          downLoad(param).then(res=>{
            DownloadFileXLS(res, item.fileName);
          }).catch((res)=>{
            this.$message.error("Download failed!")
             console.log('文件下载失败');
          });
        

      }
      

    },
    // 保存信息
    handleSave(){
      if(this.detailStatus==='Waiting for Confirmation'){
        //remark info
            this.$refs.warningInfo.saveRemark(this.remark)
        }
    },
   // 确认账单信息
    handleAccepted(){
      if(this.detailStatus==='Confirmed'){
        this.$refs.WrongCostCenterTable.acceptCostCenter()
      }else{
        this.$refs.warningInfo.acceptRemark(this.remark)
      }
      
    },
    // 取消账单
    handleCancel(){
      this.$refs.warningInfo.cancelRecord(this.remark)
    },
   // 执行posting 
    handelPosting(){
      // 校验cost center  是否存在失效的
      if(this.detailFileId!==''){
        const params={
          id:this.detailFileId,
          leCode:this.companyCode,
          sourceType:this.detailSourceType
        }
        doPosting(params).then(res=>{
          debugger
          console.log(res);
        })
      }
    },
  // 查询错误成本中心
    getLockStatus(){
      const param={
            fileId:this.detailFileId
          }
          getLockCostCenter(param).then(res=>{
            debugger
            this.lockDeatil=res.data
          }).catch(res=>{
            this.$message.error("get lock stauts error")
          })
    }


      
    },
  
    watch:{
      companyCode(newVal, oldVal){
        this.fetch()
      },
    }
}
</script>

<style scope>
::v-deep
 .ant-table-scroll {
  height: 150px;
  overflow: auto  scroll;
 }
.legal_entity_text{
   font-size: 17px;
   color: blue;
   /* margin-top: 10px; */
   margin-left: 20px;
   width: 120px;
   float: left;
   width: 120px;
   font-weight: bold;
 }
 .legal_entity_select{
  float: left;
 }
 .legal_entity{
    width: 120px;
    margin-left: -20px;
 }
 .detail_text_style{
    background-color:lightskyblue
 }

 .table-striped td {
  background-color: lightskyblue;
  height: 0.5rem;
 }

 .table-striped_click td {
  background-color: rgb(135, 250, 139);
  height: 0.8rem;
 }
 .button_div{
  background-color: greenyellow;
  float: right;
 }
</style>