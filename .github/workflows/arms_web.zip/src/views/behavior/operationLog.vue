<template>
  <page-header-wrapper :title="false">
    <a-card :bordered="false">
      <div class="table-page-search-wrapper">
        <a-form layout="inline" size="small">
          <a-row :gutter="24" size="small">
            <a-col :md="12" :sm="24" size="small">
              <a-form-item label="OperateTime">
                <a-range-picker @change="onChange" v-model="selectTime" :show-time="{
                  hideDisabledOptions: true,
                  defaultValue: [moment('00:00:00', 'HH:mm:ss'), moment('23:59:59', 'HH:mm:ss')],
                }" format="YYYY-MM-DD HH:mm:ss" />
                <a-input v-model="queryParam.startTime" placeholder="" v-show="false" />
                <a-input v-model="queryParam.endTime" placeholder="" v-show="false" />
              </a-form-item>
            </a-col>
            <a-col :md="!advanced && 8 || 24" :sm="24">
              <span class="table-page-search-submitButtons">
                <a-button type="primary" shape="round" @click="$refs.table.refresh(true)">Search</a-button>
                <a-button style="margin-left: 8px" shape="round" @click="resetSearchControl()">Reset</a-button>
              </span>
            </a-col>
          </a-row>
        </a-form>
      </div>
      <s-table ref="table" size="small" rowKey="operationId" :columns="columns" :data="loadData" :alert="false"
        :loading="loading" showPagination="auto">
        <span slot="serial" slot-scope="text, record, index">
          {{ index + 1 }}
        </span>
        <span slot="status" slot-scope="text">
          <a-badge :status="text | statusTypeFilter" :text="text | statusFilter" />
        </span>
      </s-table>
    </a-card>
  </page-header-wrapper>
</template>
   
<script>
import { STable, Ellipsis } from '@/components'
import { GetOperationLogList } from '@/api/arms'

import moment from 'moment'

const columns = [
  {
    title: 'Operate Time',
    width: 120,
    dataIndex: 'operateTime'
  },
  {
    title: 'Operator Name',
    width: 150,
    dataIndex: 'operatorName'
  },
  {
    title: 'Operate Type',
    width: 100,
    dataIndex: 'operateType'
  },
  {
    title: 'Operate IP',
    width: 100,
    dataIndex: 'operateIP'
  },
  {
    title: 'Comments',
    width: 200,
    dataIndex: 'operateInfo',
    ellipsis: true
  }
]

export default {
  name: 'TableList',
  components: {
    STable,
    Ellipsis
  },
  data() {
    this.columns = columns
    return {
      moment,
      // create model
      visible: false,
      loading: false,
      confirmLoading: false,
      mdl: null,
      // 高级搜索 展开/关闭
      advanced: false,
      // 查询参数
      queryParam: {},
      // 加载数据方法 必须为 Promise 对象
      loadData: parameter => {
        const requestParameters = Object.assign({}, parameter, this.queryParam)
        //console.log('loadData request parameters:', requestParameters)
        return GetOperationLogList(requestParameters)
          .then(res => {
            //console.log(res);
            if (res.status == '500') {
              this.$message.error(res.message)
              //this.$refs.table.refresh()
              return;
            }
            return res.result
          })
      },
      selectedRowKeys: [],
      selectedRows: [],
      companyData: [],
      startTime: null,
      endTime: null,
      selectTime: []
    }
  },
  mounted() {
    //this.fetch();
  },
  filters: {
    statusFilter(type) {
      return statusMap[type].text
    },
    statusTypeFilter(type) {
      return statusMap[type].status
    }
  },
  computed: {
    rowSelection() {
      return {
        selectedRowKeys: this.selectedRowKeys,
        //selectedRows: this.selectedRows,
        onChange: this.onSelectChange
      }
    }
  },
  created() {
    this.initTime()
  },
  methods: {
    onSelectChange(selectedRowKeys, selectedRows) {
      this.selectedRowKeys = selectedRowKeys
      this.selectedRows = selectedRows
    },
    initTime() {
      this.selectTime = []
      this.selectTime = [moment().utcOffset(8).subtract(1, 'month').format('YYYY-MM-DD')]
      this.queryParam.startTime = this.selectTime[0]
    },
    fetch(parameter = {}) {
      this.loading = true;
      this.queryParam
      const requestParameters = { pageNo: 1, pageSize: 10, companyCode: '0813' }
      return GetOperationLogList(requestParameters)
        .then(res => {
          //console.log(res);
          if (res.status == '500') {
            this.$message.error(res.message)
            //this.$refs.table.refresh()
            return;
          }
          return res.result
        })
    },
    onChange(date, dateString) {
      this.startTime = dateString[0];
      this.endTime = dateString[1];
      if (date.length === 0) {
        this.selectTime = [];
        this.queryParam.startTime = null
        this.queryParam.endTime = null
      } else {
        this.queryParam.startTime = this.startTime;
        this.queryParam.endTime = this.endTime;
      }
    },
    resetSearchControl() {
      this.queryParam = {}
      this.selectTime = []
      this.queryParam.startTime = null
      this.queryParam.endTime = null
    }
  }
}
</script> 