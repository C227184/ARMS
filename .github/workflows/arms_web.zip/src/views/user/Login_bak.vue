<template>
  <div class="login-wrapper">
    <a-spin :spinning="loginLoading">
      <div class="login-box">
        <div class="top-area">
          <span>Travel Billing System</span>
        </div>
        <div class="bottom-area">
         <div class="login-form">
            <a-alert v-if="isLoginError" type="error" showIcon style="margin-bottom: 24px;" :message="errMsg"/>
          
              <a-button
              @click="handleLogin"
              size="small"
              type="primary"
              class="login-btn"
              :loading="loginBtn"
              :disabled="loginBtn"
               >Log In</a-button>
          </div> 
        </div>
      </div>
    </a-spin>
  </div>
</template>

<script>
import { timeFix } from '@/utils/util'
import storage from 'store'
import { AZURE_STATE} from '@/store/mutation-types'

export default {
  name: 'MrbsLogin',
  data() {
    return {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 }
      },
      loginBtn: false,
      isLoginError: false,
      errMsg: '',
      loginLoading: false
    }
  },
  beforeCreate() {
    this.form = this.$form.createForm(this)
  },
  mounted() { 

     this.loginLoading=true
     var loading = this.$message.loading('正在自动登录...', 0)
     this.azureNoLogin(loading)
    // 绑定enter事件
    this.enterKeyup()
  },
  destroyed() {
    // 销毁enter事件
    this.enterKeyupDestroyed()
    
  },
  methods: {
    enterKey(event) {
      const componentName = this.$options.name
      if (componentName == 'MrbsLogin') {
        const code = event.keyCode
            ? event.keyCode
            : event.which
                ? event.which
                : event.charCode
        if (code == 13) {
          this.handleLogin(event)
        }
      }
    },
    enterKeyupDestroyed() {
      document.removeEventListener('keyup', this.enterKey)
    },
    enterKeyup() {
      document.addEventListener('keyup', this.enterKey)
    },

    azureNoLogin(loading)
    {
      this.loginSuccess2()
    },

    loginSuccess2() {
      // check res.homePage define, set $router.push name res.homePage
      // Why not enter onComplete
      /*
      this.$router.push({ name: 'analysis' }, () => {
        console.log('onComplete')
        this.$notification.success({
          message: '欢迎',
          description: `${timeFix()}，欢迎回来`
        })
      })
      */
      this.$router.push({ path: '/' })
      console.error('1222')
      // 延迟 1 秒显示欢迎信息
      setTimeout(() => {
        this.$notification.success({
          message: '欢迎',
          description: `${timeFix()}，欢迎回来`
        })
      }, 1000)
      this.isLoginError = false
    },

    azureLogin(loading) {
      
      this.loginBtn = true
      let stateId=''
      
      if( localStorage.getItem(AZURE_STATE) !=null  && localStorage.getItem(AZURE_STATE) !=''){
        stateId= JSON.parse(localStorage.getItem(AZURE_STATE))
      }
      this.$store.dispatch('AzureLogin',stateId).then(res => {
        this.loginSuccess(res)
      }).catch(err => {
        this.isLoginError = true
        this.errMsg = err.msg || '未知异常，请联系管理员！'
        console.error('login err', err)
      })
          .finally(() => {
            this.loginBtn = false
            this.loginLoading = false
            setTimeout(loading, 50)
          })
    },

    handleLogin(e) {
      e.preventDefault()
      this.loginBtn = true
      this.form.validateFieldsAndScroll((err, values) => {
        if (!err) {
           let stateId=''
       if( storage.get(AZURE_STATE) !=null && storage.get(AZURE_STATE) !=''){
        stateId=storage.get(AZURE_STATE)
      }
          this.$store.dispatch('AzureLogin', stateId).then(res => this.loginSuccess(res))
              .catch(err => {
                this.isLoginError = true
                this.errMsg = err.msg || '未知异常，请联系管理员！'
                console.error('login err', err)
              })
              .finally(() => {
                this.loginBtn = false
              })
        } else {
          setTimeout(() => {
            this.loginBtn = false
          }, 600)
        }
      })
    },
    loginSuccess(res) {

     if(this.$store.getters.azureUrl!=''){
       window.location.href=this.$store.getters.azureUrl
     }else{

        this.$router.push({ path: '/' })
      // 延迟 1 秒显示欢迎信息
      setTimeout(() => {
        this.$notification.success({
          message: this.$store.getters.nickname,
          description: `${timeFix()}，Welcome Back!`
        })
      }, 1000)
      this.isLoginError = false
     }
  
    }
  }
}
</script>

<style lang="less" scoped>

.login-wrapper {
  height: 100vh;
  width: 100vw;
  padding-top: 6%;
  background-color: #f3f3f3;
  //background-image: url("~@/assets/login-bg.png");
  //background-repeat: no-repeat;
  //background-size: cover;

  .login-box {
    margin: 0 auto;
    width: 500px;
    height: 360px;
    background: #fff;
    border-radius: 4px;
    box-sizing: border-box;
    box-shadow: 0 2px 8px #ececec;


    .top-area {
      height: 25%;
      background: #0091df;
      border-radius: 4px 4px 0 0;
      display: flex;
      align-items: center;
      justify-content: center;

      span {
        color: #fff;
        font-size: 24px;
        font-weight: bold;
      }
    }

    .bottom-area {
      height: 75%;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;

      .login-form {
        width: 80%;
      }

      .login-btn {
        position: absolute;
        bottom: -20px;
        left: 40%;
        height: 40px;
        line-height: 40px;
        width: 20%;
        border-radius: 4px;
        background: #0091df;
        color: #fff;
        font-size: 14px;
        text-align: center;
        cursor: pointer;
        user-select: none;
      }
    }
  }
}


</style>
