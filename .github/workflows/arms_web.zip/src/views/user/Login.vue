<template>
    <div class="login-wrapper">
        <a-form id="formLogin" class="user-layout-login" ref="formLogin" :form="form" @submit="handleSubmit">
            <div class="login-box">
                <div class="top-area">
                    <span>ARMS System</span>
                </div>
                <div class="bottom-area">
                    <div class="login-form">
                        <a-form-item>
                            <a-input size="large" type="text" allowClear :placeholder="$t('Please input your account')"
                                v-decorator="[
                                    'username',
                                    { rules: [{ required: true, message: 'Please input your account' }] }
                                ]">
                                <a-icon slot="prefix" type="user" :style="{ color: 'rgba(0,0,0,.25)' }" />
                            </a-input>
                        </a-form-item>
                        <a-form-item>
                            <a-input-password size="large" allowClear :placeholder="$t('Please input your password')"
                                v-decorator="[
                                    'password',
                                    { rules: [{ required: true, message: 'Please input your password' }] }
                                ]">
                                <a-icon slot="prefix" type="lock" :style="{ color: 'rgba(0,0,0,.25)' }" />
                            </a-input-password>
                        </a-form-item>

                        <a-form-item style="margin-top:24px">
                            <a-button size="large" type="primary" htmlType="submit" class="login-button"
                                :loading="state.loginBtn" :disabled="state.loginBtn">Log In</a-button>
                        </a-form-item>
                    </div>
                </div>
            </div>
        </a-form>
    </div>
</template>
  
<script>

import md5 from 'md5'
import { mapActions } from 'vuex'
import { timeFix } from '@/utils/util'
import { getSmsCaptcha, get2step } from '@/api/login'

import storage from 'store'
import { AZURE_STATE } from '@/store/mutation-types'
import store from '@/store/index'


export default {
    name: 'ArmsLogin',
    data() {
        return {
            labelCol: {
                xs: { span: 24 },
                sm: { span: 6 }
            },
            wrapperCol: {
                xs: { span: 24 },
                sm: { span: 16 }
            },
            loginBtn: false,
            isLoginError: false,
            form: this.$form.createForm(this),
            state: {
                time: 60,
                loginBtn: false
            }
        }
    },
    beforeCreate() {
        this.form = this.$form.createForm(this)
    },
    mounted() {
        // 绑定enter事件
        this.enterKeyup()
    },
    destroyed() {
        // 销毁enter事件
        this.enterKeyupDestroyed()

    },
    methods: {
        enterKey(event) {
            const componentName = this.$options.name
            if (componentName == 'ArmsLogin') {
                const code = event.keyCode
                    ? event.keyCode
                    : event.which
                        ? event.which
                        : event.charCode
                if (code == 13) {
                    //this.handleSubmit(event)
                }
            }
        },
        enterKeyupDestroyed() {
            document.removeEventListener('keyup', this.enterKey)
        },
        enterKeyup() {
            document.addEventListener('keyup', this.enterKey)
        },

        ...mapActions(['Login', 'Logout']),
        // handler
        handleSubmit(e) {
            e.preventDefault()
            const {
                form: { validateFields },
                state,
                Login
            } = this
            state.loginBtn = true
            const validateFieldsKey = ['username', 'password'];
            validateFields(validateFieldsKey, { force: true }, (err, values) => {
                if (!err) {
                    //console.log('login form', values)
                    const loginParams = { ...values }
                    Login(loginParams)
                        .then((res) => {
                            this.loginSuccess(res)
                        })
                        .catch(err => this.requestFailed(err))
                        .finally(() => {
                            state.loginBtn = false
                        })
                } else {
                    setTimeout(() => {
                        state.loginBtn = false
                    }, 600)
                }
            })
        },
        loginSuccess(res) {
            this.$router.push({ path: '/' })
            // 延迟 1 秒显示欢迎信息
            setTimeout(() => {
                this.$notification.success({
                    message: this.$store.getters.nickname,
                    description: `${timeFix()}，Welcome Back!`
                })
            }, 1000)
            this.isLoginError = false
        },
        requestFailed(err) {
            this.isLoginError = true
            this.$notification['error']({
                message: '错误',
                description: ((err.response || {}).data || {}).message || '登录失败，请检查用户名/密码输入是否正确!',
                duration: 4
            })
        }

    }
}
</script>
  
<style lang="less" scoped>
.user-layout-login {
    label {
        font-size: 14px;
    }
}

button.login-button {
    padding: 0 15px;
    font-size: 16px;
    height: 40px;
    width: 100%;
}

.login-wrapper {
    height: 100vh;
    width: 100vw;
    padding-top: 6%;
    background-color: #f3f3f3;
    //background-image: url("~@/assets/login-bg.png");
    //background-repeat: no-repeat;
    //background-size: cover;

    .login-box {
        margin: 0 auto;
        width: 500px;
        height: 360px;
        background: #fff;
        border-radius: 4px;
        box-sizing: border-box;
        box-shadow: 0 2px 8px #ececec;


        .top-area {
            height: 25%;
            background: #0091df;
            border-radius: 4px 4px 0 0;
            display: flex;
            align-items: center;
            justify-content: center;

            span {
                color: #fff;
                font-size: 24px;
                font-weight: bold;
            }
        }

        .bottom-area {
            height: 75%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;

            .login-form {
                width: 90%;
            }

            .login-btn {
                position: absolute;
                bottom: -20px;
                left: 40%;
                height: 40px;
                line-height: 40px;
                width: 20%;
                border-radius: 4px;
                background: #0091df;
                color: #fff;
                font-size: 14px;
                text-align: center;
                cursor: pointer;
                user-select: none;
            }
        }
    }
}
</style>
  